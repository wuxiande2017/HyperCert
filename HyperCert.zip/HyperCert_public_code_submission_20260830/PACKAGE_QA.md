# Package quality checks

- Curated source modules copied from the current audited project: 35.
- Copied core-module SHA-256 comparison against the working project: PASS.
- Minimal certificate-feedback example: PASS.
- Public unit smoke tests: 3/3 PASS.
- Direct imports of the safe-anytime planner, certificate projector, and geometric verifier: PASS.
- Machine-specific absolute path and username scan: PASS; no matches.
- Credential-pattern scan: PASS; no matches.
- Cache, bytecode, log, Word, and binary-array exclusion scan: PASS.

The checks above validate packaging and the included public subset. They do not claim that this reduced archive reproduces the complete manuscript experiment suite.
