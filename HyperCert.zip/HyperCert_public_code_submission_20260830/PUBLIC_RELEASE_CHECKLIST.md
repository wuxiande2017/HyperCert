# Public-release checklist

- [ ] Add the final manuscript title, author list, and DOI or preprint identifier.
- [ ] Select and add an appropriate software license.
- [ ] Confirm institutional and funder requirements for public code.
- [ ] Confirm whether the journal requires archived raw data in addition to this code subset.
- [ ] Create a permanent release tag and archive it with a DOI-bearing service if required.
- [ ] Keep `SCOPE_AND_EXCLUSIONS.md` with the public release so the reproducibility boundary is explicit.
