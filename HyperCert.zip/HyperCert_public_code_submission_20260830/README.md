# HyperCert: Curated Public Code for Manuscript Submission

This archive contains a curated, public-facing subset of the current HyperCert research code. It exposes the main implementation path used to describe the method in the manuscript:

1. robust continuous resource-occupancy intervals;
2. continuous-time capacity verification;
3. structured overload witnesses;
4. continuous geometric-separation verification;
5. certificate-informed route/timing candidate generation; and
6. safe-anytime candidate evaluation with final recertification.

The source files in `src/` were copied from the current audited project state. The package is intentionally smaller than the development repository and should be cited as a curated research artifact, not as a complete software release.

## Quick start

Python 3.10 or later is recommended.

```bash
python -m venv .venv
python -m pip install -e .
python examples/basic_certificate_feedback.py
python -m unittest discover -s tests -v
```

The example creates two robust occupancy intervals on one capacity-one resource, detects the overload by an exact event sweep, and converts it into a structured HyperCert witness.

## Public source layout

- `src/certificate/`: robust occupancy records and continuous-time capacity verification.
- `src/hypercert/`: decision variables, projection, structured certificate feedback, geometric checking, conflict-hypergraph support, and the safe-anytime planner.
- `src/reservation/`: atomic reservation structures required by final certificate commitment.
- `src/models/`: uncertainty bounds used by robust occupancy projection.
- `src/corridor/`: the topology structure required by the execution-geometry interface.
- `examples/`: a small executable certificate-feedback example.
- `tests/`: public smoke tests for the included subset.

## Reproducibility boundary

This package demonstrates and tests the principal HyperCert mechanism. It does not contain the complete experiment-orchestration repository and is not sufficient by itself to regenerate every manuscript table and figure. See `SCOPE_AND_EXCLUSIONS.md` for the explicit boundary.

## Installation note

The public subset depends only on NumPy and SciPy. No GPU is required.

## License note

No open-source license has been selected in this archive. Before publishing the archive in a permanent repository, the authors should add the license required by their institution, funder, or journal.
