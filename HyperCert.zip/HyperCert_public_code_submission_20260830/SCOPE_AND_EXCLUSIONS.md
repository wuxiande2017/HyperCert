# Scope and exclusions

## Included

- The current core HyperCert certificate and witness data structures.
- Exact continuous-time capacity verification by event sweep.
- Robust occupancy projection support.
- Continuous geometric-separation checking.
- Conflict-hypergraph and distributed local-update support required by the planner.
- The current safe-anytime certificate-feedback planner and its direct import dependencies.
- A minimal public example and smoke tests.

## Deliberately excluded

- The full development repository and Git history.
- Historical prototypes and superseded algorithms.
- Internal audit scripts, reviewer-response utilities, manuscript-editing scripts, and Word files.
- Full experiment launchers, multiprocessing orchestration, machine-specific paths, logs, caches, and intermediate artifacts.
- Complete raw seed-level result directories and large generated figures.
- External baseline implementations and calibration workflows, including the corridor-adapted UTFM experiment pipeline.
- Private or unpublished exploratory tests.

These exclusions implement the authors' request to publish the principal method without releasing the complete internal codebase. Claims about manuscript results should continue to refer to the audited manuscript and retained experimental archive.
