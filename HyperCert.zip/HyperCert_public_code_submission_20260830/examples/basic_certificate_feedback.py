"""Minimal continuous-capacity certificate and witness example."""

from __future__ import annotations

import json
from types import SimpleNamespace

import numpy as np

from certificate import (
    ContinuousCapacityVerifier,
    OccupancyInterval,
    ResourceCertificate,
)
from hypercert import CertificateFailureType, evaluate_certificate


def make_interval(uav_id: str, trajectory_id: str, start: float, end: float) -> OccupancyInterval:
    return OccupancyInterval(
        uav_id=uav_id,
        trajectory_id=trajectory_id,
        resource_id="crossing_node",
        t_enter_nominal=start,
        t_exit_nominal=end,
        t_enter_robust=start - 0.25,
        t_exit_robust=end + 0.25,
        entry_position=np.asarray([0.0, 0.0, 0.0]),
        exit_position=np.asarray([10.0, 0.0, 0.0]),
        spatial_margin_m=1.0,
        temporal_margin_s=0.25,
    )


def make_certificate(interval: OccupancyInterval) -> ResourceCertificate:
    return ResourceCertificate(
        certificate_id=f"cert-{interval.uav_id}",
        uav_id=interval.uav_id,
        trajectory_id=interval.trajectory_id,
        route_id="route-0",
        resource_intervals=(interval,),
        creation_time=0.0,
        snapshot_version=0,
        certificate_version=1,
        valid_from=0.0,
        valid_until=60.0,
        state="tentative",
    )


def main() -> None:
    first = make_interval("uav-1", "traj-1", 2.0, 5.0)
    second = make_interval("uav-2", "traj-2", 4.0, 7.0)
    verification = ContinuousCapacityVerifier({"crossing_node": 1}).verify((first, second))

    projection = SimpleNamespace(
        verification=verification,
        existing_certificates=(make_certificate(first),),
        candidate_certificates=(make_certificate(second),),
        projection_errors=(),
    )
    evaluation = evaluate_certificate("candidate-demo", projection)

    assert not evaluation.fully_certified
    assert evaluation.failure_types == (CertificateFailureType.RESOURCE_OVERLOAD,)
    assert evaluation.resource_witnesses[0].responsible_uav_ids == ("uav-1", "uav-2")
    print(json.dumps(evaluation.to_json_dict(), indent=2))


if __name__ == "__main__":
    main()
