from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from time import time
from typing import Any

from .resource_certificate import CertificateAuditRecord, ResourceCertificate


@dataclass
class CertificateAuditor:
    records: list[CertificateAuditRecord] = field(default_factory=list)

    def record(
        self,
        certificate: ResourceCertificate,
        action: str,
        reason: str,
        verifier_result: dict[str, Any],
        old_version: int | None = None,
        new_version: int | None = None,
    ) -> CertificateAuditRecord:
        rec = CertificateAuditRecord(
            timestamp=time(),
            certificate_id=certificate.certificate_id,
            action=action,
            old_version=certificate.certificate_version if old_version is None else old_version,
            new_version=certificate.certificate_version if new_version is None else new_version,
            reason=reason,
            affected_resources=tuple(sorted({i.resource_id for i in certificate.resource_intervals})),
            verifier_result=verifier_result,
        )
        self.records.append(rec)
        return rec

    def write_jsonl(self, path: str | Path) -> None:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("w", encoding="utf-8") as f:
            for rec in self.records:
                f.write(json.dumps(rec.to_json_dict(), sort_keys=True) + "\n")
