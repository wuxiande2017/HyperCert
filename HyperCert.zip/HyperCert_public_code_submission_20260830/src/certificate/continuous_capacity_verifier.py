from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from typing import Iterable

import numpy as np

from .occupancy_interval import OccupancyInterval


@dataclass(frozen=True)
class OverloadEpisode:
    resource_id: str
    t_start: float
    t_end: float
    capacity: int
    occupancy: int
    excess_occupancy: int
    responsible_certificate_ids: tuple[str, ...]

    @property
    def duration_s(self) -> float:
        return max(0.0, self.t_end - self.t_start)

    @property
    def integral_uav_s(self) -> float:
        return self.excess_occupancy * self.duration_s


@dataclass(frozen=True)
class ContinuousVerificationResult:
    is_safe: bool
    maximum_occupancy: dict[str, int]
    excess_occupancy: float
    overload_episodes: tuple[OverloadEpisode, ...]
    overload_duration_s: float
    overload_integral_uav_s: float
    responsible_certificate_ids: tuple[str, ...]
    minimal_conflicting_certificate_subset: tuple[str, ...]

    def to_json_dict(self) -> dict:
        return {
            "is_safe": self.is_safe,
            "maximum_occupancy": dict(self.maximum_occupancy),
            "excess_occupancy": float(self.excess_occupancy),
            "overload_episodes": [
                {
                    "resource_id": e.resource_id,
                    "t_start": float(e.t_start),
                    "t_end": float(e.t_end),
                    "capacity": int(e.capacity),
                    "occupancy": int(e.occupancy),
                    "excess_occupancy": int(e.excess_occupancy),
                    "responsible_certificate_ids": list(e.responsible_certificate_ids),
                }
                for e in self.overload_episodes
            ],
            "overload_duration_s": float(self.overload_duration_s),
            "overload_integral_uav_s": float(self.overload_integral_uav_s),
            "responsible_certificate_ids": list(self.responsible_certificate_ids),
            "minimal_conflicting_certificate_subset": list(self.minimal_conflicting_certificate_subset),
        }


class ContinuousCapacityVerifier:
    def __init__(self, capacities: dict[str, int]) -> None:
        self.capacities = {str(k): max(1, int(v)) for k, v in capacities.items()}

    def verify(self, intervals: Iterable[OccupancyInterval]) -> ContinuousVerificationResult:
        by_resource: dict[str, list[OccupancyInterval]] = {}
        for interval in intervals:
            by_resource.setdefault(interval.resource_id, []).append(interval)
        maximum: dict[str, int] = {}
        episodes: list[OverloadEpisode] = []
        for resource_id, resource_intervals in by_resource.items():
            cap = self.capacities.get(resource_id, 1)
            for start, end, active in _sweep(resource_intervals):
                occ = len({interval.trajectory_id for interval in active})
                maximum[resource_id] = max(maximum.get(resource_id, 0), occ)
                if end > start and occ > cap:
                    cert_ids = tuple(sorted({i.trajectory_id for i in active}))
                    episodes.append(
                        OverloadEpisode(
                            resource_id=resource_id,
                            t_start=start,
                            t_end=end,
                            capacity=cap,
                            occupancy=occ,
                            excess_occupancy=occ - cap,
                            responsible_certificate_ids=cert_ids,
                        )
                    )
        responsible = tuple(sorted({cid for e in episodes for cid in e.responsible_certificate_ids}))
        return ContinuousVerificationResult(
            is_safe=not episodes,
            maximum_occupancy=maximum,
            excess_occupancy=float(sum(e.excess_occupancy for e in episodes)),
            overload_episodes=tuple(episodes),
            overload_duration_s=float(sum(e.duration_s for e in episodes)),
            overload_integral_uav_s=float(sum(e.integral_uav_s for e in episodes)),
            responsible_certificate_ids=responsible,
            minimal_conflicting_certificate_subset=_minimal_subset(episodes),
        )

    def simulation_cross_check(self, intervals: Iterable[OccupancyInterval], dt: float = 0.01) -> ContinuousVerificationResult:
        intervals = tuple(intervals)
        if not intervals:
            return self.verify(intervals)
        t0 = min(i.t_enter_robust for i in intervals)
        t1 = max(i.t_exit_robust for i in intervals)
        sampled: list[OverloadEpisode] = []
        maximum: dict[str, int] = {}
        resources = sorted({i.resource_id for i in intervals})
        for resource_id in resources:
            cap = self.capacities.get(resource_id, 1)
            resource_intervals = [i for i in intervals if i.resource_id == resource_id]
            in_episode = False
            episode_start = t0
            episode_occ = 0
            episode_ids: tuple[str, ...] = tuple()
            for t in np.arange(t0, t1 + dt, dt):
                active = [i for i in resource_intervals if i.t_enter_robust <= t < i.t_exit_robust]
                occ = len({interval.trajectory_id for interval in active})
                maximum[resource_id] = max(maximum.get(resource_id, 0), occ)
                if occ > cap and not in_episode:
                    in_episode = True
                    episode_start = float(t)
                    episode_occ = occ
                    episode_ids = tuple(sorted({i.trajectory_id for i in active}))
                elif occ <= cap and in_episode:
                    sampled.append(OverloadEpisode(resource_id, episode_start, float(t), cap, episode_occ, episode_occ - cap, episode_ids))
                    in_episode = False
            if in_episode:
                sampled.append(OverloadEpisode(resource_id, episode_start, t1, cap, episode_occ, episode_occ - cap, episode_ids))
        responsible = tuple(sorted({cid for e in sampled for cid in e.responsible_certificate_ids}))
        return ContinuousVerificationResult(
            is_safe=not sampled,
            maximum_occupancy=maximum,
            excess_occupancy=float(sum(e.excess_occupancy for e in sampled)),
            overload_episodes=tuple(sampled),
            overload_duration_s=float(sum(e.duration_s for e in sampled)),
            overload_integral_uav_s=float(sum(e.integral_uav_s for e in sampled)),
            responsible_certificate_ids=responsible,
            minimal_conflicting_certificate_subset=_minimal_subset(sampled),
        )


def _sweep(intervals: list[OccupancyInterval]) -> list[tuple[float, float, tuple[OccupancyInterval, ...]]]:
    events: list[tuple[float, int, OccupancyInterval]] = []
    for interval in intervals:
        events.append((interval.t_enter_robust, 1, interval))
        events.append((interval.t_exit_robust, -1, interval))
    events.sort(key=lambda item: (item[0], item[1]))
    active: list[OccupancyInterval] = []
    prev: float | None = None
    segments: list[tuple[float, float, tuple[OccupancyInterval, ...]]] = []
    idx = 0
    while idx < len(events):
        t = events[idx][0]
        if prev is not None and t > prev:
            segments.append((prev, t, tuple(active)))
        while idx < len(events) and events[idx][0] == t:
            _, delta, interval = events[idx]
            if delta < 0:
                active = [item for item in active if item is not interval]
            else:
                active.append(interval)
            idx += 1
        prev = t
    return segments


def _minimal_subset(episodes: list[OverloadEpisode]) -> tuple[str, ...]:
    if not episodes:
        return tuple()
    first = episodes[0]
    ids = first.responsible_certificate_ids
    need = first.capacity + 1
    if len(ids) <= need:
        return ids
    return tuple(next(combinations(ids, need)))
