from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable

import numpy as np
import math

from models.uncertainty_model import UncertaintyModel

from .occupancy_interval import OccupancyInterval


@dataclass(frozen=True)
class ContinuousResource:
    resource_id: str
    contains: Callable[[np.ndarray, float], bool]
    corridor_polytope_id: str = ""
    kind: str = "generic"
    segment_intervals: Callable[[np.ndarray, np.ndarray, float, float], list[tuple[float, float]]] | None = None
    segment_intervals_with_margin: Callable[
        [np.ndarray, np.ndarray, float, float, float],
        list[tuple[float, float]],
    ] | None = None


@dataclass(frozen=True)
class SphericalResource:
    resource_id: str
    center: np.ndarray
    radius_m: float
    kind: str = "node"

    def as_resource(self) -> ContinuousResource:
        center = np.asarray(self.center, dtype=float)
        radius = float(self.radius_m)
        return ContinuousResource(
            resource_id=self.resource_id,
            kind=self.kind,
            contains=lambda p, _t: float(np.linalg.norm(np.asarray(p, dtype=float) - center)) <= radius + 1e-9,
            segment_intervals=lambda p0, p1, t0, t1: _sphere_segment_intervals(
                p0, p1, t0, t1, center, radius + 1e-9
            ),
            segment_intervals_with_margin=lambda p0, p1, t0, t1, margin: _sphere_segment_intervals(
                p0,
                p1,
                t0,
                t1,
                center,
                radius + max(0.0, float(margin)) + 1e-9,
            ),
        )


@dataclass(frozen=True)
class BoxResource:
    resource_id: str
    lower: np.ndarray
    upper: np.ndarray
    kind: str = "edge"

    def as_resource(self) -> ContinuousResource:
        lo = np.asarray(self.lower, dtype=float)
        hi = np.asarray(self.upper, dtype=float)
        return ContinuousResource(
            resource_id=self.resource_id,
            kind=self.kind,
            contains=lambda p, _t: bool(np.all(np.asarray(p, dtype=float) >= lo - 1e-9) and np.all(np.asarray(p, dtype=float) <= hi + 1e-9)),
            segment_intervals=lambda p0, p1, t0, t1: _box_segment_intervals(
                p0, p1, t0, t1, lo - 1e-9, hi + 1e-9
            ),
            segment_intervals_with_margin=lambda p0, p1, t0, t1, margin: _box_segment_intervals(
                p0,
                p1,
                t0,
                t1,
                lo - max(0.0, float(margin)) - 1e-9,
                hi + max(0.0, float(margin)) + 1e-9,
            ),
        )


@dataclass(frozen=True)
class PolylineTubeResource:
    resource_id: str
    centerline: np.ndarray
    radius_m: float
    sample_spacing_m: float = 5.0
    kind: str = "edge"

    def as_resource(self) -> ContinuousResource:
        centerline = np.asarray(self.centerline, dtype=float)
        if (
            centerline.ndim != 2
            or centerline.shape[1] != 3
            or len(centerline) < 2
        ):
            raise ValueError("polyline tube centerline must have shape (N, 3)")
        radius = float(self.radius_m)
        spacing = float(self.sample_spacing_m)
        if radius <= 0.0 or spacing <= 0.0:
            raise ValueError("polyline tube radius and spacing must be positive")
        centers, maximum_spacing = _polyline_cover_centers(centerline, spacing)

        def intervals(
            p0: np.ndarray,
            p1: np.ndarray,
            t0: float,
            t1: float,
            margin: float,
        ) -> list[tuple[float, float]]:
            expanded_radius = radius + max(0.0, float(margin))
            cover_radius = math.sqrt(
                expanded_radius * expanded_radius
                + 0.25 * maximum_spacing * maximum_spacing
            )
            visits = [
                interval
                for center in centers
                for interval in _sphere_segment_intervals(
                    p0,
                    p1,
                    t0,
                    t1,
                    center,
                    cover_radius + 1e-9,
                )
            ]
            return _merge_visits(visits, tolerance=1e-12)

        return ContinuousResource(
            resource_id=self.resource_id,
            kind=self.kind,
            contains=lambda p, _t: (
                _distance_to_polyline(np.asarray(p, dtype=float), centerline)
                <= radius + 1e-9
            ),
            segment_intervals=lambda p0, p1, t0, t1: intervals(
                p0,
                p1,
                t0,
                t1,
                0.0,
            ),
            segment_intervals_with_margin=intervals,
        )


class ContinuousOccupancyExtractor:
    def __init__(
        self,
        uncertainty_model: UncertaintyModel | None = None,
        max_subdivision_depth: int = 20,
        min_interval_s: float = 1e-4,
        subdivision_tolerance_s: float | None = None,
        bisection_tolerance_s: float = 1e-6,
    ) -> None:
        if max_subdivision_depth <= 0:
            raise ValueError("max_subdivision_depth must be positive")
        if min_interval_s <= 0.0 or bisection_tolerance_s <= 0.0:
            raise ValueError("occupancy extraction tolerances must be positive")
        self.uncertainty_model = uncertainty_model or UncertaintyModel()
        self.max_subdivision_depth = max_subdivision_depth
        self.min_interval_s = min_interval_s
        self.subdivision_tolerance_s = float(subdivision_tolerance_s if subdivision_tolerance_s is not None else min_interval_s)
        self.bisection_tolerance_s = float(bisection_tolerance_s)
        if self.subdivision_tolerance_s <= 0.0:
            raise ValueError("subdivision_tolerance_s must be positive")

    def extract(
        self,
        trajectory: np.ndarray,
        resources: Iterable[ContinuousResource],
        uav_id: str,
        trajectory_id: str,
    ) -> tuple[OccupancyInterval, ...]:
        trajectory = np.asarray(trajectory, dtype=float)
        if trajectory.ndim != 2 or trajectory.shape[1] < 4:
            raise ValueError("trajectory must be an N x >=4 array containing time and xyz")
        if not np.all(np.isfinite(trajectory[:, :4])):
            raise ValueError("trajectory time and position values must be finite")
        if np.any(np.diff(trajectory[:, 0]) < 0.0):
            raise ValueError("Trajectory times must be nondecreasing")
        if len(trajectory) < 2:
            return tuple()
        intervals: list[OccupancyInterval] = []
        resources = tuple(resources)
        for resource in resources:
            visits: list[tuple[float, float]] = []
            for a, b in zip(trajectory[:-1], trajectory[1:]):
                visits.extend(self._segment_intervals(a, b, resource))
            for enter, exit_t in _merge_visits(visits, tolerance=self.min_interval_s):
                enter = _round_earlier(enter, self.bisection_tolerance_s)
                exit_t = _round_later(exit_t, self.bisection_tolerance_s)
                entry = _interp_position(trajectory, enter)
                exit_pos = _interp_position(trajectory, exit_t)
                speed = _mean_speed(trajectory, enter, exit_t)
                bounds = self.uncertainty_model.bounds_for_resource(resource.resource_id, speed)
                intervals.append(
                    OccupancyInterval(
                        uav_id=uav_id,
                        trajectory_id=trajectory_id,
                        resource_id=resource.resource_id,
                        t_enter_nominal=float(enter),
                        t_exit_nominal=float(exit_t),
                        t_enter_robust=float(enter - bounds.epsilon_early_s),
                        t_exit_robust=float(exit_t + bounds.epsilon_late_s),
                        entry_position=entry,
                        exit_position=exit_pos,
                        spatial_margin_m=bounds.spatial_margin_m,
                        temporal_margin_s=max(bounds.epsilon_early_s, bounds.epsilon_late_s),
                    )
                )
        return tuple(sorted(intervals, key=lambda item: (item.resource_id, item.t_enter_nominal)))

    def _segment_intervals(
        self,
        row_a: np.ndarray,
        row_b: np.ndarray,
        resource: ContinuousResource,
    ) -> list[tuple[float, float]]:
        t0, t1 = float(row_a[0]), float(row_b[0])
        if t1 < t0:
            raise ValueError("Trajectory times must be nondecreasing")
        if t1 == t0:
            p = np.asarray(row_a[1:4], dtype=float)
            return [(t0, t1)] if resource.contains(p, t0) else []

        if resource.segment_intervals is not None:
            return resource.segment_intervals(
                np.asarray(row_a[1:4], dtype=float),
                np.asarray(row_b[1:4], dtype=float),
                t0,
                t1,
            )

        def inside(t: float) -> bool:
            alpha = (t - t0) / max(t1 - t0, 1e-12)
            p = row_a[1:4] + (row_b[1:4] - row_a[1:4]) * alpha
            return bool(resource.contains(np.asarray(p, dtype=float), t))

        samples = self._adaptive_samples(t0, t1, inside)
        states = [inside(t) for t in samples]
        out: list[tuple[float, float]] = []
        open_start: float | None = samples[0] if states[0] else None
        for idx in range(1, len(samples)):
            prev_t, curr_t = samples[idx - 1], samples[idx]
            prev_state, curr_state = states[idx - 1], states[idx]
            if prev_state == curr_state:
                continue
            crossing = _bisect_transition(inside, prev_t, curr_t, curr_state, self.bisection_tolerance_s)
            if curr_state:
                open_start = crossing
            elif open_start is not None:
                out.append((open_start, crossing))
                open_start = None
        if open_start is not None:
            out.append((open_start, samples[-1]))
        return [(a, b) for a, b in out if b >= a]

    def _adaptive_samples(self, t0: float, t1: float, inside: Callable[[float], bool]) -> list[float]:
        points = {t0, t1}

        def recurse(a: float, b: float, depth: int) -> None:
            if depth >= self.max_subdivision_depth or b - a <= self.subdivision_tolerance_s:
                return
            mid = 0.5 * (a + b)
            points.add(mid)
            left = inside(a)
            middle = inside(mid)
            right = inside(b)
            # Continue if a transition is visible, or if both endpoints are
            # outside but the midpoint catches a between-sample traversal.
            if left != middle or middle != right or (not left and middle and not right):
                recurse(a, mid, depth + 1)
                recurse(mid, b, depth + 1)

        recurse(t0, t1, 0)
        return sorted(points)


def _bisect_transition(inside: Callable[[float], bool], lo: float, hi: float, target_state: bool, tolerance_s: float = 1e-6) -> float:
    for _ in range(64):
        if hi - lo <= tolerance_s:
            break
        mid = 0.5 * (lo + hi)
        if inside(mid) == target_state:
            hi = mid
        else:
            lo = mid
    return hi


def _round_earlier(t: float, quantum_s: float) -> float:
    q = max(float(quantum_s), 1e-12)
    return math.floor(float(t) / q) * q


def _round_later(t: float, quantum_s: float) -> float:
    q = max(float(quantum_s), 1e-12)
    return math.ceil(float(t) / q) * q


def _merge_visits(visits: list[tuple[float, float]], tolerance: float) -> list[tuple[float, float]]:
    if not visits:
        return []
    visits = sorted(visits)
    merged = [visits[0]]
    for enter, exit_t in visits[1:]:
        prev_enter, prev_exit = merged[-1]
        if enter <= prev_exit + tolerance:
            merged[-1] = (prev_enter, max(prev_exit, exit_t))
        else:
            merged.append((enter, exit_t))
    return merged


def _interp_position(trajectory: np.ndarray, t: float) -> np.ndarray:
    return np.asarray([np.interp(t, trajectory[:, 0], trajectory[:, dim]) for dim in (1, 2, 3)], dtype=float)


def _mean_speed(trajectory: np.ndarray, enter: float, exit_t: float) -> float:
    if exit_t <= enter:
        return 0.0
    p0 = _interp_position(trajectory, enter)
    p1 = _interp_position(trajectory, exit_t)
    return float(np.linalg.norm(p1 - p0) / max(exit_t - enter, 1e-9))


def _sphere_segment_intervals(
    p0: np.ndarray,
    p1: np.ndarray,
    t0: float,
    t1: float,
    center: np.ndarray,
    radius: float,
) -> list[tuple[float, float]]:
    start = np.asarray(p0, dtype=float) - center
    direction = np.asarray(p1, dtype=float) - np.asarray(p0, dtype=float)
    a = float(np.dot(direction, direction))
    c = float(np.dot(start, start) - radius * radius)
    if a <= 1e-24:
        return [(t0, t1)] if c <= 0.0 else []
    b = 2.0 * float(np.dot(start, direction))
    discriminant = b * b - 4.0 * a * c
    tolerance = 1e-12 * max(1.0, b * b, abs(4.0 * a * c))
    if discriminant < -tolerance:
        return []
    root = math.sqrt(max(0.0, discriminant))
    alpha_enter = (-b - root) / (2.0 * a)
    alpha_exit = (-b + root) / (2.0 * a)
    lo = max(0.0, min(alpha_enter, alpha_exit))
    hi = min(1.0, max(alpha_enter, alpha_exit))
    if hi < lo:
        return []
    duration = t1 - t0
    return [(t0 + lo * duration, t0 + hi * duration)]


def _box_segment_intervals(
    p0: np.ndarray,
    p1: np.ndarray,
    t0: float,
    t1: float,
    lower: np.ndarray,
    upper: np.ndarray,
) -> list[tuple[float, float]]:
    start = np.asarray(p0, dtype=float)
    direction = np.asarray(p1, dtype=float) - start
    alpha_lo = 0.0
    alpha_hi = 1.0
    for dimension in range(3):
        if abs(direction[dimension]) <= 1e-15:
            if start[dimension] < lower[dimension] or start[dimension] > upper[dimension]:
                return []
            continue
        left = (lower[dimension] - start[dimension]) / direction[dimension]
        right = (upper[dimension] - start[dimension]) / direction[dimension]
        alpha_lo = max(alpha_lo, min(left, right))
        alpha_hi = min(alpha_hi, max(left, right))
        if alpha_hi < alpha_lo:
            return []
    duration = t1 - t0
    return [(t0 + alpha_lo * duration, t0 + alpha_hi * duration)]


def _polyline_cover_centers(
    centerline: np.ndarray,
    maximum_spacing_m: float,
) -> tuple[np.ndarray, float]:
    centers: list[np.ndarray] = []
    actual_maximum_spacing = 0.0
    for start, end in zip(centerline[:-1], centerline[1:]):
        length = float(np.linalg.norm(end - start))
        subdivisions = max(1, int(math.ceil(length / maximum_spacing_m)))
        actual_spacing = length / subdivisions
        actual_maximum_spacing = max(actual_maximum_spacing, actual_spacing)
        for index in range(subdivisions + 1):
            point = start + (end - start) * (index / subdivisions)
            if not centers or np.linalg.norm(point - centers[-1]) > 1e-12:
                centers.append(point)
    return np.asarray(centers), actual_maximum_spacing


def _distance_to_polyline(point: np.ndarray, centerline: np.ndarray) -> float:
    distances = []
    for start, end in zip(centerline[:-1], centerline[1:]):
        direction = end - start
        denominator = float(np.dot(direction, direction))
        if denominator <= 1e-24:
            projection = start
        else:
            alpha = float(
                np.clip(
                    np.dot(point - start, direction) / denominator,
                    0.0,
                    1.0,
                )
            )
            projection = start + alpha * direction
        distances.append(float(np.linalg.norm(point - projection)))
    return min(distances, default=float("inf"))
