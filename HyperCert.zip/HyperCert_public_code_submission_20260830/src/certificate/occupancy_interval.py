from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


def _array3(value: Any) -> np.ndarray:
    arr = np.asarray(value, dtype=float)
    if arr.shape != (3,):
        raise ValueError(f"Expected a 3-vector, got shape {arr.shape}")
    return arr


@dataclass(frozen=True)
class OccupancyInterval:
    uav_id: str
    trajectory_id: str
    resource_id: str
    t_enter_nominal: float
    t_exit_nominal: float
    t_enter_robust: float
    t_exit_robust: float
    entry_position: np.ndarray
    exit_position: np.ndarray
    spatial_margin_m: float
    temporal_margin_s: float

    def __post_init__(self) -> None:
        object.__setattr__(self, "uav_id", str(self.uav_id))
        object.__setattr__(self, "trajectory_id", str(self.trajectory_id))
        object.__setattr__(self, "resource_id", str(self.resource_id))
        object.__setattr__(self, "entry_position", _array3(self.entry_position))
        object.__setattr__(self, "exit_position", _array3(self.exit_position))
        if self.t_exit_nominal < self.t_enter_nominal:
            raise ValueError("Nominal exit time must be >= nominal entry time")
        if self.t_exit_robust < self.t_enter_robust:
            raise ValueError("Robust exit time must be >= robust entry time")

    @property
    def duration_nominal_s(self) -> float:
        return max(0.0, float(self.t_exit_nominal - self.t_enter_nominal))

    @property
    def duration_robust_s(self) -> float:
        return max(0.0, float(self.t_exit_robust - self.t_enter_robust))

    def overlaps(self, other: "OccupancyInterval") -> bool:
        return self.resource_id == other.resource_id and self.t_enter_robust < other.t_exit_robust and other.t_enter_robust < self.t_exit_robust

    def to_json_dict(self) -> dict[str, Any]:
        return {
            "uav_id": self.uav_id,
            "trajectory_id": self.trajectory_id,
            "resource_id": self.resource_id,
            "t_enter_nominal": float(self.t_enter_nominal),
            "t_exit_nominal": float(self.t_exit_nominal),
            "t_enter_robust": float(self.t_enter_robust),
            "t_exit_robust": float(self.t_exit_robust),
            "entry_position": [float(x) for x in self.entry_position],
            "exit_position": [float(x) for x in self.exit_position],
            "spatial_margin_m": float(self.spatial_margin_m),
            "temporal_margin_s": float(self.temporal_margin_s),
        }

    @classmethod
    def from_json_dict(cls, data: dict[str, Any]) -> "OccupancyInterval":
        return cls(
            uav_id=data["uav_id"],
            trajectory_id=data["trajectory_id"],
            resource_id=data["resource_id"],
            t_enter_nominal=float(data["t_enter_nominal"]),
            t_exit_nominal=float(data["t_exit_nominal"]),
            t_enter_robust=float(data["t_enter_robust"]),
            t_exit_robust=float(data["t_exit_robust"]),
            entry_position=np.asarray(data["entry_position"], dtype=float),
            exit_position=np.asarray(data["exit_position"], dtype=float),
            spatial_margin_m=float(data["spatial_margin_m"]),
            temporal_margin_s=float(data["temporal_margin_s"]),
        )
