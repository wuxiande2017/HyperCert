from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

from .occupancy_interval import OccupancyInterval

CertificateState = Literal["tentative", "committed", "executing", "expired", "revoked"]


@dataclass(frozen=True)
class ResourceCertificate:
    certificate_id: str
    uav_id: str
    trajectory_id: str
    route_id: str
    resource_intervals: tuple[OccupancyInterval, ...]
    creation_time: float
    snapshot_version: int
    certificate_version: int
    valid_from: float
    valid_until: float
    state: CertificateState

    def __post_init__(self) -> None:
        object.__setattr__(self, "resource_intervals", tuple(self.resource_intervals))
        if self.state not in {"tentative", "committed", "executing", "expired", "revoked"}:
            raise ValueError(f"Invalid certificate state: {self.state}")

    def with_state(self, state: CertificateState, version_increment: int = 1) -> "ResourceCertificate":
        return ResourceCertificate(
            certificate_id=self.certificate_id,
            uav_id=self.uav_id,
            trajectory_id=self.trajectory_id,
            route_id=self.route_id,
            resource_intervals=self.resource_intervals,
            creation_time=self.creation_time,
            snapshot_version=self.snapshot_version,
            certificate_version=self.certificate_version + version_increment,
            valid_from=self.valid_from,
            valid_until=self.valid_until,
            state=state,
        )

    def to_json_dict(self) -> dict[str, Any]:
        return {
            "certificate_id": self.certificate_id,
            "uav_id": self.uav_id,
            "trajectory_id": self.trajectory_id,
            "route_id": self.route_id,
            "resource_intervals": [i.to_json_dict() for i in self.resource_intervals],
            "creation_time": float(self.creation_time),
            "snapshot_version": int(self.snapshot_version),
            "certificate_version": int(self.certificate_version),
            "valid_from": float(self.valid_from),
            "valid_until": float(self.valid_until),
            "state": self.state,
        }

    @classmethod
    def from_json_dict(cls, data: dict[str, Any]) -> "ResourceCertificate":
        return cls(
            certificate_id=str(data["certificate_id"]),
            uav_id=str(data["uav_id"]),
            trajectory_id=str(data["trajectory_id"]),
            route_id=str(data["route_id"]),
            resource_intervals=tuple(OccupancyInterval.from_json_dict(x) for x in data["resource_intervals"]),
            creation_time=float(data["creation_time"]),
            snapshot_version=int(data["snapshot_version"]),
            certificate_version=int(data["certificate_version"]),
            valid_from=float(data["valid_from"]),
            valid_until=float(data["valid_until"]),
            state=data["state"],
        )


@dataclass(frozen=True)
class CertificateAuditRecord:
    timestamp: float
    certificate_id: str
    action: str
    old_version: int
    new_version: int
    reason: str
    affected_resources: tuple[str, ...]
    verifier_result: dict[str, Any]

    def to_json_dict(self) -> dict[str, Any]:
        return {
            "timestamp": float(self.timestamp),
            "certificate_id": self.certificate_id,
            "action": self.action,
            "old_version": int(self.old_version),
            "new_version": int(self.new_version),
            "reason": self.reason,
            "affected_resources": list(self.affected_resources),
            "verifier_result": self.verifier_result,
        }

    @classmethod
    def from_json_dict(cls, data: dict[str, Any]) -> "CertificateAuditRecord":
        return cls(
            timestamp=float(data["timestamp"]),
            certificate_id=str(data["certificate_id"]),
            action=str(data["action"]),
            old_version=int(data["old_version"]),
            new_version=int(data["new_version"]),
            reason=str(data["reason"]),
            affected_resources=tuple(str(x) for x in data["affected_resources"]),
            verifier_result=dict(data["verifier_result"]),
        )
