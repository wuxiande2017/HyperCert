from __future__ import annotations

from dataclasses import dataclass, field
import heapq
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np


@dataclass
class CorridorNode:
    node_id: str
    kind: str
    position: np.ndarray
    capacity: int = 1
    service_time: float = 0.0
    priority_boost: float = 0.0


@dataclass
class CorridorEdge:
    edge_id: str
    start: str
    end: str
    centerline: List[np.ndarray]
    width: float
    h_min: float
    h_max: float
    capacity: int
    speed_limit: float
    closed_intervals: List[Tuple[float, float]] = field(default_factory=list)

    def is_open(self, t: float) -> bool:
        return all(not (a <= t <= b) for a, b in self.closed_intervals)

    @property
    def length(self) -> float:
        return float(sum(np.linalg.norm(b - a) for a, b in zip(self.centerline[:-1], self.centerline[1:])))


class CorridorGraph:
    def __init__(self) -> None:
        self.nodes: Dict[str, CorridorNode] = {}
        self.edges: Dict[str, CorridorEdge] = {}
        self.adjacency: Dict[str, List[Tuple[str, str, float]]] = {}

    def add_node(self, node: CorridorNode) -> None:
        self.nodes[node.node_id] = node
        self.adjacency.setdefault(node.node_id, [])

    def add_edge(self, edge: CorridorEdge) -> None:
        self.edges[edge.edge_id] = edge
        self.adjacency.setdefault(edge.start, []).append((edge.end, edge.edge_id, edge.length))
        self.adjacency.setdefault(edge.end, [])

    def shortest_edge_path(self, start: str, goal: str, t: float = 0.0) -> List[str]:
        queue: List[Tuple[float, str, List[str]]] = [(0.0, start, [])]
        best: Dict[str, float] = {start: 0.0}
        while queue:
            cost, node_id, path = heapq.heappop(queue)
            if node_id == goal:
                return path
            if cost > best.get(node_id, float("inf")):
                continue
            for nxt, edge_id, weight in self.adjacency.get(node_id, []):
                edge = self.edges[edge_id]
                if not edge.is_open(t):
                    continue
                new_cost = cost + weight
                if new_cost < best.get(nxt, float("inf")):
                    best[nxt] = new_cost
                    heapq.heappush(queue, (new_cost, nxt, path + [edge_id]))
        raise ValueError(f"No open route from {start} to {goal} at t={t}")

    def candidate_edge_paths(self, start: str, goal: str, t: float = 0.0, max_paths: int = 3) -> List[List[str]]:
        paths: List[Tuple[float, List[str]]] = []
        stack: List[Tuple[str, List[str], set[str], float]] = [(start, [], {start}, 0.0)]
        while stack and len(paths) < max_paths * 8:
            node_id, path, visited, cost = stack.pop()
            if node_id == goal:
                paths.append((cost, path))
                continue
            for nxt, edge_id, weight in sorted(self.adjacency.get(node_id, []), key=lambda item: item[2], reverse=True):
                edge = self.edges[edge_id]
                if nxt in visited or not edge.is_open(t):
                    continue
                stack.append((nxt, path + [edge_id], visited | {nxt}, cost + weight))
        paths.sort(key=lambda item: item[0])
        unique: List[List[str]] = []
        seen = set()
        for _, path in paths:
            key = tuple(path)
            if key not in seen:
                seen.add(key)
                unique.append(path)
            if len(unique) >= max_paths:
                break
        if unique:
            return unique
        return [self.shortest_edge_path(start, goal, t)]

    def outgoing_edges(self, node_id: str) -> Iterable[CorridorEdge]:
        for _, edge_id, _ in self.adjacency.get(node_id, []):
            yield self.edges[edge_id]

    def edge_centers(self, edge_path: List[str]) -> np.ndarray:
        pts: List[np.ndarray] = []
        for edge_id in edge_path:
            line = self.edges[edge_id].centerline
            pts.extend(line if not pts else line[1:])
        return np.asarray(pts, dtype=float)
