"""Curated public HyperCert implementation.

Only stable entry points included in the manuscript-facing public subset are
re-exported here. Import individual submodules for advanced components.
"""

from .certificate_feedback import (
    CertificateEvaluation,
    CertificateFailureType,
    GeometryConflictWitness,
    ResourceOverloadWitness,
    evaluate_certificate,
)
from .config import HyperCertConfig, HyperCertObjectiveWeights, HyperCertSolverSettings
from .decision_variables import ContinuousVariableLayout, UAVDecisionVariables

__all__ = [
    "CertificateEvaluation",
    "CertificateFailureType",
    "ContinuousVariableLayout",
    "GeometryConflictWitness",
    "HyperCertConfig",
    "HyperCertObjectiveWeights",
    "HyperCertSolverSettings",
    "ResourceOverloadWitness",
    "UAVDecisionVariables",
    "evaluate_certificate",
]
