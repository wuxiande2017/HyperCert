from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Iterable

from .certificate_feedback import CertificateFailureType


@dataclass(frozen=True)
class AcceptanceFunnel:
    abstract_scheduled: int
    resource_certificate_accepted: int
    geometry_certificate_accepted: int
    committed: int

    def __post_init__(self) -> None:
        counts = (
            self.abstract_scheduled,
            self.resource_certificate_accepted,
            self.geometry_certificate_accepted,
            self.committed,
        )
        if min(counts) < 0:
            raise ValueError("acceptance funnel counts must be nonnegative")
        if self.resource_certificate_accepted > self.abstract_scheduled:
            raise ValueError("resource acceptance cannot exceed abstract scheduling")
        if self.geometry_certificate_accepted > self.resource_certificate_accepted:
            raise ValueError("geometry acceptance cannot exceed resource acceptance")
        if self.committed > self.geometry_certificate_accepted:
            raise ValueError("commits cannot exceed geometry acceptance")

    @property
    def abstract_to_resource_certificate_retention(self) -> float:
        return self.resource_certificate_accepted / max(self.abstract_scheduled, 1)

    @property
    def resource_to_geometry_retention(self) -> float:
        return self.geometry_certificate_accepted / max(
            self.resource_certificate_accepted,
            1,
        )

    @property
    def end_to_end_retention(self) -> float:
        return self.committed / max(self.abstract_scheduled, 1)


@dataclass(frozen=True)
class CertificateFeedbackEvent:
    sequence: int
    stage: str
    uav_id: str
    attempt: int
    action: str
    candidate_fingerprint: str
    route_index: int
    departure_delay_s: float
    edge_travel_time_s: float
    holding_time_s: float
    accepted: bool
    fully_certified: bool
    failure_types: tuple[CertificateFailureType, ...]
    resource_witness_count: int
    geometry_witness_count: int
    responsible_uav_ids: tuple[str, ...]
    projection_runtime_s: float
    geometry_runtime_s: float
    cache_hits: int
    cache_misses: int
    feedback_information_mode: str = "structured"
    witness_resource_ids: tuple[str, ...] = ()
    witness_time_supports_s: tuple[tuple[float, float], ...] = ()
    witness_peak_excess: int = 0
    witness_overload_integral_uav_s: float = 0.0
    modified_uav_count: int = 1
    active_uav_count: int = 1

    def to_json_dict(self) -> dict[str, object]:
        data = asdict(self)
        data["failure_types"] = [failure.value for failure in self.failure_types]
        return data


@dataclass(frozen=True)
class PlannerRuntimeBreakdown:
    abstract_optimization_s: float
    resource_feedback_s: float
    geometry_feedback_s: float
    commit_s: float
    total_s: float

    def __post_init__(self) -> None:
        values = (
            self.abstract_optimization_s,
            self.resource_feedback_s,
            self.geometry_feedback_s,
            self.commit_s,
            self.total_s,
        )
        if min(values) < 0.0:
            raise ValueError("runtime components must be nonnegative")


@dataclass(frozen=True)
class FailureReasonCount:
    failure_type: CertificateFailureType
    event_count: int
    affected_uav_count: int


def summarize_failure_reasons(
    events: Iterable[CertificateFeedbackEvent],
) -> tuple[FailureReasonCount, ...]:
    event_counts = {failure: 0 for failure in CertificateFailureType}
    affected = {failure: set() for failure in CertificateFailureType}
    for event in events:
        for failure in set(event.failure_types):
            event_counts[failure] += 1
            affected[failure].add(event.uav_id)
    return tuple(
        FailureReasonCount(
            failure_type=failure,
            event_count=event_counts[failure],
            affected_uav_count=len(affected[failure]),
        )
        for failure in CertificateFailureType
        if event_counts[failure]
    )
