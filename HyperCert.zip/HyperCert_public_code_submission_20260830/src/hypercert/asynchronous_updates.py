from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .dual_variables import ResourceTimeDualVariables
from .message_model import OptimizationMessage


@dataclass(frozen=True)
class AsynchronousUpdateConfig:
    uav_update_period: int = 2
    resource_update_period: int = 1
    maximum_stale_iterations: int = 3
    maximum_communication_delay_iterations: int = 2

    def __post_init__(self) -> None:
        if min(self.uav_update_period, self.resource_update_period) <= 0:
            raise ValueError("asynchronous update periods must be positive")
        if min(self.maximum_stale_iterations, self.maximum_communication_delay_iterations) < 0:
            raise ValueError("staleness and delay bounds cannot be negative")


class DeterministicAsynchronousScheduler:
    def __init__(self, config: AsynchronousUpdateConfig) -> None:
        self.config = config

    def select_uavs(self, uav_ids: tuple[str, ...], iteration: int) -> tuple[str, ...]:
        ordered = tuple(sorted(uav_ids))
        return tuple(
            uav_id
            for index, uav_id in enumerate(ordered)
            if (iteration + index) % self.config.uav_update_period == 0
        )

    def select_resources(self, resource_ids: tuple[str, ...], iteration: int) -> tuple[str, ...]:
        if iteration % self.config.resource_update_period != 0:
            return tuple()
        return tuple(sorted(resource_ids))


class BoundedStaleDualStore:
    def __init__(
        self,
        uav_ids: tuple[str, ...],
        initial_duals: ResourceTimeDualVariables,
        maximum_stale_iterations: int,
    ) -> None:
        self.maximum_stale_iterations = maximum_stale_iterations
        self._time_grid = initial_duals.time_grid_s.copy()
        self._resource_ids = tuple(initial_duals.values)
        self._values: dict[tuple[str, str], np.ndarray] = {}
        self._source_iteration: dict[tuple[str, str], int] = {}
        for uav_id in uav_ids:
            for resource_id, values in initial_duals.values.items():
                self._values[(uav_id, resource_id)] = values.copy()
                self._source_iteration[(uav_id, resource_id)] = 0

    def apply(self, message: OptimizationMessage) -> None:
        if message.message_type != "dual_price":
            return
        uav_id = str(message.payload["uav_id"])
        resource_id = str(message.payload["resource_id"])
        values = np.asarray(message.payload["price"], dtype=float)
        if values.shape != self._time_grid.shape:
            raise ValueError("received dual-price shape does not match the local time grid")
        key = (uav_id, resource_id)
        if message.source_iteration >= self._source_iteration.get(key, -1):
            self._values[key] = values.copy()
            self._source_iteration[key] = message.source_iteration

    def duals_for_uav(
        self,
        uav_id: str,
        current_iteration: int,
        required_resource_ids: tuple[str, ...] | None = None,
    ) -> tuple[ResourceTimeDualVariables | None, tuple[str, ...]]:
        required = self._resource_ids if required_resource_ids is None else required_resource_ids
        stale = tuple(
            resource_id
            for resource_id in required
            if current_iteration - self._source_iteration[(uav_id, resource_id)]
            > self.maximum_stale_iterations
        )
        if stale:
            return None, stale
        return (
            ResourceTimeDualVariables(
                self._time_grid,
                {
                    resource_id: self._values[(uav_id, resource_id)].copy()
                    for resource_id in self._resource_ids
                },
            ),
            tuple(),
        )
