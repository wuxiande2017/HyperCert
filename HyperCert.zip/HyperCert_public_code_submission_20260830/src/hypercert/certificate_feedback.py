from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import TYPE_CHECKING, Mapping, Sequence

if TYPE_CHECKING:
    from .certificate_projection import CertificateProjectionResult
    from .geometric_separation import ContinuousSeparationResult


class CertificateFailureType(str, Enum):
    RESOURCE_OVERLOAD = "resource_overload"
    GEOMETRY_SEPARATION = "geometry_separation"
    TRACKING_TUBE = "tracking_tube"
    UNSUPPORTED_GEOMETRY = "unsupported_geometry"
    NUMERICAL_UNRESOLVED = "numerical_unresolved"
    VERSION_CONFLICT = "version_conflict"
    DEADLINE_EXCEEDED = "deadline_exceeded"


@dataclass(frozen=True)
class ResourceOverloadWitness:
    resource_id: str
    start_time_s: float
    end_time_s: float
    capacity: int
    peak_occupancy: int
    overload_integral_uav_s: float
    responsible_uav_ids: tuple[str, ...]
    visit_indices: Mapping[str, tuple[int, ...]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.end_time_s < self.start_time_s:
            raise ValueError("end_time_s must be >= start_time_s")
        if self.capacity < 1:
            raise ValueError("capacity must be positive")
        if self.peak_occupancy <= self.capacity:
            raise ValueError("witness must represent a true overload")
        if self.overload_integral_uav_s < 0.0:
            raise ValueError("overload integral must be nonnegative")
        responsible = tuple(sorted({str(value) for value in self.responsible_uav_ids}))
        if not responsible:
            raise ValueError("responsible_uav_ids cannot be empty")
        normalized_visits = {
            str(uav_id): tuple(sorted({int(index) for index in indices}))
            for uav_id, indices in self.visit_indices.items()
        }
        unknown = set(normalized_visits) - set(responsible)
        if unknown:
            raise ValueError(
                f"visit_indices contains non-responsible UAVs: {sorted(unknown)}"
            )
        object.__setattr__(self, "resource_id", str(self.resource_id))
        object.__setattr__(self, "responsible_uav_ids", responsible)
        object.__setattr__(
            self,
            "visit_indices",
            MappingProxyType(normalized_visits),
        )


@dataclass(frozen=True)
class GeometryConflictWitness:
    uav_i: str
    uav_j: str
    start_time_s: float
    end_time_s: float
    lower_bound_distance_m: float
    required_distance_m: float
    segment_i: int
    segment_j: int
    unresolved: bool = False

    def __post_init__(self) -> None:
        if self.end_time_s < self.start_time_s:
            raise ValueError("end_time_s must be >= start_time_s")
        if self.lower_bound_distance_m < 0.0:
            raise ValueError("lower_bound_distance_m must be nonnegative")
        if self.required_distance_m < 0.0:
            raise ValueError("required_distance_m must be nonnegative")
        if self.segment_i < 0 or self.segment_j < 0:
            raise ValueError("geometry witness segment indices must be nonnegative")
        object.__setattr__(self, "uav_i", str(self.uav_i))
        object.__setattr__(self, "uav_j", str(self.uav_j))


@dataclass(frozen=True)
class CertificateEvaluation:
    candidate_id: str
    exact_capacity_safe: bool
    geometry_safe: bool
    tracking_tube_safe: bool
    resource_witnesses: tuple[ResourceOverloadWitness, ...] = ()
    geometry_witnesses: tuple[GeometryConflictWitness, ...] = ()
    failure_types: tuple[CertificateFailureType, ...] = ()
    certificate_runtime_s: float = 0.0

    def __post_init__(self) -> None:
        if not self.candidate_id:
            raise ValueError("candidate_id cannot be empty")
        if self.certificate_runtime_s < 0.0:
            raise ValueError("certificate_runtime_s must be nonnegative")
        failures = tuple(dict.fromkeys(CertificateFailureType(value) for value in self.failure_types))
        object.__setattr__(self, "failure_types", failures)

    @property
    def fully_certified(self) -> bool:
        return (
            self.exact_capacity_safe
            and self.geometry_safe
            and self.tracking_tube_safe
            and not self.failure_types
        )

    @property
    def responsible_uav_ids(self) -> tuple[str, ...]:
        return tuple(
            sorted(
                {
                    uav_id
                    for witness in self.resource_witnesses
                    for uav_id in witness.responsible_uav_ids
                }
                | {
                    uav_id
                    for witness in self.geometry_witnesses
                    for uav_id in (witness.uav_i, witness.uav_j)
                }
            )
        )

    def to_json_dict(self) -> dict[str, object]:
        return {
            "candidate_id": self.candidate_id,
            "exact_capacity_safe": self.exact_capacity_safe,
            "geometry_safe": self.geometry_safe,
            "tracking_tube_safe": self.tracking_tube_safe,
            "resource_witnesses": [
                {
                    "resource_id": witness.resource_id,
                    "start_time_s": witness.start_time_s,
                    "end_time_s": witness.end_time_s,
                    "capacity": witness.capacity,
                    "peak_occupancy": witness.peak_occupancy,
                    "overload_integral_uav_s": (
                        witness.overload_integral_uav_s
                    ),
                    "responsible_uav_ids": list(
                        witness.responsible_uav_ids
                    ),
                    "visit_indices": {
                        uav_id: list(indices)
                        for uav_id, indices in witness.visit_indices.items()
                    },
                }
                for witness in self.resource_witnesses
            ],
            "geometry_witnesses": [
                asdict(witness) for witness in self.geometry_witnesses
            ],
            "failure_types": [
                failure.value for failure in self.failure_types
            ],
            "certificate_runtime_s": self.certificate_runtime_s,
            "fully_certified": self.fully_certified,
            "responsible_uav_ids": list(self.responsible_uav_ids),
        }


def evaluate_certificate(
    candidate_id: str,
    projection: CertificateProjectionResult,
    *,
    geometry: ContinuousSeparationResult | None = None,
    require_geometry: bool = False,
    tracking_tube_safe: bool = True,
    certificate_runtime_s: float = 0.0,
    additional_failures: Sequence[CertificateFailureType] = (),
) -> CertificateEvaluation:
    """Convert exact projectors into one typed feedback object.

    `require_geometry=True` is fail closed: omitting a geometric result becomes
    `UNSUPPORTED_GEOMETRY`, never an implicit safe result.
    """

    resource_witnesses = _resource_witnesses(projection)
    failures = list(additional_failures)
    exact_capacity_safe = bool(projection.verification.is_safe)
    if not exact_capacity_safe:
        failures.append(CertificateFailureType.RESOURCE_OVERLOAD)

    for error in projection.projection_errors:
        lowered = error.lower()
        if (
            "unsupported" in lowered
            or "missing resources" in lowered
            or "misses route resources" in lowered
        ):
            failures.append(CertificateFailureType.UNSUPPORTED_GEOMETRY)
        else:
            failures.append(CertificateFailureType.NUMERICAL_UNRESOLVED)

    geometry_witnesses: tuple[GeometryConflictWitness, ...] = tuple()
    if geometry is None:
        geometry_safe = not require_geometry
        if require_geometry:
            failures.append(CertificateFailureType.UNSUPPORTED_GEOMETRY)
    else:
        geometry_safe = bool(geometry.certified_safe)
        geometry_witnesses = _geometry_witnesses(geometry)
        if geometry.confirmed_violation_pairs:
            failures.append(CertificateFailureType.GEOMETRY_SEPARATION)
        if geometry.unresolved_pairs:
            failures.append(CertificateFailureType.NUMERICAL_UNRESOLVED)

    if not tracking_tube_safe:
        failures.append(CertificateFailureType.TRACKING_TUBE)

    return CertificateEvaluation(
        candidate_id=candidate_id,
        exact_capacity_safe=exact_capacity_safe and not projection.projection_errors,
        geometry_safe=geometry_safe,
        tracking_tube_safe=bool(tracking_tube_safe),
        resource_witnesses=resource_witnesses,
        geometry_witnesses=geometry_witnesses,
        failure_types=tuple(failures),
        certificate_runtime_s=float(certificate_runtime_s),
    )


def _resource_witnesses(
    projection: CertificateProjectionResult,
) -> tuple[ResourceOverloadWitness, ...]:
    certificates = projection.existing_certificates + projection.candidate_certificates
    trajectory_to_uav = {
        certificate.trajectory_id: certificate.uav_id for certificate in certificates
    }
    witnesses = []
    for episode in projection.verification.overload_episodes:
        responsible = tuple(
            sorted(
                {
                    trajectory_to_uav[trajectory_id]
                    for trajectory_id in episode.responsible_certificate_ids
                    if trajectory_id in trajectory_to_uav
                }
            )
        )
        visits: dict[str, list[int]] = {uav_id: [] for uav_id in responsible}
        for certificate in certificates:
            if certificate.uav_id not in visits:
                continue
            resource_visit_index = 0
            for interval in certificate.resource_intervals:
                if interval.resource_id != episode.resource_id:
                    continue
                if (
                    interval.t_enter_robust < episode.t_end
                    and episode.t_start < interval.t_exit_robust
                ):
                    visits[certificate.uav_id].append(resource_visit_index)
                resource_visit_index += 1
        witnesses.append(
            ResourceOverloadWitness(
                resource_id=episode.resource_id,
                start_time_s=float(episode.t_start),
                end_time_s=float(episode.t_end),
                capacity=int(episode.capacity),
                peak_occupancy=int(episode.occupancy),
                overload_integral_uav_s=float(episode.integral_uav_s),
                responsible_uav_ids=responsible,
                visit_indices={
                    uav_id: tuple(indices)
                    for uav_id, indices in visits.items()
                },
            )
        )
    return tuple(witnesses)


def _geometry_witnesses(
    geometry: ContinuousSeparationResult,
) -> tuple[GeometryConflictWitness, ...]:
    witnesses = []
    for pair in geometry.pairs:
        if pair.certified_safe:
            continue
        witnesses.append(
            GeometryConflictWitness(
                uav_i=pair.first_uav_id,
                uav_j=pair.second_uav_id,
                start_time_s=float(pair.critical_start_time_s),
                end_time_s=float(pair.critical_end_time_s),
                lower_bound_distance_m=float(pair.critical_lower_bound_distance_m),
                required_distance_m=float(pair.required_reference_separation_m),
                segment_i=int(pair.critical_first_segment),
                segment_j=int(pair.critical_second_segment),
                unresolved=not pair.confirmed_violation,
            )
        )
    return tuple(witnesses)
