from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, field, replace
import hashlib
from time import perf_counter
from typing import Callable, Mapping

import numpy as np

from certificate.continuous_capacity_verifier import (
    ContinuousCapacityVerifier,
    ContinuousVerificationResult,
)
from certificate.continuous_occupancy_extractor import (
    ContinuousOccupancyExtractor,
    ContinuousResource,
)
from certificate.resource_certificate import ResourceCertificate
from models.uncertainty_model import UncertaintyModel
from reservation.reservation_manager import ReservationCommitResult, ReservationManager
from reservation.reservation_snapshot import ReservationSnapshot

from .decision_variables import UAVDecisionVariables
from .closed_loop_validation import (
    MinimumSnapTrajectory,
    minimum_snap_from_hypercert_decision,
)
from .polynomial_occupancy import (
    ConservativePolynomialOccupancyExtractor,
    PolynomialEnclosureConfig,
)
from .problem_definition import HyperCertProblemDefinition


TrajectoryProvider = Callable[[int, UAVDecisionVariables], np.ndarray]
PolynomialTrajectoryProvider = Callable[
    [int, UAVDecisionVariables],
    MinimumSnapTrajectory,
]


@dataclass(frozen=True)
class CertificateProjectionConfig:
    maximum_subdivision_depth: int = 24
    subdivision_tolerance_s: float = 1e-4
    bisection_tolerance_s: float = 1e-6
    minimum_interval_s: float = 1e-4
    polynomial_spatial_tolerance_m: float = 1e-3
    polynomial_numerical_margin_m: float = 1e-9
    trajectory_model: str = "piecewise_linear"
    require_analytic_resource_intersection: bool = True
    require_route_resource_coverage: bool = True

    def __post_init__(self) -> None:
        if self.maximum_subdivision_depth <= 0:
            raise ValueError("maximum_subdivision_depth must be positive")
        if min(
            self.subdivision_tolerance_s,
            self.bisection_tolerance_s,
            self.minimum_interval_s,
            self.polynomial_spatial_tolerance_m,
        ) <= 0.0:
            raise ValueError("certificate projection tolerances must be positive")
        if self.polynomial_numerical_margin_m < 0.0:
            raise ValueError("polynomial_numerical_margin_m must be nonnegative")
        if self.trajectory_model not in {"piecewise_linear", "minimum_snap"}:
            raise ValueError(
                "trajectory_model must be 'piecewise_linear' or 'minimum_snap'"
            )


@dataclass(frozen=True)
class ProjectionConflictHyperedge:
    hyperedge_id: str
    resource_id: str
    time_support_s: tuple[float, float]
    capacity: int
    occupancy: int
    excess_occupancy: int
    participating_uav_ids: tuple[str, ...]
    participating_trajectory_ids: tuple[str, ...]


@dataclass(frozen=True)
class CertificateProjectionResult:
    decision_fingerprint: str
    snapshot_version: int
    candidate_certificates: tuple[ResourceCertificate, ...]
    existing_certificates: tuple[ResourceCertificate, ...]
    trajectories: dict[str, np.ndarray]
    verification: ContinuousVerificationResult
    conflict_hyperedges: tuple[ProjectionConflictHyperedge, ...]
    projection_errors: tuple[str, ...]
    trajectory_enclosure_stats: dict[str, object] = field(default_factory=dict)
    polynomial_trajectories: dict[str, MinimumSnapTrajectory] = field(
        default_factory=dict
    )
    projection_runtime_s: float = 0.0
    trajectory_cache_hits: int = 0
    trajectory_cache_misses: int = 0

    @property
    def is_safe(self) -> bool:
        return self.verification.is_safe and not self.projection_errors

    @property
    def overload_integral_uav_s(self) -> float:
        return self.verification.overload_integral_uav_s


@dataclass(frozen=True)
class ProjectionCacheStats:
    hits: int
    misses: int
    evictions: int
    entries: int


@dataclass(frozen=True)
class _TrajectoryProjectionCacheEntry:
    trajectory: np.ndarray
    intervals: tuple[object, ...]
    enclosure_stats: object | None
    polynomial_trajectory: MinimumSnapTrajectory | None


class ExactRobustCertificateProjector:
    """Exact/conservative post-optimization projection for Phase 6.

    Exactness is with respect to the supplied piecewise-linear timed trajectory.
    Sphere and box resources use analytic line-segment intersections. Generic
    predicates are rejected by default because finite point sampling alone
    cannot prove the absence of a short hidden traversal.
    """

    def __init__(
        self,
        problem: HyperCertProblemDefinition,
        resources: tuple[ContinuousResource, ...],
        uncertainty_model: UncertaintyModel | None = None,
        config: CertificateProjectionConfig | None = None,
        trajectory_provider: TrajectoryProvider | None = None,
        polynomial_trajectory_provider: PolynomialTrajectoryProvider | None = None,
        trajectory_cache_capacity: int = 2_048,
        enable_trajectory_cache: bool = True,
    ) -> None:
        self.problem = problem
        self.resources = tuple(resources)
        self.config = config or CertificateProjectionConfig()
        self.uncertainty_model = uncertainty_model or UncertaintyModel()
        if trajectory_cache_capacity <= 0:
            raise ValueError("trajectory_cache_capacity must be positive")
        self.trajectory_cache_capacity = int(trajectory_cache_capacity)
        self.enable_trajectory_cache = bool(enable_trajectory_cache)
        self._trajectory_cache: OrderedDict[
            str,
            _TrajectoryProjectionCacheEntry,
        ] = OrderedDict()
        self._trajectory_shape_cache: OrderedDict[
            str,
            _TrajectoryProjectionCacheEntry,
        ] = OrderedDict()
        self._cache_hits = 0
        self._cache_misses = 0
        self._cache_evictions = 0
        self._uses_default_trajectory_provider = trajectory_provider is None
        if (
            self.config.trajectory_model == "minimum_snap"
            and trajectory_provider is not None
        ):
            raise ValueError(
                "minimum_snap projection constructs the execution trajectory "
                "from the HyperCert decision and does not accept a custom "
                "piecewise-linear provider"
            )
        if (
            self.config.trajectory_model == "piecewise_linear"
            and polynomial_trajectory_provider is not None
        ):
            raise ValueError(
                "polynomial_trajectory_provider requires trajectory_model='minimum_snap'"
            )
        self.trajectory_provider = trajectory_provider or self._default_timed_trajectory
        self._uses_default_polynomial_trajectory_provider = (
            polynomial_trajectory_provider is None
        )
        self.polynomial_trajectory_provider = (
            polynomial_trajectory_provider
            or self._default_minimum_snap_trajectory
        )
        resource_ids = [resource.resource_id for resource in self.resources]
        if len(set(resource_ids)) != len(resource_ids):
            raise ValueError("continuous projection resource ids must be unique")
        missing = set(problem.resource_ids) - set(resource_ids)
        if missing:
            raise ValueError(f"continuous projection is missing resources: {sorted(missing)}")
        if self.config.require_analytic_resource_intersection:
            if self.config.trajectory_model == "minimum_snap":
                unsupported = [
                    resource.resource_id
                    for resource in self.resources
                    if resource.segment_intervals_with_margin is None
                ]
            else:
                unsupported = [
                    resource.resource_id
                    for resource in self.resources
                    if resource.segment_intervals is None
                ]
            if unsupported:
                raise ValueError(
                    "strict certificate projection requires analytic or conservatively bounded "
                    f"segment intersection for resources: {sorted(unsupported)}"
                )
        self.extractor = ContinuousOccupancyExtractor(
            uncertainty_model=self.uncertainty_model,
            max_subdivision_depth=self.config.maximum_subdivision_depth,
            min_interval_s=self.config.minimum_interval_s,
            subdivision_tolerance_s=self.config.subdivision_tolerance_s,
            bisection_tolerance_s=self.config.bisection_tolerance_s,
        )
        self.polynomial_extractor = ConservativePolynomialOccupancyExtractor(
            uncertainty_model=self.uncertainty_model,
            config=PolynomialEnclosureConfig(
                spatial_tolerance_m=self.config.polynomial_spatial_tolerance_m,
                temporal_tolerance_s=self.config.subdivision_tolerance_s,
                bisection_tolerance_s=self.config.bisection_tolerance_s,
                maximum_subdivision_depth=self.config.maximum_subdivision_depth,
                numerical_margin_m=self.config.polynomial_numerical_margin_m,
            ),
        )
        self.verifier = ContinuousCapacityVerifier(
            {resource.resource_id: resource.capacity for resource in problem.resources}
        )

    def project(
        self,
        decisions: Mapping[str, UAVDecisionVariables],
        existing_certificates: tuple[ResourceCertificate, ...] = tuple(),
        snapshot_version: int = 0,
        creation_time_s: float = 0.0,
        uav_ids: tuple[str, ...] | None = None,
    ) -> CertificateProjectionResult:
        started = perf_counter()
        initial_hits = self._cache_hits
        initial_misses = self._cache_misses
        self.problem.validate_decisions(decisions)
        selected_uav_ids = (
            {uav.uav_id for uav in self.problem.uavs}
            if uav_ids is None
            else set(uav_ids)
        )
        unknown_uavs = selected_uav_ids - {uav.uav_id for uav in self.problem.uavs}
        if unknown_uavs:
            raise ValueError(f"projection has unknown UAVs: {sorted(unknown_uavs)}")
        fingerprint = decision_fingerprint(decisions)
        trajectories: dict[str, np.ndarray] = {}
        polynomial_trajectories: dict[str, MinimumSnapTrajectory] = {}
        enclosure_stats: dict[str, object] = {}
        candidates: list[ResourceCertificate] = []
        errors: list[str] = []
        for uav_index, uav in enumerate(self.problem.uavs):
            if uav.uav_id not in selected_uav_ids:
                continue
            decision = decisions[uav.uav_id]
            individual_fingerprint = trajectory_fingerprint(uav.uav_id, decision)
            shape_fingerprint = trajectory_shape_fingerprint(
                uav.uav_id,
                decision,
            )
            trajectory_id = f"hypercert:{uav.uav_id}:{individual_fingerprint[:16]}"
            cached = (
                self._trajectory_cache.get(individual_fingerprint)
                if self.enable_trajectory_cache
                else None
            )
            if cached is not None:
                self._trajectory_cache.move_to_end(individual_fingerprint)
                self._cache_hits += 1
                trajectory = cached.trajectory.copy()
                intervals = cached.intervals
                if cached.polynomial_trajectory is not None:
                    polynomial_trajectories[uav.uav_id] = (
                        cached.polynomial_trajectory
                    )
                if cached.enclosure_stats is not None:
                    enclosure_stats[uav.uav_id] = cached.enclosure_stats
            elif (
                self.config.trajectory_model == "minimum_snap"
                and self.enable_trajectory_cache
                and shape_fingerprint in self._trajectory_shape_cache
            ):
                cached_shape = self._trajectory_shape_cache[shape_fingerprint]
                self._trajectory_shape_cache.move_to_end(shape_fingerprint)
                self._cache_hits += 1
                target_start_s = (
                    uav.release_time_s + decision.departure_delay_s
                )
                shift_s = target_start_s - float(cached_shape.trajectory[0, 0])
                trajectory = cached_shape.trajectory.copy()
                trajectory[:, 0] += shift_s
                intervals = tuple(
                    replace(
                        interval,
                        trajectory_id=trajectory_id,
                        t_enter_nominal=interval.t_enter_nominal + shift_s,
                        t_exit_nominal=interval.t_exit_nominal + shift_s,
                        t_enter_robust=interval.t_enter_robust + shift_s,
                        t_exit_robust=interval.t_exit_robust + shift_s,
                    )
                    for interval in cached_shape.intervals
                )
                if cached_shape.polynomial_trajectory is not None:
                    cached_polynomial = cached_shape.polynomial_trajectory
                    polynomial_trajectories[uav.uav_id] = (
                        MinimumSnapTrajectory(
                            cached_polynomial.segment_start_times_s + shift_s,
                            cached_polynomial.segment_durations_s,
                            cached_polynomial.coefficients,
                        )
                    )
                if cached_shape.enclosure_stats is not None:
                    enclosure_stats[uav.uav_id] = (
                        cached_shape.enclosure_stats
                    )
                self._trajectory_cache[individual_fingerprint] = (
                    _TrajectoryProjectionCacheEntry(
                        trajectory=trajectory.copy(),
                        intervals=intervals,
                        enclosure_stats=cached_shape.enclosure_stats,
                        polynomial_trajectory=polynomial_trajectories.get(
                            uav.uav_id
                        ),
                    )
                )
                if len(self._trajectory_cache) > self.trajectory_cache_capacity:
                    self._trajectory_cache.popitem(last=False)
                    self._cache_evictions += 1
            else:
                self._cache_misses += 1
                enclosure = None
                if self.config.trajectory_model == "minimum_snap":
                    execution_trajectory = self.polynomial_trajectory_provider(
                        uav_index,
                        decision,
                    )
                    intervals = self.polynomial_extractor.extract(
                        execution_trajectory,
                        self.resources,
                        uav.uav_id,
                        trajectory_id,
                    )
                    enclosure = self.polynomial_extractor.last_stats
                    enclosure_stats[uav.uav_id] = enclosure
                    trajectory = _minimum_snap_timed_knots(execution_trajectory)
                    polynomial_trajectories[uav.uav_id] = (
                        execution_trajectory
                    )
                else:
                    trajectory = np.asarray(
                        self.trajectory_provider(uav_index, decision),
                        dtype=float,
                    )
                    intervals = self.extractor.extract(
                        trajectory,
                        self.resources,
                        uav.uav_id,
                        trajectory_id,
                    )
                if self.enable_trajectory_cache:
                    self._trajectory_cache[individual_fingerprint] = (
                        _TrajectoryProjectionCacheEntry(
                            trajectory=trajectory.copy(),
                            intervals=tuple(intervals),
                            enclosure_stats=enclosure,
                            polynomial_trajectory=polynomial_trajectories.get(
                                uav.uav_id
                            ),
                        )
                    )
                    if self.config.trajectory_model == "minimum_snap":
                        self._trajectory_shape_cache[shape_fingerprint] = (
                            _TrajectoryProjectionCacheEntry(
                                trajectory=trajectory.copy(),
                                intervals=tuple(intervals),
                                enclosure_stats=enclosure,
                                polynomial_trajectory=polynomial_trajectories.get(
                                    uav.uav_id
                                ),
                            )
                        )
                    if (
                        len(self._trajectory_cache)
                        > self.trajectory_cache_capacity
                    ):
                        self._trajectory_cache.popitem(last=False)
                        self._cache_evictions += 1
                    if (
                        len(self._trajectory_shape_cache)
                        > self.trajectory_cache_capacity
                    ):
                        self._trajectory_shape_cache.popitem(last=False)
                        self._cache_evictions += 1
            trajectories[uav.uav_id] = trajectory.copy()
            route = uav.route(decision.route_index)
            if self.config.require_route_resource_coverage:
                covered = {interval.resource_id for interval in intervals}
                missing_visits = set(route.resource_ids) - covered
                if missing_visits:
                    errors.append(
                        f"{uav.uav_id}: trajectory misses route resources {sorted(missing_visits)}"
                    )
            valid_from = float(trajectory[0, 0]) if len(trajectory) else uav.release_time_s
            valid_until = float(trajectory[-1, 0]) if len(trajectory) else valid_from
            if intervals:
                valid_from = min(valid_from, min(interval.t_enter_robust for interval in intervals))
                valid_until = max(valid_until, max(interval.t_exit_robust for interval in intervals))
            candidates.append(
                ResourceCertificate(
                    certificate_id=f"cert:{uav.uav_id}:{individual_fingerprint[:16]}",
                    uav_id=uav.uav_id,
                    trajectory_id=trajectory_id,
                    route_id=route.route_id,
                    resource_intervals=intervals,
                    creation_time=float(creation_time_s),
                    snapshot_version=int(snapshot_version),
                    certificate_version=0,
                    valid_from=valid_from,
                    valid_until=valid_until,
                    state="tentative",
                )
            )
        all_certificates = tuple(existing_certificates) + tuple(candidates)
        all_intervals = tuple(
            interval
            for certificate in all_certificates
            if certificate.state in {"tentative", "committed", "executing"}
            for interval in certificate.resource_intervals
        )
        verification = self.verifier.verify(all_intervals)
        trajectory_to_uav = {
            certificate.trajectory_id: certificate.uav_id for certificate in all_certificates
        }
        conflicts = tuple(
            ProjectionConflictHyperedge(
                hyperedge_id=f"exact:{episode.resource_id}:{index}",
                resource_id=episode.resource_id,
                time_support_s=(episode.t_start, episode.t_end),
                capacity=episode.capacity,
                occupancy=episode.occupancy,
                excess_occupancy=episode.excess_occupancy,
                participating_uav_ids=tuple(
                    sorted(
                        {
                            trajectory_to_uav[trajectory_id]
                            for trajectory_id in episode.responsible_certificate_ids
                            if trajectory_id in trajectory_to_uav
                        }
                    )
                ),
                participating_trajectory_ids=episode.responsible_certificate_ids,
            )
            for index, episode in enumerate(verification.overload_episodes)
        )
        return CertificateProjectionResult(
            decision_fingerprint=fingerprint,
            snapshot_version=int(snapshot_version),
            candidate_certificates=tuple(candidates),
            existing_certificates=tuple(existing_certificates),
            trajectories=trajectories,
            verification=verification,
            conflict_hyperedges=conflicts,
            projection_errors=tuple(errors),
            trajectory_enclosure_stats=enclosure_stats,
            polynomial_trajectories=polynomial_trajectories,
            projection_runtime_s=perf_counter() - started,
            trajectory_cache_hits=self._cache_hits - initial_hits,
            trajectory_cache_misses=self._cache_misses - initial_misses,
        )

    @property
    def cache_stats(self) -> ProjectionCacheStats:
        return ProjectionCacheStats(
            hits=self._cache_hits,
            misses=self._cache_misses,
            evictions=self._cache_evictions,
            entries=(
                len(self._trajectory_cache)
                + len(self._trajectory_shape_cache)
            ),
        )

    def clear_cache(self) -> None:
        self._trajectory_cache.clear()
        self._trajectory_shape_cache.clear()
        self._cache_hits = 0
        self._cache_misses = 0
        self._cache_evictions = 0

    def verify(
        self,
        decisions: Mapping[str, UAVDecisionVariables],
        existing_certificates: tuple[ResourceCertificate, ...] = tuple(),
    ) -> bool:
        return self.project(decisions, existing_certificates).is_safe

    def timed_trajectory(
        self,
        uav_index: int,
        decision: UAVDecisionVariables,
    ) -> np.ndarray:
        if self.config.trajectory_model == "minimum_snap":
            return _minimum_snap_timed_knots(
                self.polynomial_trajectory_provider(uav_index, decision)
            )
        return np.asarray(self.trajectory_provider(uav_index, decision), dtype=float).copy()

    def for_problem(
        self,
        problem: HyperCertProblemDefinition,
        uncertainty_model: UncertaintyModel | None = None,
    ) -> "ExactRobustCertificateProjector":
        provider = None if self._uses_default_trajectory_provider else self.trajectory_provider
        return ExactRobustCertificateProjector(
            problem=problem,
            resources=self.resources,
            uncertainty_model=uncertainty_model or self.uncertainty_model,
            config=self.config,
            trajectory_provider=provider,
            polynomial_trajectory_provider=(
                self.polynomial_trajectory_provider
                if (
                    self.config.trajectory_model == "minimum_snap"
                    and not self._uses_default_polynomial_trajectory_provider
                )
                else None
            ),
            trajectory_cache_capacity=self.trajectory_cache_capacity,
            enable_trajectory_cache=self.enable_trajectory_cache,
        )

    def _default_minimum_snap_trajectory(
        self,
        uav_index: int,
        decision: UAVDecisionVariables,
    ) -> MinimumSnapTrajectory:
        return minimum_snap_from_hypercert_decision(
            decision,
            release_time_s=self.problem.uavs[uav_index].release_time_s,
        )

    def _default_timed_trajectory(
        self,
        uav_index: int,
        decision: UAVDecisionVariables,
    ) -> np.ndarray:
        uav = self.problem.uavs[uav_index]
        positions = np.asarray(decision.trajectory_coefficients, dtype=float)
        if len(positions) < 2:
            raise ValueError("certificate projection requires at least two trajectory positions")
        start_s = uav.release_time_s + decision.departure_delay_s
        duration_s = float(np.sum(decision.edge_travel_times_s) + np.sum(decision.holding_times_s))
        if duration_s <= 0.0:
            raise ValueError("projected trajectory duration must be positive")
        times = np.linspace(start_s, start_s + duration_s, len(positions))
        return np.column_stack((times, positions))


class CertificateProjectionTransactionAdapter:
    """Stateful Phase 4/5 callbacks enforcing verify-before-atomic-commit."""

    def __init__(
        self,
        projector: ExactRobustCertificateProjector,
        reservation_manager: ReservationManager,
        owner_id: str = "hypercert",
        priority: float = 0.0,
    ) -> None:
        self.projector = projector
        self.reservation_manager = reservation_manager
        self.owner_id = owner_id
        self.priority = float(priority)
        self.last_projection: CertificateProjectionResult | None = None
        self.last_snapshot: ReservationSnapshot | None = None
        self.last_commit_result: ReservationCommitResult | None = None

    def exact_verifier(self, decisions: Mapping[str, UAVDecisionVariables]) -> bool:
        snapshot = self.reservation_manager.snapshot()
        projection = self.projector.project(
            decisions,
            existing_certificates=snapshot.certificates,
            snapshot_version=snapshot.version,
        )
        self.last_snapshot = snapshot
        self.last_projection = projection
        self.last_commit_result = None
        return projection.is_safe

    def atomic_committer(self, decisions: Mapping[str, UAVDecisionVariables]) -> bool:
        fingerprint = decision_fingerprint(decisions)
        if (
            self.last_projection is None
            or self.last_snapshot is None
            or not self.last_projection.is_safe
            or self.last_projection.decision_fingerprint != fingerprint
        ):
            return False
        lease = self.reservation_manager.create_lease(self.owner_id, self.priority)
        transaction = self.reservation_manager.make_transaction(
            self.owner_id,
            self.last_snapshot,
            self.last_projection.candidate_certificates,
            lease,
            self.priority,
        )
        self.last_commit_result = self.reservation_manager.commit(transaction)
        return self.last_commit_result.success


def decision_fingerprint(decisions: Mapping[str, UAVDecisionVariables]) -> str:
    digest = hashlib.sha256()
    for uav_id in sorted(decisions):
        decision = decisions[uav_id]
        digest.update(uav_id.encode("utf-8"))
        digest.update(np.asarray([decision.route_index, decision.altitude_layer_index], dtype=np.int64).tobytes())
        digest.update(np.asarray(decision.continuous_vector(), dtype=np.float64).tobytes())
    return digest.hexdigest()


def trajectory_fingerprint(
    uav_id: str,
    decision: UAVDecisionVariables,
) -> str:
    digest = hashlib.sha256()
    digest.update(str(uav_id).encode("utf-8"))
    digest.update(
        np.asarray(
            [decision.route_index, decision.altitude_layer_index],
            dtype=np.int64,
        ).tobytes()
    )
    digest.update(np.asarray(decision.continuous_vector(), dtype=np.float64).tobytes())
    return digest.hexdigest()


def trajectory_shape_fingerprint(
    uav_id: str,
    decision: UAVDecisionVariables,
) -> str:
    """Fingerprint a minimum-snap trajectory modulo absolute time shift."""

    digest = hashlib.sha256()
    digest.update(str(uav_id).encode("utf-8"))
    digest.update(
        np.asarray(
            [decision.route_index, decision.altitude_layer_index],
            dtype=np.int64,
        ).tobytes()
    )
    digest.update(
        np.asarray(decision.edge_travel_times_s, dtype=np.float64).tobytes()
    )
    digest.update(
        np.asarray(decision.holding_times_s, dtype=np.float64).tobytes()
    )
    digest.update(
        np.asarray(decision.trajectory_coefficients, dtype=np.float64).tobytes()
    )
    return digest.hexdigest()


def _minimum_snap_timed_knots(
    trajectory: MinimumSnapTrajectory,
) -> np.ndarray:
    times = np.concatenate(
        (
            trajectory.segment_start_times_s,
            np.asarray([trajectory.end_time_s]),
        )
    )
    positions = np.vstack(
        [trajectory.evaluate(float(time_s), 0) for time_s in times]
    )
    return np.column_stack((times, positions))
