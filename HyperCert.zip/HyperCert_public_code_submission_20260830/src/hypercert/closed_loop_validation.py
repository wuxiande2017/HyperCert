from __future__ import annotations

from dataclasses import dataclass
from math import factorial
from pathlib import Path

import numpy as np

from .decision_variables import UAVDecisionVariables


@dataclass(frozen=True)
class MinimumSnapTrajectory:
    segment_start_times_s: np.ndarray
    segment_durations_s: np.ndarray
    coefficients: np.ndarray

    def __post_init__(self) -> None:
        starts = np.asarray(self.segment_start_times_s, dtype=float)
        durations = np.asarray(self.segment_durations_s, dtype=float)
        coefficients = np.asarray(self.coefficients, dtype=float)
        if starts.ndim != 1 or durations.ndim != 1 or len(starts) != len(durations):
            raise ValueError("segment time vectors must have one matching dimension")
        if coefficients.shape != (len(durations), 3, 8):
            raise ValueError("minimum-snap coefficients must have shape (segments, 3, 8)")
        if len(durations) == 0 or np.any(durations <= 0.0):
            raise ValueError("segment durations must be positive")
        if np.any(np.diff(starts) <= 0.0):
            raise ValueError("segment start times must be strictly increasing")
        expected_starts = starts[:-1] + durations[:-1]
        if len(expected_starts) and not np.allclose(
            starts[1:],
            expected_starts,
            atol=1e-9,
            rtol=1e-9,
        ):
            raise ValueError("minimum-snap segments must form a contiguous timeline")
        object.__setattr__(self, "segment_start_times_s", starts)
        object.__setattr__(self, "segment_durations_s", durations)
        object.__setattr__(self, "coefficients", coefficients)

    @property
    def start_time_s(self) -> float:
        return float(self.segment_start_times_s[0])

    @property
    def end_time_s(self) -> float:
        return float(self.segment_start_times_s[-1] + self.segment_durations_s[-1])

    def evaluate(self, time_s: float, derivative: int = 0) -> np.ndarray:
        if not 0 <= derivative <= 4:
            raise ValueError("derivative must lie between zero and four")
        clipped = min(max(float(time_s), self.start_time_s), self.end_time_s)
        segment = int(
            np.searchsorted(self.segment_start_times_s[1:], clipped, side="right")
        )
        local_time = clipped - self.segment_start_times_s[segment]
        if clipped >= self.end_time_s:
            local_time = self.segment_durations_s[-1]
        basis = _polynomial_derivative_basis(local_time, derivative)
        return self.coefficients[segment] @ basis


@dataclass(frozen=True)
class QuadrotorParameters:
    mass_kg: float = 1.5
    gravity_mps2: float = 9.81
    inertia_kgm2: tuple[float, float, float] = (0.025, 0.025, 0.045)
    linear_drag_ns_m: float = 0.08
    maximum_thrust_n: float = 36.0
    maximum_torque_nm: float = 1.5


@dataclass(frozen=True)
class ControllerGains:
    position_kp: tuple[float, float, float] = (3.8, 3.8, 5.0)
    velocity_kd: tuple[float, float, float] = (3.1, 3.1, 3.8)
    attitude_kp: tuple[float, float, float] = (8.0, 8.0, 4.8)
    angular_rate_kd: tuple[float, float, float] = (1.4, 1.4, 0.98)


@dataclass(frozen=True)
class ClosedLoopValidationResult:
    backend: str
    time_s: np.ndarray
    reference_position_m: np.ndarray
    position_m: np.ndarray
    reference_velocity_mps: np.ndarray
    velocity_mps: np.ndarray
    attitude_rad: np.ndarray
    thrust_n: np.ndarray
    position_rmse_m: float
    maximum_tracking_error_m: float
    velocity_rmse_mps: float
    certificate_bound_m: float
    certificate_violation_samples: int
    certificate_violation_events: int
    certificate_violation_fraction: float
    thrust_saturation_fraction: float

    def summary(self) -> dict[str, float | int | str]:
        return {
            "backend": self.backend,
            "position_rmse_m": self.position_rmse_m,
            "maximum_tracking_error_m": self.maximum_tracking_error_m,
            "velocity_rmse_mps": self.velocity_rmse_mps,
            "certificate_bound_m": self.certificate_bound_m,
            "certificate_violation_samples": self.certificate_violation_samples,
            "certificate_violation_events": self.certificate_violation_events,
            "certificate_violation_fraction": self.certificate_violation_fraction,
            "thrust_saturation_fraction": self.thrust_saturation_fraction,
        }


def generate_minimum_snap_trajectory(
    waypoints_m: np.ndarray,
    *,
    start_time_s: float = 0.0,
    segment_durations_s: np.ndarray | None = None,
    total_duration_s: float | None = None,
) -> MinimumSnapTrajectory:
    waypoints = np.asarray(waypoints_m, dtype=float)
    if waypoints.ndim != 2 or waypoints.shape[1] != 3 or len(waypoints) < 2:
        raise ValueError("waypoints must have shape (N, 3) with N >= 2")
    segment_count = len(waypoints) - 1
    if segment_durations_s is None:
        if total_duration_s is None or total_duration_s <= 0.0:
            raise ValueError("a positive total_duration_s is required")
        distances = np.linalg.norm(np.diff(waypoints, axis=0), axis=1)
        weights = np.maximum(distances, 1e-3)
        durations = float(total_duration_s) * weights / float(np.sum(weights))
    else:
        durations = np.asarray(segment_durations_s, dtype=float)
        if durations.shape != (segment_count,):
            raise ValueError("segment_durations_s must match the waypoint segments")
        if np.any(durations <= 0.0):
            raise ValueError("segment durations must be positive")

    hessian = np.zeros((8 * segment_count, 8 * segment_count), dtype=float)
    objective_scale = float(np.max(durations) ** 7)
    for segment, duration in enumerate(durations):
        block = np.zeros((8, 8), dtype=float)
        for row in range(4, 8):
            for column in range(4, 8):
                block[row, column] = (
                    factorial(row)
                    / factorial(row - 4)
                    * factorial(column)
                    / factorial(column - 4)
                    / (row + column - 7)
                    * objective_scale
                    / duration**7
                )
        start = 8 * segment
        hessian[start : start + 8, start : start + 8] = block
    hessian += 1e-11 * np.eye(len(hessian))

    rows: list[np.ndarray] = []
    waypoint_rows: list[tuple[int, int]] = []
    for segment, duration in enumerate(durations):
        start_row = np.zeros(8 * segment_count)
        start_row[8 * segment : 8 * segment + 8] = _normalized_derivative_basis(
            0.0,
            0,
            duration,
        )
        rows.append(start_row)
        waypoint_rows.append((segment, 0))
        end_row = np.zeros(8 * segment_count)
        end_row[8 * segment : 8 * segment + 8] = _normalized_derivative_basis(
            1.0,
            0,
            duration,
        )
        rows.append(end_row)
        waypoint_rows.append((segment + 1, 0))
    for derivative in range(1, 4):
        start_row = np.zeros(8 * segment_count)
        start_row[:8] = _normalized_derivative_basis(0.0, derivative, durations[0])
        rows.append(start_row)
        waypoint_rows.append((-1, derivative))
        end_row = np.zeros(8 * segment_count)
        end_row[-8:] = _normalized_derivative_basis(1.0, derivative, durations[-1])
        rows.append(end_row)
        waypoint_rows.append((-1, derivative))
    for segment in range(segment_count - 1):
        for derivative in range(1, 4):
            continuity = np.zeros(8 * segment_count)
            continuity[8 * segment : 8 * segment + 8] = _normalized_derivative_basis(
                1.0,
                derivative,
                durations[segment],
            )
            continuity[8 * (segment + 1) : 8 * (segment + 1) + 8] = (
                -_normalized_derivative_basis(0.0, derivative, durations[segment + 1])
            )
            rows.append(continuity)
            waypoint_rows.append((-2, derivative))
    constraints = np.vstack(rows)
    coefficients = np.zeros((segment_count, 3, 8), dtype=float)
    kkt = np.block(
        [
            [hessian, constraints.T],
            [constraints, np.zeros((len(constraints), len(constraints)))],
        ]
    )
    for dimension in range(3):
        rhs_constraints = np.zeros(len(constraints), dtype=float)
        for index, (waypoint_index, _) in enumerate(waypoint_rows):
            if waypoint_index >= 0:
                rhs_constraints[index] = waypoints[waypoint_index, dimension]
        solution = np.linalg.lstsq(
            kkt,
            np.concatenate((np.zeros(8 * segment_count), rhs_constraints)),
            rcond=1e-12,
        )[0]
        normalized_coefficients = solution[: 8 * segment_count].reshape(
            segment_count,
            8,
        )
        coefficients[:, dimension, :] = normalized_coefficients / np.asarray(
            [
                [duration**power for power in range(8)]
                for duration in durations
            ]
        )
    starts = float(start_time_s) + np.concatenate(([0.0], np.cumsum(durations[:-1])))
    return MinimumSnapTrajectory(starts, durations, coefficients)


def minimum_snap_from_hypercert_decision(
    decision: UAVDecisionVariables,
    *,
    release_time_s: float = 0.0,
) -> MinimumSnapTrajectory:
    waypoints = np.asarray(decision.trajectory_coefficients, dtype=float)
    if len(waypoints) < 2:
        raise ValueError("HyperCert trajectory output has fewer than two waypoints")
    total_duration = float(
        np.sum(decision.edge_travel_times_s) + np.sum(decision.holding_times_s)
    )
    return generate_minimum_snap_trajectory(
        waypoints,
        start_time_s=release_time_s + decision.departure_delay_s,
        total_duration_s=total_duration,
    )


def generate_phased_minimum_snap_trajectory(
    phases: tuple[tuple[np.ndarray, float], ...],
    *,
    start_time_s: float = 0.0,
) -> MinimumSnapTrajectory:
    """Build a contiguous trajectory from timed motion and holding phases.

    A phase with one waypoint is an exact constant-position hold. A phase with
    two or more waypoints is a minimum-snap motion whose duration is preserved
    exactly. Motion sections have zero endpoint derivatives, so adjoining
    holds remain position-through-jerk continuous.
    """

    if not phases:
        raise ValueError("at least one execution phase is required")
    starts: list[float] = []
    durations: list[float] = []
    coefficients: list[np.ndarray] = []
    cursor = float(start_time_s)
    previous_end: np.ndarray | None = None
    for waypoints_m, duration_s in phases:
        waypoints = np.asarray(waypoints_m, dtype=float)
        duration = float(duration_s)
        if duration <= 0.0:
            raise ValueError("execution phase durations must be positive")
        if waypoints.ndim != 2 or waypoints.shape[1] != 3 or len(waypoints) == 0:
            raise ValueError("execution phase waypoints must have shape (N, 3)")
        if previous_end is not None and not np.allclose(
            waypoints[0],
            previous_end,
            atol=1e-8,
            rtol=1e-8,
        ):
            raise ValueError("execution phases must meet at a common waypoint")

        if len(waypoints) == 1:
            phase_starts = np.asarray([cursor])
            phase_durations = np.asarray([duration])
            phase_coefficients = np.zeros((1, 3, 8), dtype=float)
            phase_coefficients[0, :, 0] = waypoints[0]
        else:
            phase = generate_minimum_snap_trajectory(
                waypoints,
                start_time_s=cursor,
                total_duration_s=duration,
            )
            phase_starts = phase.segment_start_times_s
            phase_durations = phase.segment_durations_s
            phase_coefficients = phase.coefficients
        starts.extend(float(value) for value in phase_starts)
        durations.extend(float(value) for value in phase_durations)
        coefficients.extend(phase_coefficients)
        cursor += duration
        previous_end = waypoints[-1]

    return MinimumSnapTrajectory(
        np.asarray(starts),
        np.asarray(durations),
        np.asarray(coefficients),
    )


def simulate_quadrotor_closed_loop(
    trajectory: MinimumSnapTrajectory,
    *,
    parameters: QuadrotorParameters | None = None,
    gains: ControllerGains | None = None,
    time_step_s: float = 0.01,
    certificate_bound_m: float = 1.0,
    wind_force_world_n: np.ndarray | None = None,
) -> ClosedLoopValidationResult:
    if time_step_s <= 0.0 or certificate_bound_m <= 0.0:
        raise ValueError("time step and certificate bound must be positive")
    params = parameters or QuadrotorParameters()
    controller = gains or ControllerGains()
    wind = (
        np.zeros(3)
        if wind_force_world_n is None
        else np.asarray(wind_force_world_n, dtype=float)
    )
    if wind.shape != (3,):
        raise ValueError("wind_force_world_n must have shape (3,)")

    times = np.arange(
        trajectory.start_time_s,
        trajectory.end_time_s + 0.5 * time_step_s,
        time_step_s,
    )
    state = np.zeros(12, dtype=float)
    state[:3] = trajectory.evaluate(times[0], 0)
    state[3:6] = trajectory.evaluate(times[0], 1)
    positions = np.zeros((len(times), 3), dtype=float)
    velocities = np.zeros((len(times), 3), dtype=float)
    attitudes = np.zeros((len(times), 3), dtype=float)
    thrusts = np.zeros(len(times), dtype=float)
    reference_positions = np.zeros((len(times), 3), dtype=float)
    reference_velocities = np.zeros((len(times), 3), dtype=float)

    for index, time_s in enumerate(times):
        reference_position = trajectory.evaluate(time_s, 0)
        reference_velocity = trajectory.evaluate(time_s, 1)
        reference_acceleration = trajectory.evaluate(time_s, 2)
        thrust, torque = _controller(
            state,
            reference_position,
            reference_velocity,
            reference_acceleration,
            params,
            controller,
        )
        positions[index] = state[:3]
        velocities[index] = state[3:6]
        attitudes[index] = state[6:9]
        thrusts[index] = thrust
        reference_positions[index] = reference_position
        reference_velocities[index] = reference_velocity
        if index + 1 < len(times):
            state = _rk4_step(
                state,
                time_step_s,
                thrust,
                torque,
                wind,
                params,
            )

    position_error = np.linalg.norm(positions - reference_positions, axis=1)
    velocity_error = np.linalg.norm(velocities - reference_velocities, axis=1)
    violations = position_error > certificate_bound_m
    events = int(np.sum(violations & ~np.concatenate(([False], violations[:-1]))))
    saturation = thrusts >= params.maximum_thrust_n - 1e-9
    return ClosedLoopValidationResult(
        backend="native_12_state_rigid_body_rk4",
        time_s=times,
        reference_position_m=reference_positions,
        position_m=positions,
        reference_velocity_mps=reference_velocities,
        velocity_mps=velocities,
        attitude_rad=attitudes,
        thrust_n=thrusts,
        position_rmse_m=float(np.sqrt(np.mean(position_error**2))),
        maximum_tracking_error_m=float(np.max(position_error, initial=0.0)),
        velocity_rmse_mps=float(np.sqrt(np.mean(velocity_error**2))),
        certificate_bound_m=float(certificate_bound_m),
        certificate_violation_samples=int(np.sum(violations)),
        certificate_violation_events=events,
        certificate_violation_fraction=float(np.mean(violations)),
        thrust_saturation_fraction=float(np.mean(saturation)),
    )


def detect_external_sitl_backends() -> dict[str, object]:
    """Report executable evidence without treating an import as a SITL run."""

    candidates = {
        "px4": ("px4.exe", "px4"),
        "gazebo": ("gz.exe", "gazebo.exe", "gz", "gazebo"),
        "airsim": ("Blocks.exe", "AirSimNH.exe"),
    }
    path_entries = [Path(entry) for entry in __import__("os").environ.get("PATH", "").split(";") if entry]
    status = {}
    for backend, names in candidates.items():
        matches = [
            str(directory / name)
            for directory in path_entries
            for name in names
            if (directory / name).exists()
        ]
        status[backend] = {"available": bool(matches), "executables": matches}
    status["external_sitl_available"] = any(
        item["available"] for key, item in status.items() if key != "external_sitl_available"
    )
    return status


def _controller(
    state: np.ndarray,
    desired_position: np.ndarray,
    desired_velocity: np.ndarray,
    desired_acceleration: np.ndarray,
    params: QuadrotorParameters,
    gains: ControllerGains,
) -> tuple[float, np.ndarray]:
    kp = np.asarray(gains.position_kp)
    kd = np.asarray(gains.velocity_kd)
    commanded_acceleration = (
        desired_acceleration
        + kp * (desired_position - state[:3])
        + kd * (desired_velocity - state[3:6])
    )
    desired_force = params.mass_kg * (
        commanded_acceleration + np.asarray([0.0, 0.0, params.gravity_mps2])
    )
    desired_roll = np.arctan2(-desired_force[1], max(desired_force[2], 1e-6))
    desired_pitch = np.arctan2(
        desired_force[0],
        max(np.hypot(desired_force[1], desired_force[2]), 1e-6),
    )
    desired_attitude = np.asarray([desired_roll, desired_pitch, 0.0])
    rotation = _rotation_matrix(state[6:9])
    thrust = float(
        np.clip(
            np.dot(desired_force, rotation[:, 2]),
            0.0,
            params.maximum_thrust_n,
        )
    )
    attitude_error = desired_attitude - state[6:9]
    attitude_error[2] = (attitude_error[2] + np.pi) % (2.0 * np.pi) - np.pi
    torque = (
        np.asarray(gains.attitude_kp) * attitude_error
        - np.asarray(gains.angular_rate_kd) * state[9:12]
    )
    torque = np.clip(torque, -params.maximum_torque_nm, params.maximum_torque_nm)
    return thrust, torque


def _rk4_step(
    state: np.ndarray,
    dt_s: float,
    thrust_n: float,
    torque_nm: np.ndarray,
    wind_force_world_n: np.ndarray,
    params: QuadrotorParameters,
) -> np.ndarray:
    derivative = lambda value: _quadrotor_derivative(
        value,
        thrust_n,
        torque_nm,
        wind_force_world_n,
        params,
    )
    k1 = derivative(state)
    k2 = derivative(state + 0.5 * dt_s * k1)
    k3 = derivative(state + 0.5 * dt_s * k2)
    k4 = derivative(state + dt_s * k3)
    result = state + dt_s * (k1 + 2.0 * k2 + 2.0 * k3 + k4) / 6.0
    result[6:9] = (result[6:9] + np.pi) % (2.0 * np.pi) - np.pi
    return result


def _quadrotor_derivative(
    state: np.ndarray,
    thrust_n: float,
    torque_nm: np.ndarray,
    wind_force_world_n: np.ndarray,
    params: QuadrotorParameters,
) -> np.ndarray:
    rotation = _rotation_matrix(state[6:9])
    velocity = state[3:6]
    acceleration = (
        rotation @ np.asarray([0.0, 0.0, thrust_n])
        + wind_force_world_n
        - params.linear_drag_ns_m * velocity
    ) / params.mass_kg - np.asarray([0.0, 0.0, params.gravity_mps2])
    roll, pitch, _ = state[6:9]
    angular_rate = state[9:12]
    cos_pitch = max(np.cos(pitch), 1e-4)
    euler_rate_map = np.asarray(
        [
            [1.0, np.sin(roll) * np.tan(pitch), np.cos(roll) * np.tan(pitch)],
            [0.0, np.cos(roll), -np.sin(roll)],
            [0.0, np.sin(roll) / cos_pitch, np.cos(roll) / cos_pitch],
        ]
    )
    inertia = np.diag(np.asarray(params.inertia_kgm2))
    angular_acceleration = np.linalg.solve(
        inertia,
        torque_nm - np.cross(angular_rate, inertia @ angular_rate),
    )
    return np.concatenate(
        (
            velocity,
            acceleration,
            euler_rate_map @ angular_rate,
            angular_acceleration,
        )
    )


def _rotation_matrix(euler_rad: np.ndarray) -> np.ndarray:
    roll, pitch, yaw = euler_rad
    cr, sr = np.cos(roll), np.sin(roll)
    cp, sp = np.cos(pitch), np.sin(pitch)
    cy, sy = np.cos(yaw), np.sin(yaw)
    return np.asarray(
        [
            [cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
            [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
            [-sp, cp * sr, cp * cr],
        ]
    )


def _polynomial_derivative_basis(time_s: float, derivative: int) -> np.ndarray:
    basis = np.zeros(8, dtype=float)
    for power in range(derivative, 8):
        basis[power] = factorial(power) / factorial(power - derivative) * time_s ** (
            power - derivative
        )
    return basis


def _normalized_derivative_basis(
    normalized_time: float,
    derivative: int,
    duration_s: float,
) -> np.ndarray:
    return _polynomial_derivative_basis(normalized_time, derivative) / duration_s**derivative
