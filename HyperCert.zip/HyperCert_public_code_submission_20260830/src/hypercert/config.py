from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class HyperCertObjectiveWeights:
    departure_delay: float = 3.0
    travel_time: float = 0.20
    route_length: float = 0.002
    control_effort: float = 0.05
    trajectory_smoothness: float = 0.10
    holding_time: float = 3.0
    route_switching: float = 1.0
    fairness: float = 0.04
    starvation: float = 0.05
    execution_repair_deviation: float = 0.50

    def as_dict(self) -> dict[str, float]:
        return {
            "departure_delay": self.departure_delay,
            "travel_time": self.travel_time,
            "route_length": self.route_length,
            "control_effort": self.control_effort,
            "trajectory_smoothness": self.trajectory_smoothness,
            "holding_time": self.holding_time,
            "route_switching": self.route_switching,
            "fairness": self.fairness,
            "starvation": self.starvation,
            "execution_repair_deviation": self.execution_repair_deviation,
        }


@dataclass(frozen=True)
class HyperCertSolverSettings:
    max_iterations: int = 300
    minimum_iterations: int = 10
    local_max_iterations: int = 100
    primal_tolerance: float = 1e-2
    dual_tolerance: float = 3e-3
    decision_tolerance: float = 1e-3
    dual_step_size: float = 0.20
    primal_relaxation: float = 0.45
    proximal_weight: float = 0.10
    stable_iterations_required: int = 5


@dataclass(frozen=True)
class HyperCertConfig:
    occupancy_temperature_s: float = 0.25
    optimization_grid_dt_s: float = 0.10
    trajectory_sample_dt_s: float = 0.25
    max_departure_delay_s: float = 120.0
    max_holding_time_s: float = 30.0
    coefficient_bound_m: float = 100_000.0
    constraint_tolerance: float = 1e-6
    weights: HyperCertObjectiveWeights = field(default_factory=HyperCertObjectiveWeights)
    solver: HyperCertSolverSettings = field(default_factory=HyperCertSolverSettings)

    def __post_init__(self) -> None:
        positive = {
            "occupancy_temperature_s": self.occupancy_temperature_s,
            "optimization_grid_dt_s": self.optimization_grid_dt_s,
            "trajectory_sample_dt_s": self.trajectory_sample_dt_s,
            "max_departure_delay_s": self.max_departure_delay_s,
            "max_holding_time_s": self.max_holding_time_s,
            "coefficient_bound_m": self.coefficient_bound_m,
        }
        invalid = [name for name, value in positive.items() if value <= 0.0]
        if invalid:
            raise ValueError(f"HyperCert configuration values must be positive: {invalid}")
        if not 0.0 < self.solver.primal_relaxation <= 1.0:
            raise ValueError("primal_relaxation must lie in (0, 1]")

