from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class CapacityConflictHyperedge:
    hyperedge_id: str
    resource_id: str
    time_support_s: tuple[float, float]
    resource_capacity: int
    participating_uav_ids: tuple[str, ...]
    soft_occupancy: dict[str, np.ndarray]
    exact_nominal_occupancy: dict[str, tuple[tuple[float, float], ...]]
    primal_capacity_residual: np.ndarray
    current_dual_price: np.ndarray
    marginal_delay_relief: dict[str, float]
    marginal_speed_relief: dict[str, float]
    marginal_holding_relief: dict[str, float]
    available_route_alternatives: dict[str, tuple[int, ...]]

    def __post_init__(self) -> None:
        if not self.hyperedge_id or not self.resource_id:
            raise ValueError("hyperedge and resource ids cannot be empty")
        if self.resource_capacity <= 0:
            raise ValueError("resource capacity must be positive")
        if self.time_support_s[1] <= self.time_support_s[0]:
            raise ValueError("hyperedge time support must have positive duration")
        if len(set(self.participating_uav_ids)) != len(self.participating_uav_ids):
            raise ValueError("hyperedge participants must be unique")
        residual = np.asarray(self.primal_capacity_residual, dtype=float).reshape(-1).copy()
        price = np.asarray(self.current_dual_price, dtype=float).reshape(-1).copy()
        if residual.shape != price.shape:
            raise ValueError("hyperedge residual and dual-price arrays must align")
        occupancy = {
            uav_id: np.asarray(values, dtype=float).reshape(-1).copy()
            for uav_id, values in self.soft_occupancy.items()
        }
        if any(values.shape != residual.shape for values in occupancy.values()):
            raise ValueError("participant occupancy arrays must align with hyperedge support")
        object.__setattr__(self, "primal_capacity_residual", residual)
        object.__setattr__(self, "current_dual_price", price)
        object.__setattr__(self, "soft_occupancy", occupancy)

    @property
    def maximum_residual(self) -> float:
        return max(0.0, float(np.max(self.primal_capacity_residual, initial=0.0)))

    @property
    def excess_occupancy(self) -> float:
        return float(np.sum(np.maximum(self.primal_capacity_residual, 0.0)))


@dataclass(frozen=True)
class CapacityConflictHypergraph:
    uav_ids: tuple[str, ...]
    hyperedges: tuple[CapacityConflictHyperedge, ...]

    def __post_init__(self) -> None:
        if len(set(self.uav_ids)) != len(self.uav_ids):
            raise ValueError("hypergraph UAV ids must be unique")
        known = set(self.uav_ids)
        for edge in self.hyperedges:
            unknown = set(edge.participating_uav_ids) - known
            if unknown:
                raise ValueError(f"hyperedge {edge.hyperedge_id} has unknown participants: {sorted(unknown)}")

    @property
    def active_uav_ids(self) -> tuple[str, ...]:
        return tuple(sorted({uav_id for edge in self.hyperedges for uav_id in edge.participating_uav_ids}))

    @property
    def active_resource_ids(self) -> tuple[str, ...]:
        return tuple(sorted({edge.resource_id for edge in self.hyperedges}))

    def incident_hyperedges(self, uav_id: str) -> tuple[CapacityConflictHyperedge, ...]:
        return tuple(edge for edge in self.hyperedges if uav_id in edge.participating_uav_ids)

    def hyperedges_for_resource(self, resource_id: str) -> tuple[CapacityConflictHyperedge, ...]:
        return tuple(edge for edge in self.hyperedges if edge.resource_id == resource_id)

    def communication_neighbors(self, uav_id: str) -> tuple[str, ...]:
        return tuple(
            sorted(
                {
                    other
                    for edge in self.incident_hyperedges(uav_id)
                    for other in edge.participating_uav_ids
                    if other != uav_id
                }
            )
        )

    def communication_memberships(self) -> tuple[tuple[str, str], ...]:
        return tuple(
            (uav_id, edge.hyperedge_id)
            for edge in self.hyperedges
            for uav_id in edge.participating_uav_ids
        )

    def uavs_to_solve(self) -> tuple[str, ...]:
        return self.active_uav_ids

    def resources_to_update(self) -> tuple[str, ...]:
        return self.active_resource_ids

    def routes_to_reconsider(self) -> tuple[str, ...]:
        return tuple(
            sorted(
                {
                    uav_id
                    for edge in self.hyperedges
                    for uav_id, alternatives in edge.available_route_alternatives.items()
                    if alternatives
                }
            )
        )

    def shares_hyperedge(self, left_uav_id: str, right_uav_id: str) -> bool:
        return any(
            left_uav_id in edge.participating_uav_ids and right_uav_id in edge.participating_uav_ids
            for edge in self.hyperedges
        )

