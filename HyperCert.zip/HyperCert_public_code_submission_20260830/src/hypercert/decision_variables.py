from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class ContinuousVariableLayout:
    departure_delay: slice
    edge_travel_times: slice
    holding_times: slice
    trajectory_coefficients: slice
    coefficient_shape: tuple[int, ...]
    size: int

    @classmethod
    def build(
        cls,
        edge_count: int,
        holding_count: int,
        coefficient_shape: tuple[int, ...],
    ) -> "ContinuousVariableLayout":
        if edge_count <= 0:
            raise ValueError("edge_count must be positive")
        if holding_count < 0:
            raise ValueError("holding_count cannot be negative")
        offset = 0
        departure = slice(offset, offset + 1)
        offset += 1
        edge_times = slice(offset, offset + edge_count)
        offset += edge_count
        holds = slice(offset, offset + holding_count)
        offset += holding_count
        coefficient_count = int(np.prod(coefficient_shape, dtype=int))
        coefficients = slice(offset, offset + coefficient_count)
        offset += coefficient_count
        return cls(departure, edge_times, holds, coefficients, coefficient_shape, offset)


@dataclass(frozen=True)
class UAVDecisionVariables:
    route_index: int
    departure_delay_s: float
    edge_travel_times_s: np.ndarray
    holding_times_s: np.ndarray
    trajectory_coefficients: np.ndarray
    altitude_layer_index: int

    def __post_init__(self) -> None:
        edge_times = np.asarray(self.edge_travel_times_s, dtype=float).reshape(-1).copy()
        holding_times = np.asarray(self.holding_times_s, dtype=float).reshape(-1).copy()
        coefficients = np.asarray(self.trajectory_coefficients, dtype=float).copy()
        if edge_times.size == 0:
            raise ValueError("at least one edge travel time is required")
        if coefficients.ndim < 1:
            raise ValueError("trajectory_coefficients must have at least one dimension")
        if not np.all(np.isfinite(np.concatenate(([self.departure_delay_s], edge_times, holding_times, coefficients.reshape(-1))))):
            raise ValueError("continuous decision variables must be finite")
        object.__setattr__(self, "edge_travel_times_s", edge_times)
        object.__setattr__(self, "holding_times_s", holding_times)
        object.__setattr__(self, "trajectory_coefficients", coefficients)

    @property
    def continuous_layout(self) -> ContinuousVariableLayout:
        return ContinuousVariableLayout.build(
            len(self.edge_travel_times_s),
            len(self.holding_times_s),
            self.trajectory_coefficients.shape,
        )

    def continuous_vector(self) -> np.ndarray:
        return np.concatenate(
            (
                np.asarray([self.departure_delay_s], dtype=float),
                self.edge_travel_times_s,
                self.holding_times_s,
                self.trajectory_coefficients.reshape(-1),
            )
        )

    def with_continuous_vector(self, vector: np.ndarray) -> "UAVDecisionVariables":
        values = np.asarray(vector, dtype=float).reshape(-1)
        layout = self.continuous_layout
        if len(values) != layout.size:
            raise ValueError(f"expected {layout.size} continuous variables, got {len(values)}")
        return UAVDecisionVariables(
            route_index=self.route_index,
            departure_delay_s=float(values[layout.departure_delay][0]),
            edge_travel_times_s=values[layout.edge_travel_times],
            holding_times_s=values[layout.holding_times],
            trajectory_coefficients=values[layout.trajectory_coefficients].reshape(layout.coefficient_shape),
            altitude_layer_index=self.altitude_layer_index,
        )

    def with_discrete_assignment(self, route_index: int, altitude_layer_index: int) -> "UAVDecisionVariables":
        return UAVDecisionVariables(
            route_index=int(route_index),
            departure_delay_s=self.departure_delay_s,
            edge_travel_times_s=self.edge_travel_times_s,
            holding_times_s=self.holding_times_s,
            trajectory_coefficients=self.trajectory_coefficients,
            altitude_layer_index=int(altitude_layer_index),
        )

    def continuous_distance_squared(self, other: "UAVDecisionVariables") -> float:
        left = self.continuous_vector()
        right = other.continuous_vector()
        if left.shape != right.shape:
            raise ValueError("continuous decision layouts must match")
        return float(np.sum((left - right) ** 2))

