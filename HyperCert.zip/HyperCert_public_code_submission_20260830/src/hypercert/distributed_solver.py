from __future__ import annotations

from dataclasses import dataclass, field
from time import perf_counter
from typing import Callable, Literal, Mapping

import numpy as np

from .asynchronous_updates import (
    AsynchronousUpdateConfig,
    BoundedStaleDualStore,
    DeterministicAsynchronousScheduler,
)
from .conflict_hypergraph import CapacityConflictHypergraph
from .decision_variables import UAVDecisionVariables
from .dual_variables import ResourceTimeDualVariables
from .hypergraph_builder import CapacityConflictHypergraphBuilder
from .local_subproblem import LocalSubproblemSolver
from .message_model import (
    MessageLedger,
    build_global_coordination_messages,
    build_hyperedge_messages,
)
from .problem_definition import HyperCertProblemDefinition
from .soft_occupancy import SoftOccupancyModel
from .step_size_policy import AdaptiveStepSizePolicy
from .warm_start import HyperCertWarmStart


ExactVerifier = Callable[[Mapping[str, UAVDecisionVariables]], bool]
AtomicCommitter = Callable[[Mapping[str, UAVDecisionVariables]], bool]


@dataclass(frozen=True)
class DistributedSolverConfig:
    update_mode: Literal["synchronous", "asynchronous"] = "synchronous"
    coordination_mode: Literal["global", "hypergraph"] = "hypergraph"
    asynchronous: AsynchronousUpdateConfig = field(default_factory=AsynchronousUpdateConfig)
    rebuild_hypergraph_every: int = 1

    def __post_init__(self) -> None:
        if self.update_mode not in {"synchronous", "asynchronous"}:
            raise ValueError("update_mode must be synchronous or asynchronous")
        if self.coordination_mode not in {"global", "hypergraph"}:
            raise ValueError("coordination_mode must be global or hypergraph")
        if self.rebuild_hypergraph_every <= 0:
            raise ValueError("rebuild_hypergraph_every must be positive")


@dataclass(frozen=True)
class DistributedIterationRecord:
    iteration: int
    local_objective: float
    global_objective_estimate: float
    primal_residual: float
    dual_residual: float
    maximum_capacity_residual: float
    decision_residual: float
    active_uav_count: int
    active_hyperedge_count: int
    communication_messages: int
    communication_bytes: int
    local_solver_failures: int
    stale_update_skips: int
    dual_step_size: float
    solver_time_s: float


@dataclass(frozen=True)
class DistributedSolverResult:
    decisions: dict[str, UAVDecisionVariables]
    duals: ResourceTimeDualVariables
    converged: bool
    stopping_reason: str
    iterations: int
    runtime_s: float
    history: tuple[DistributedIterationRecord, ...]
    final_hypergraph: CapacityConflictHypergraph
    solver_failure_fallbacks: int
    warm_start_used: bool
    exact_verification_safe: bool | None
    atomic_commit_success: bool | None
    accepted_for_execution: bool
    coordination_mode: str = "hypergraph"
    deadline_exceeded: bool = False


class HypergraphDistributedPrimalDualSolver:
    """Sparse Phase 4 solver whose updates are selected by capacity hyperedges."""

    def __init__(
        self,
        problem: HyperCertProblemDefinition,
        config: DistributedSolverConfig | None = None,
        step_size_policy: AdaptiveStepSizePolicy | None = None,
    ) -> None:
        self.problem = problem
        self.config = config or DistributedSolverConfig()
        self.builder = CapacityConflictHypergraphBuilder(problem)
        self.occupancy = SoftOccupancyModel(problem)
        self.local_solver = LocalSubproblemSolver(problem)
        settings = problem.config.solver
        self.step_size_policy = step_size_policy or AdaptiveStepSizePolicy(
            initial_step=settings.dual_step_size
        )

    def solve(
        self,
        initial_decisions: Mapping[str, UAVDecisionVariables],
        warm_start: HyperCertWarmStart | None = None,
        exact_verifier: ExactVerifier | None = None,
        atomic_committer: AtomicCommitter | None = None,
        optimization_uav_ids: tuple[str, ...] | None = None,
        optimization_resource_ids: tuple[str, ...] | None = None,
        deadline_s: float | None = None,
    ) -> DistributedSolverResult:
        self.problem.validate_decisions(initial_decisions)
        known_uavs = {uav.uav_id for uav in self.problem.uavs}
        known_resources = set(self.problem.resource_ids)
        uav_scope = known_uavs if optimization_uav_ids is None else set(optimization_uav_ids)
        resource_scope = known_resources if optimization_resource_ids is None else set(optimization_resource_ids)
        if not uav_scope <= known_uavs:
            raise ValueError(f"optimization scope has unknown UAVs: {sorted(uav_scope - known_uavs)}")
        if not resource_scope <= known_resources:
            raise ValueError(
                f"optimization scope has unknown resources: {sorted(resource_scope - known_resources)}"
            )
        warm_start_used = warm_start is not None
        if warm_start is not None:
            warm_start.validate(self.problem)
            decisions = warm_start.copied_decisions()
            duals = warm_start.duals.copy()
        else:
            decisions = {
                uav_id: decision.with_continuous_vector(decision.continuous_vector().copy())
                for uav_id, decision in initial_decisions.items()
            }
            duals = ResourceTimeDualVariables.zeros(self.problem.resource_ids, self.problem.time_grid_s)

        settings = self.problem.config.solver
        async_config = self.config.asynchronous
        maximum_delay = (
            0
            if self.config.update_mode == "synchronous"
            else async_config.maximum_communication_delay_iterations
        )
        ledger = MessageLedger(maximum_delay)
        scheduler = DeterministicAsynchronousScheduler(async_config)
        stale_store = BoundedStaleDualStore(
            tuple(uav.uav_id for uav in self.problem.uavs),
            duals,
            async_config.maximum_stale_iterations,
        )
        history: list[DistributedIterationRecord] = []
        fallbacks = 0
        stable_count = 0
        previous_primal = 1.0
        previous_dual = 1.0
        graph = (
            CapacityConflictHypergraph(tuple(sorted(known_uavs)), tuple())
            if self.config.coordination_mode == "global"
            else self.builder.build(decisions, duals)
        )
        start_time = perf_counter()
        deadline_exceeded = False

        for iteration in range(1, settings.max_iterations + 1):
            if deadline_s is not None and perf_counter() >= deadline_s:
                deadline_exceeded = True
                break
            iteration_start = perf_counter()
            for message in ledger.deliver_ready(iteration):
                stale_store.apply(message)
            if (
                self.config.coordination_mode == "hypergraph"
                and (iteration == 1 or iteration % self.config.rebuild_hypergraph_every == 0)
            ):
                graph = self.builder.build(decisions, duals)

            if self.config.coordination_mode == "global":
                uav_occupancies = {
                    uav.uav_id: self.occupancy.occupancy_by_resource_for_uav(
                        self._uav_index(uav.uav_id),
                        decisions[uav.uav_id],
                    )
                    for uav in self.problem.uavs
                    if uav.uav_id in uav_scope
                }
                messages = build_global_coordination_messages(
                    tuple(sorted(uav_scope)),
                    tuple(sorted(resource_scope)),
                    iteration,
                    maximum_delay,
                    duals.values,
                    uav_occupancies,
                )
            else:
                messages = build_hyperedge_messages(
                    graph,
                    iteration,
                    maximum_delay,
                    duals.values,
                )
            if optimization_uav_ids is not None or optimization_resource_ids is not None:
                messages = tuple(
                    message
                    for message in messages
                    if (
                        message.payload.get("uav_id") in uav_scope
                        and message.payload.get("resource_id") in resource_scope
                    )
                )
            for message in messages:
                ledger.enqueue(message)
            for message in ledger.deliver_ready(iteration):
                stale_store.apply(message)

            graph_active_uavs = (
                tuple(sorted(uav_scope))
                if self.config.coordination_mode == "global"
                else tuple(sorted(set(graph.uavs_to_solve()).intersection(uav_scope)))
            )
            if optimization_uav_ids is not None:
                graph_active_uavs = tuple(sorted(set(graph_active_uavs).union(uav_scope)))
            graph_active_resources = (
                tuple(sorted(resource_scope))
                if self.config.coordination_mode == "global"
                else tuple(sorted(set(graph.resources_to_update()).intersection(resource_scope)))
            )
            if optimization_resource_ids is not None:
                graph_active_resources = tuple(
                    sorted(set(graph_active_resources).union(resource_scope))
                )
            if self.config.update_mode == "asynchronous":
                selected_uavs = scheduler.select_uavs(graph_active_uavs, iteration)
                selected_resources = scheduler.select_resources(graph_active_resources, iteration)
            else:
                selected_uavs = graph_active_uavs
                selected_resources = graph_active_resources

            weighted_delays = np.asarray(
                [uav.priority_weight * decisions[uav.uav_id].departure_delay_s for uav in self.problem.uavs]
            )
            fairness_reference = float(np.mean(weighted_delays))
            previous_decisions = decisions
            next_decisions = dict(previous_decisions)
            local_objective = 0.0
            local_failures = 0
            stale_skips = 0
            for uav_id in selected_uavs:
                uav_index = self._uav_index(uav_id)
                current = previous_decisions[uav_id]
                local_duals = duals
                if self.config.update_mode == "asynchronous":
                    required_resources = (
                        tuple(sorted(resource_scope))
                        if self.config.coordination_mode == "global"
                        else tuple(
                            sorted({edge.resource_id for edge in graph.incident_hyperedges(uav_id)})
                        )
                    )
                    local_duals, stale_resources = stale_store.duals_for_uav(
                        uav_id,
                        iteration,
                        required_resources,
                    )
                    if local_duals is None:
                        stale_skips += 1
                        fallbacks += 1
                        continue
                local = self.local_solver.solve(
                    uav_index,
                    current,
                    previous_decisions,
                    local_duals,
                    fairness_reference,
                )
                local_objective += local.local_objective + local.resource_price_cost
                if not local.success:
                    local_failures += 1
                    fallbacks += 1
                    continue
                current_vector = current.continuous_vector()
                candidate_vector = local.decision.continuous_vector()
                relaxed = current_vector + settings.primal_relaxation * (
                    candidate_vector - current_vector
                )
                next_decisions[uav_id] = current.with_continuous_vector(relaxed)
            decisions = next_decisions

            residual = self.occupancy.capacity_residual(decisions)
            active_residual = {
                resource_id: (
                    values if resource_id in selected_resources else np.zeros_like(values)
                )
                for resource_id, values in residual.items()
            }
            step_size = self.step_size_policy.update(iteration, previous_primal, previous_dual)
            dual_update = duals.update(active_residual, step_size)
            previous_primal = dual_update.primal_residual
            previous_dual = dual_update.dual_residual
            decision_residual = max(
                (
                    float(
                        np.max(
                            np.abs(
                                decisions[uav.uav_id].continuous_vector()
                                - previous_decisions[uav.uav_id].continuous_vector()
                            ),
                            initial=0.0,
                        )
                    )
                    for uav in self.problem.uavs
                ),
                default=0.0,
            )
            record = DistributedIterationRecord(
                iteration=iteration,
                local_objective=float(local_objective),
                global_objective_estimate=self.problem.global_objective(decisions),
                primal_residual=dual_update.primal_residual,
                dual_residual=dual_update.dual_residual,
                maximum_capacity_residual=max(
                    0.0,
                    max(float(np.max(values, initial=0.0)) for values in residual.values()),
                ),
                decision_residual=decision_residual,
                active_uav_count=len(selected_uavs),
                active_hyperedge_count=(
                    len(resource_scope)
                    if self.config.coordination_mode == "global"
                    else len(graph.hyperedges)
                ),
                communication_messages=len(messages),
                communication_bytes=sum(message.size_bytes for message in messages),
                local_solver_failures=local_failures,
                stale_update_skips=stale_skips,
                dual_step_size=step_size,
                solver_time_s=perf_counter() - iteration_start,
            )
            history.append(record)
            within_tolerance = (
                iteration >= settings.minimum_iterations
                and record.primal_residual <= settings.primal_tolerance
                and record.maximum_capacity_residual <= settings.primal_tolerance
                and record.dual_residual <= settings.dual_tolerance
                and record.decision_residual <= settings.decision_tolerance
            )
            stable_count = stable_count + 1 if within_tolerance else 0
            if stable_count >= settings.stable_iterations_required:
                break

        converged = stable_count >= settings.stable_iterations_required
        stopping_reason = (
            "deadline_exceeded"
            if deadline_exceeded
            else ("residual_tolerance" if converged else "maximum_iterations")
        )
        final_graph = (
            graph
            if deadline_exceeded or self.config.coordination_mode == "global"
            else self.builder.build(decisions, duals)
        )

        exact_safe = (
            exact_verifier(decisions)
            if exact_verifier is not None and not deadline_exceeded
            else None
        )
        atomic_success = None
        if exact_safe is True and atomic_committer is not None:
            atomic_success = bool(atomic_committer(decisions))
        accepted = bool(converged and exact_safe is True and atomic_success is True)
        return DistributedSolverResult(
            decisions=decisions,
            duals=duals,
            converged=converged,
            stopping_reason=stopping_reason,
            iterations=len(history),
            runtime_s=perf_counter() - start_time,
            history=tuple(history),
            final_hypergraph=final_graph,
            solver_failure_fallbacks=fallbacks,
            warm_start_used=warm_start_used,
            exact_verification_safe=exact_safe,
            atomic_commit_success=atomic_success,
            accepted_for_execution=accepted,
            coordination_mode=self.config.coordination_mode,
            deadline_exceeded=deadline_exceeded,
        )

    def _uav_index(self, uav_id: str) -> int:
        for index, uav in enumerate(self.problem.uavs):
            if uav.uav_id == uav_id:
                return index
        raise KeyError(uav_id)
