from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

import numpy as np


@dataclass(frozen=True)
class DualUpdateResult:
    primal_residual: float
    dual_residual: float
    maximum_capacity_residual: float
    active_price_samples: int


@dataclass
class ResourceTimeDualVariables:
    time_grid_s: np.ndarray
    values: dict[str, np.ndarray]

    def __post_init__(self) -> None:
        self.time_grid_s = np.asarray(self.time_grid_s, dtype=float).reshape(-1).copy()
        if len(self.time_grid_s) < 2 or np.any(np.diff(self.time_grid_s) <= 0.0):
            raise ValueError("dual time grid must be strictly increasing")
        converted = {}
        for resource_id, value in self.values.items():
            array = np.asarray(value, dtype=float).reshape(-1).copy()
            if array.shape != self.time_grid_s.shape:
                raise ValueError(f"dual shape for {resource_id} does not match the time grid")
            if np.any(array < 0.0):
                raise ValueError("resource-time dual prices must be nonnegative")
            converted[resource_id] = array
        self.values = converted

    @classmethod
    def zeros(cls, resource_ids: tuple[str, ...], time_grid_s: np.ndarray) -> "ResourceTimeDualVariables":
        grid = np.asarray(time_grid_s, dtype=float)
        return cls(grid, {resource_id: np.zeros_like(grid) for resource_id in resource_ids})

    def copy(self) -> "ResourceTimeDualVariables":
        return ResourceTimeDualVariables(self.time_grid_s, {key: value.copy() for key, value in self.values.items()})

    def update(
        self,
        capacity_residual: Mapping[str, np.ndarray],
        step_size: float,
    ) -> DualUpdateResult:
        if step_size <= 0.0:
            raise ValueError("dual step size must be positive")
        old = {resource_id: value.copy() for resource_id, value in self.values.items()}
        positive_residuals = []
        all_residuals = []
        for resource_id, price in self.values.items():
            residual = np.asarray(capacity_residual[resource_id], dtype=float)
            if residual.shape != price.shape:
                raise ValueError(f"capacity residual shape for {resource_id} does not match dual prices")
            all_residuals.append(residual)
            positive_residuals.append(np.maximum(residual, 0.0))
            self.values[resource_id] = np.maximum(0.0, price + step_size * residual)
        positive = np.concatenate(positive_residuals) if positive_residuals else np.empty(0)
        residual_values = np.concatenate(all_residuals) if all_residuals else np.empty(0)
        dual_delta = np.concatenate(
            [self.values[resource_id] - old[resource_id] for resource_id in self.values]
        )
        return DualUpdateResult(
            primal_residual=float(np.sqrt(np.mean(positive**2))) if positive.size else 0.0,
            dual_residual=float(np.sqrt(np.mean(dual_delta**2))) if dual_delta.size else 0.0,
            maximum_capacity_residual=max(0.0, float(np.max(residual_values, initial=0.0))),
            active_price_samples=int(sum(np.count_nonzero(value > 0.0) for value in self.values.values())),
        )

    def peak_price(self, resource_id: str) -> float:
        return float(np.max(self.values[resource_id], initial=0.0))

    def as_mapping(self) -> Mapping[str, np.ndarray]:
        return self.values

