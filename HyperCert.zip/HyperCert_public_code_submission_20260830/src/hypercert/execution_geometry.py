from __future__ import annotations

import numpy as np

from certificate.continuous_occupancy_extractor import (
    ContinuousResource,
    PolylineTubeResource,
    SphericalResource,
)
from corridor.topology import CorridorGraph

from .closed_loop_validation import (
    MinimumSnapTrajectory,
    generate_phased_minimum_snap_trajectory,
)
from .decision_variables import UAVDecisionVariables
from .problem_definition import HyperCertProblemDefinition


def build_corridor_resource_geometry(
    problem: HyperCertProblemDefinition,
    graph: CorridorGraph,
) -> tuple[ContinuousResource, ...]:
    """Create explicit conservative geometry for every abstract resource."""

    resources = []
    for resource in problem.resources:
        kind, source_id = resource.resource_id.split(":", 1)
        if kind == "edge":
            edge = graph.edges[source_id]
            radius = 0.5 * float(edge.width)
            spacing = max(1.0, min(5.0, radius))
            resources.append(
                PolylineTubeResource(
                    resource.resource_id,
                    np.asarray(edge.centerline, dtype=float),
                    radius,
                    spacing,
                ).as_resource()
            )
        elif kind == "node":
            node = graph.nodes[source_id]
            adjacent_widths = [
                float(edge.width)
                for edge in graph.edges.values()
                if edge.start == source_id or edge.end == source_id
            ]
            radius = (
                max(2.0, 0.4 * min(adjacent_widths))
                if adjacent_widths
                else 5.0
            )
            resources.append(
                SphericalResource(
                    resource.resource_id,
                    np.asarray(node.position, dtype=float),
                    radius,
                    kind="node",
                ).as_resource()
            )
        else:
            raise ValueError(f"unsupported corridor resource kind: {kind}")
    return tuple(resources)


def build_route_execution_trajectory(
    problem: HyperCertProblemDefinition,
    graph: CorridorGraph,
    uav_index: int,
    decision: UAVDecisionVariables,
) -> MinimumSnapTrajectory:
    """Map route, per-edge traversal time, and holding into one execution path."""

    uav = problem.uavs[uav_index]
    route = uav.route(decision.route_index)
    phases: list[tuple[np.ndarray, float]] = []
    current_position: np.ndarray | None = None
    for edge_index, encoded_edge_id in enumerate(route.edge_ids):
        duration = float(decision.edge_travel_times_s[edge_index])
        if encoded_edge_id.startswith("travel:"):
            source_id = encoded_edge_id.split(":", 1)[1]
            waypoints = np.asarray(graph.edges[source_id].centerline, dtype=float)
            if current_position is not None and not np.allclose(
                waypoints[0],
                current_position,
                atol=1e-8,
            ):
                raise ValueError(
                    f"route execution discontinuity before edge {source_id}"
                )
            phases.append((waypoints, duration))
            current_position = waypoints[-1]
        elif encoded_edge_id.startswith("node_visit:"):
            parts = encoded_edge_id.split(":")
            node_id = parts[1]
            node_position = np.asarray(graph.nodes[node_id].position, dtype=float)
            if current_position is not None and not np.allclose(
                node_position,
                current_position,
                atol=1e-8,
            ):
                raise ValueError(
                    f"route execution discontinuity at node {node_id}"
                )
            phases.append((node_position.reshape(1, 3), duration))
            current_position = node_position
        else:
            raise ValueError(f"unsupported encoded route edge: {encoded_edge_id}")

        if edge_index < len(decision.holding_times_s):
            holding = float(decision.holding_times_s[edge_index])
            numerical_zero_s = max(
                1e-9,
                float(problem.config.constraint_tolerance),
            )
            if holding > numerical_zero_s:
                if current_position is None:
                    raise ValueError("holding phase has no route position")
                phases.append((current_position.reshape(1, 3), holding))

    return generate_phased_minimum_snap_trajectory(
        tuple(phases),
        start_time_s=uav.release_time_s + decision.departure_delay_s,
    )
