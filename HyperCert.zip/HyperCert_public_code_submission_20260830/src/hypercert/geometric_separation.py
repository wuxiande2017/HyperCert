from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
import hashlib
from itertools import combinations
from typing import Mapping, Sequence

import numpy as np

from .closed_loop_validation import MinimumSnapTrajectory
from .polynomial_occupancy import (
    _power_coefficients_on_unit_interval,
    _power_to_bernstein,
)


@dataclass(frozen=True)
class PairwiseSeparationResult:
    first_uav_id: str
    second_uav_id: str
    required_reference_separation_m: float
    minimum_sampled_separation_m: float
    certified_safe: bool
    confirmed_violation: bool
    unresolved_leaf_count: int
    critical_start_time_s: float = 0.0
    critical_end_time_s: float = 0.0
    critical_lower_bound_distance_m: float = float("inf")
    critical_first_segment: int = 0
    critical_second_segment: int = 0


@dataclass(frozen=True)
class ContinuousSeparationResult:
    pairs: tuple[PairwiseSeparationResult, ...]

    @property
    def certified_safe(self) -> bool:
        return all(pair.certified_safe for pair in self.pairs)

    @property
    def confirmed_violation_pairs(self) -> int:
        return sum(pair.confirmed_violation for pair in self.pairs)

    @property
    def unresolved_pairs(self) -> int:
        return sum(
            not pair.certified_safe and not pair.confirmed_violation
            for pair in self.pairs
        )

    @property
    def minimum_sampled_separation_m(self) -> float:
        return min(
            (
                pair.minimum_sampled_separation_m
                for pair in self.pairs
            ),
            default=float("inf"),
        )


@dataclass(frozen=True)
class GeometricAdmissionResult:
    accepted_uav_ids: tuple[str, ...]
    rejected_uav_ids: tuple[str, ...]
    initial_separation: ContinuousSeparationResult
    final_separation: ContinuousSeparationResult


@dataclass(frozen=True)
class SeparationCacheStats:
    hits: int
    misses: int
    evictions: int
    entries: int


class ContinuousSeparationVerifier:
    """Conservative pairwise verifier with a stable polynomial-pair cache."""

    def __init__(
        self,
        *,
        temporal_tolerance_s: float = 1e-4,
        distance_tolerance_m: float = 1e-6,
        maximum_subdivision_depth: int = 24,
        cache_capacity: int = 8_192,
        enable_cache: bool = True,
    ) -> None:
        if min(temporal_tolerance_s, distance_tolerance_m) <= 0.0:
            raise ValueError("separation tolerances must be positive")
        if maximum_subdivision_depth <= 0 or cache_capacity <= 0:
            raise ValueError("separation depth and cache capacity must be positive")
        self.temporal_tolerance_s = float(temporal_tolerance_s)
        self.distance_tolerance_m = float(distance_tolerance_m)
        self.maximum_subdivision_depth = int(maximum_subdivision_depth)
        self.cache_capacity = int(cache_capacity)
        self.enable_cache = bool(enable_cache)
        self._cache: OrderedDict[tuple[object, ...], PairwiseSeparationResult] = (
            OrderedDict()
        )
        self._hits = 0
        self._misses = 0
        self._evictions = 0

    def verify(
        self,
        trajectories: Mapping[str, MinimumSnapTrajectory],
        *,
        minimum_separation_m: float,
        tracking_bounds_m: Mapping[str, float] | None = None,
    ) -> ContinuousSeparationResult:
        if minimum_separation_m < 0.0:
            raise ValueError("minimum_separation_m must be nonnegative")
        bounds = tracking_bounds_m or {}
        results = []
        for (first_id, first), (second_id, second) in combinations(
            sorted(trajectories.items()),
            2,
        ):
            required = (
                float(minimum_separation_m)
                + float(bounds.get(first_id, 0.0))
                + float(bounds.get(second_id, 0.0))
            )
            key = (
                first_id,
                polynomial_trajectory_fingerprint(first),
                second_id,
                polynomial_trajectory_fingerprint(second),
                required,
                self.temporal_tolerance_s,
                self.distance_tolerance_m,
                self.maximum_subdivision_depth,
            )
            pair = self._cache.get(key) if self.enable_cache else None
            if pair is None:
                self._misses += 1
                pair = _verify_pair(
                    first_id,
                    first,
                    second_id,
                    second,
                    required,
                    self.temporal_tolerance_s,
                    self.distance_tolerance_m,
                    self.maximum_subdivision_depth,
                )
                if self.enable_cache:
                    self._cache[key] = pair
                    if len(self._cache) > self.cache_capacity:
                        self._cache.popitem(last=False)
                        self._evictions += 1
            else:
                self._hits += 1
                self._cache.move_to_end(key)
            results.append(pair)
        return ContinuousSeparationResult(tuple(results))

    @property
    def cache_stats(self) -> SeparationCacheStats:
        return SeparationCacheStats(
            hits=self._hits,
            misses=self._misses,
            evictions=self._evictions,
            entries=len(self._cache),
        )

    def clear_cache(self) -> None:
        self._cache.clear()
        self._hits = 0
        self._misses = 0
        self._evictions = 0


def apply_conservative_geometric_admission_gate(
    trajectories: Mapping[str, MinimumSnapTrajectory],
    *,
    minimum_separation_m: float,
    tracking_bounds_m: Mapping[str, float] | None = None,
    rejection_order: Sequence[str],
    temporal_tolerance_s: float = 1e-4,
    distance_tolerance_m: float = 1e-6,
    maximum_subdivision_depth: int = 24,
    verifier: ContinuousSeparationVerifier | None = None,
) -> GeometricAdmissionResult:
    """Reject lower-priority trajectories until pairwise safety is certified."""

    trajectory_ids = set(trajectories)
    if set(rejection_order) != trajectory_ids:
        raise ValueError("rejection_order must contain every trajectory exactly once")
    if len(rejection_order) != len(trajectory_ids):
        raise ValueError("rejection_order contains duplicate UAV identifiers")
    rank = {
        uav_id: index
        for index, uav_id in enumerate(rejection_order)
    }
    accepted = set(trajectory_ids)
    active_verifier = verifier or ContinuousSeparationVerifier(
        temporal_tolerance_s=temporal_tolerance_s,
        distance_tolerance_m=distance_tolerance_m,
        maximum_subdivision_depth=maximum_subdivision_depth,
    )

    def verify() -> ContinuousSeparationResult:
        return active_verifier.verify(
            {
                uav_id: trajectories[uav_id]
                for uav_id in sorted(accepted)
            },
            minimum_separation_m=minimum_separation_m,
            tracking_bounds_m=tracking_bounds_m,
        )

    initial = verify()
    current = initial
    rejected = []
    while not current.certified_safe:
        unsafe_pair = next(
            pair
            for pair in current.pairs
            if not pair.certified_safe
        )
        removed = min(
            (unsafe_pair.first_uav_id, unsafe_pair.second_uav_id),
            key=lambda uav_id: rank[uav_id],
        )
        accepted.remove(removed)
        rejected.append(removed)
        current = verify()
    return GeometricAdmissionResult(
        accepted_uav_ids=tuple(sorted(accepted)),
        rejected_uav_ids=tuple(rejected),
        initial_separation=initial,
        final_separation=current,
    )


def verify_continuous_separation(
    trajectories: Mapping[str, MinimumSnapTrajectory],
    *,
    minimum_separation_m: float,
    tracking_bounds_m: Mapping[str, float] | None = None,
    temporal_tolerance_s: float = 1e-4,
    distance_tolerance_m: float = 1e-6,
    maximum_subdivision_depth: int = 24,
) -> ContinuousSeparationResult:
    """Conservatively verify pairwise separation of polynomial references."""

    return ContinuousSeparationVerifier(
        temporal_tolerance_s=temporal_tolerance_s,
        distance_tolerance_m=distance_tolerance_m,
        maximum_subdivision_depth=maximum_subdivision_depth,
    ).verify(
        trajectories,
        minimum_separation_m=minimum_separation_m,
        tracking_bounds_m=tracking_bounds_m,
    )


def polynomial_trajectory_fingerprint(
    trajectory: MinimumSnapTrajectory,
) -> str:
    digest = hashlib.sha256()
    digest.update(
        np.asarray(trajectory.segment_start_times_s, dtype=np.float64).tobytes()
    )
    digest.update(
        np.asarray(trajectory.segment_durations_s, dtype=np.float64).tobytes()
    )
    digest.update(np.asarray(trajectory.coefficients, dtype=np.float64).tobytes())
    return digest.hexdigest()


def _verify_pair(
    first_id: str,
    first: MinimumSnapTrajectory,
    second_id: str,
    second: MinimumSnapTrajectory,
    required_m: float,
    temporal_tolerance_s: float,
    distance_tolerance_m: float,
    maximum_depth: int,
) -> PairwiseSeparationResult:
    overlap_start = max(first.start_time_s, second.start_time_s)
    overlap_end = min(first.end_time_s, second.end_time_s)
    if overlap_end <= overlap_start:
        return PairwiseSeparationResult(
            first_id,
            second_id,
            required_m,
            float("inf"),
            True,
            False,
            0,
            overlap_start,
            overlap_start,
            float("inf"),
            0,
            0,
        )

    boundaries = sorted(
        {
            overlap_start,
            overlap_end,
            *(
                float(value)
                for value in first.segment_start_times_s[1:]
                if overlap_start < value < overlap_end
            ),
            *(
                float(value)
                for value in second.segment_start_times_s[1:]
                if overlap_start < value < overlap_end
            ),
        }
    )
    confirmed = False
    unresolved = 0
    minimum_sampled = float("inf")
    critical_start = overlap_start
    critical_end = overlap_end
    critical_lower_bound = float("inf")
    critical_first_segment = 0
    critical_second_segment = 0

    def recurse(
        left_s: float,
        right_s: float,
        first_segment: int,
        second_segment: int,
        depth: int,
    ) -> None:
        nonlocal confirmed, unresolved, minimum_sampled
        nonlocal critical_start, critical_end, critical_lower_bound
        nonlocal critical_first_segment, critical_second_segment
        if confirmed:
            return
        first_power = _power_coefficients_on_unit_interval(
            first.coefficients[first_segment],
            left_s - first.segment_start_times_s[first_segment],
            right_s - first.segment_start_times_s[first_segment],
        )
        second_power = _power_coefficients_on_unit_interval(
            second.coefficients[second_segment],
            left_s - second.segment_start_times_s[second_segment],
            right_s - second.segment_start_times_s[second_segment],
        )
        relative_controls = _power_to_bernstein(first_power - second_power)
        lower_bound = _distance_from_origin_to_aabb(relative_controls)
        sample_times = (left_s, 0.5 * (left_s + right_s), right_s)
        sampled_distances = tuple(
            float(
                np.linalg.norm(
                    first.evaluate(time_s, 0)
                    - second.evaluate(time_s, 0)
                )
            )
            for time_s in sample_times
        )
        sampled = min(sampled_distances)
        minimum_sampled = min(minimum_sampled, sampled)
        if lower_bound < critical_lower_bound:
            critical_start = left_s
            critical_end = right_s
            critical_lower_bound = lower_bound
            critical_first_segment = first_segment
            critical_second_segment = second_segment
        if sampled < required_m - distance_tolerance_m:
            confirmed = True
            sample_index = int(np.argmin(sampled_distances))
            critical_start = sample_times[sample_index]
            critical_end = sample_times[sample_index]
            critical_lower_bound = min(lower_bound, sampled)
            critical_first_segment = first_segment
            critical_second_segment = second_segment
            return
        if lower_bound >= required_m - distance_tolerance_m:
            return
        if (
            right_s - left_s <= temporal_tolerance_s
            or depth >= maximum_depth
        ):
            unresolved += 1
            return
        midpoint = 0.5 * (left_s + right_s)
        recurse(
            left_s,
            midpoint,
            first_segment,
            second_segment,
            depth + 1,
        )
        recurse(
            midpoint,
            right_s,
            first_segment,
            second_segment,
            depth + 1,
        )

    for left_s, right_s in zip(boundaries[:-1], boundaries[1:]):
        midpoint = 0.5 * (left_s + right_s)
        first_segment = _segment_index(first, midpoint)
        second_segment = _segment_index(second, midpoint)
        recurse(left_s, right_s, first_segment, second_segment, 0)
        if confirmed:
            break
    safe = not confirmed and unresolved == 0
    return PairwiseSeparationResult(
        first_id,
        second_id,
        required_m,
        minimum_sampled,
        safe,
        confirmed,
        unresolved,
        critical_start,
        critical_end,
        critical_lower_bound,
        critical_first_segment,
        critical_second_segment,
    )


def _segment_index(
    trajectory: MinimumSnapTrajectory,
    time_s: float,
) -> int:
    return int(
        np.searchsorted(
            trajectory.segment_start_times_s[1:],
            time_s,
            side="right",
        )
    )


def _distance_from_origin_to_aabb(points: np.ndarray) -> float:
    lower = np.min(points, axis=0)
    upper = np.max(points, axis=0)
    closest = np.where(lower > 0.0, lower, np.where(upper < 0.0, upper, 0.0))
    return float(np.linalg.norm(closest))
