from __future__ import annotations

from dataclasses import dataclass, field
import heapq
from time import perf_counter
from typing import Callable, Mapping, Protocol

import numpy as np

from .conflict_hypergraph import CapacityConflictHyperedge
from .decision_variables import UAVDecisionVariables
from .distributed_solver import (
    AtomicCommitter,
    DistributedSolverResult,
    ExactVerifier,
    HypergraphDistributedPrimalDualSolver,
)
from .dual_variables import ResourceTimeDualVariables
from .problem_definition import HyperCertProblemDefinition
from .reduced_cost_route_selector import ReducedCostRouteSelector, RouteReducedCost
from .soft_occupancy import SoftOccupancyModel
from .warm_start import HyperCertWarmStart


class ContinuousTimingSolver(Protocol):
    def solve(
        self,
        initial_decisions: Mapping[str, UAVDecisionVariables],
        warm_start: HyperCertWarmStart | None = None,
        exact_verifier: ExactVerifier | None = None,
        atomic_committer: AtomicCommitter | None = None,
    ) -> DistributedSolverResult: ...


@dataclass(frozen=True)
class HypergraphBranchingConfig:
    maximum_route_iterations: int = 8
    highest_price_hyperedge_count: int = 3
    maximum_assignment_changes_per_iteration: int = 1
    minimum_reduced_cost_improvement: float = 1e-4

    def __post_init__(self) -> None:
        values = (
            self.maximum_route_iterations,
            self.highest_price_hyperedge_count,
            self.maximum_assignment_changes_per_iteration,
        )
        if min(values) <= 0:
            raise ValueError("hypergraph branching limits must be positive")
        if self.minimum_reduced_cost_improvement < 0.0:
            raise ValueError("minimum reduced-cost improvement cannot be negative")


@dataclass(frozen=True)
class RouteChangeRecord:
    route_iteration: int
    uav_id: str
    from_route_id: str
    to_route_id: str
    from_route_index: int
    to_route_index: int
    from_altitude_layer_index: int
    to_altitude_layer_index: int
    reason: str
    triggering_hyperedge_ids: tuple[str, ...]
    triggering_resource_ids: tuple[str, ...]
    reduced_cost_before: float
    reduced_cost_after: float
    resource_price_before: float
    resource_price_after: float
    objective_before: float
    objective_after: float
    objective_change: float
    overload_integral_before: float
    overload_integral_after: float
    overload_relief: float
    additional_travel_distance_m: float


@dataclass(frozen=True)
class HypergraphBranchingResult:
    decisions: dict[str, UAVDecisionVariables]
    duals: ResourceTimeDualVariables
    continuous_result: DistributedSolverResult
    route_changes: tuple[RouteChangeRecord, ...]
    route_iterations: int
    continuous_solves: int
    route_assignments_stable: bool
    stopping_reason: str
    exact_verification_safe: bool | None
    atomic_commit_success: bool | None
    accepted_for_execution: bool
    deadline_exceeded: bool = False


class HypergraphBranchAndOptimize:
    """Sparse route/altitude updates around the Phase 4 timing solver."""

    def __init__(
        self,
        problem: HyperCertProblemDefinition,
        config: HypergraphBranchingConfig | None = None,
        continuous_solver: ContinuousTimingSolver | None = None,
    ) -> None:
        self.problem = problem
        self.config = config or HypergraphBranchingConfig()
        self.continuous_solver = continuous_solver or HypergraphDistributedPrimalDualSolver(problem)
        self.selector = ReducedCostRouteSelector(
            problem,
            minimum_improvement=self.config.minimum_reduced_cost_improvement,
        )
        self.occupancy = SoftOccupancyModel(problem)

    def solve(
        self,
        initial_decisions: Mapping[str, UAVDecisionVariables],
        warm_start: HyperCertWarmStart | None = None,
        exact_verifier: ExactVerifier | None = None,
        atomic_committer: AtomicCommitter | None = None,
        deadline_s: float | None = None,
    ) -> HypergraphBranchingResult:
        self.problem.validate_decisions(initial_decisions)
        solve_kwargs = {"warm_start": warm_start}
        if deadline_s is not None:
            solve_kwargs["deadline_s"] = deadline_s
        continuous = self.continuous_solver.solve(initial_decisions, **solve_kwargs)
        continuous_solves = 1
        changes: list[RouteChangeRecord] = []
        seen_assignments = {self._assignment_signature(continuous.decisions)}
        stable = False
        stopping_reason = "route_iteration_limit"
        route_iterations = 0
        deadline_exceeded = bool(continuous.deadline_exceeded)

        for route_iteration in range(1, self.config.maximum_route_iterations + 1):
            if deadline_exceeded or (
                deadline_s is not None and perf_counter() >= deadline_s
            ):
                deadline_exceeded = True
                stopping_reason = "deadline_exceeded"
                break
            route_iterations = route_iteration
            targets = self._highest_price_hyperedges(continuous)
            if not targets:
                stable = True
                stopping_reason = "no_active_high_price_hyperedges"
                break
            selections = self._route_selections(continuous, targets)
            improving = [selection for selection in selections if selection[1].changes_assignment]
            improving.sort(key=lambda item: (-item[1].improvement, item[0]))
            selected = improving[: self.config.maximum_assignment_changes_per_iteration]
            if not selected:
                stable = True
                stopping_reason = "no_improving_reduced_cost_assignment"
                break

            before_decisions = continuous.decisions
            before_duals = continuous.duals.copy()
            before_objective = self.problem.global_objective(before_decisions)
            before_overload = self._overload_integral(before_decisions)
            next_decisions = dict(before_decisions)
            for uav_id, selection, _ in selected:
                next_decisions[uav_id] = selection.selected.candidate_decision
            signature = self._assignment_signature(next_decisions)
            if signature in seen_assignments:
                stopping_reason = "route_assignment_cycle"
                break
            seen_assignments.add(signature)
            next_warm_start = HyperCertWarmStart(
                decisions=next_decisions,
                duals=continuous.duals.copy(),
                source_iteration=continuous.iterations,
                source_label=f"phase5_route_iteration_{route_iteration}",
            )
            solve_kwargs = {"warm_start": next_warm_start}
            if deadline_s is not None:
                solve_kwargs["deadline_s"] = deadline_s
            updated = self.continuous_solver.solve(next_decisions, **solve_kwargs)
            continuous_solves += 1
            deadline_exceeded = bool(updated.deadline_exceeded)
            after_objective = self.problem.global_objective(updated.decisions)
            after_overload = self._overload_integral(updated.decisions)
            for uav_id, selection, uav_targets in selected:
                uav_index = self._uav_index(uav_id)
                old_route = self.problem.uavs[uav_index].route(selection.incumbent.assignment.route_index)
                new_route = self.problem.uavs[uav_index].route(selection.selected.assignment.route_index)
                resource_ids = tuple(sorted({edge.resource_id for edge in uav_targets}))
                changes.append(
                    RouteChangeRecord(
                        route_iteration=route_iteration,
                        uav_id=uav_id,
                        from_route_id=old_route.route_id,
                        to_route_id=new_route.route_id,
                        from_route_index=selection.incumbent.assignment.route_index,
                        to_route_index=selection.selected.assignment.route_index,
                        from_altitude_layer_index=selection.incumbent.assignment.altitude_layer_index,
                        to_altitude_layer_index=selection.selected.assignment.altitude_layer_index,
                        reason=selection.reason,
                        triggering_hyperedge_ids=tuple(edge.hyperedge_id for edge in uav_targets),
                        triggering_resource_ids=resource_ids,
                        reduced_cost_before=selection.incumbent.total_reduced_cost,
                        reduced_cost_after=selection.selected.total_reduced_cost,
                        resource_price_before=self._peak_price(before_duals, resource_ids),
                        resource_price_after=self._peak_price(updated.duals, resource_ids),
                        objective_before=before_objective,
                        objective_after=after_objective,
                        objective_change=after_objective - before_objective,
                        overload_integral_before=before_overload,
                        overload_integral_after=after_overload,
                        overload_relief=before_overload - after_overload,
                        additional_travel_distance_m=new_route.route_length_m - old_route.route_length_m,
                    )
                )
            continuous = updated

        exact_safe = None
        atomic_success = None
        if (
            stable
            and continuous.converged
            and not deadline_exceeded
            and exact_verifier is not None
        ):
            exact_safe = bool(exact_verifier(continuous.decisions))
            if exact_safe and atomic_committer is not None:
                atomic_success = bool(atomic_committer(continuous.decisions))
        accepted = bool(stable and continuous.converged and exact_safe is True and atomic_success is True)
        return HypergraphBranchingResult(
            decisions=dict(continuous.decisions),
            duals=continuous.duals,
            continuous_result=continuous,
            route_changes=tuple(changes),
            route_iterations=route_iterations,
            continuous_solves=continuous_solves,
            route_assignments_stable=stable,
            stopping_reason=stopping_reason,
            exact_verification_safe=exact_safe,
            atomic_commit_success=atomic_success,
            accepted_for_execution=accepted,
            deadline_exceeded=deadline_exceeded,
        )

    def _highest_price_hyperedges(
        self,
        result: DistributedSolverResult,
    ) -> tuple[CapacityConflictHyperedge, ...]:
        return tuple(
            sorted(
                result.final_hypergraph.hyperedges,
                key=lambda edge: (
                    -float(np.max(edge.current_dual_price, initial=0.0)),
                    -float(np.max(edge.primal_capacity_residual, initial=0.0)),
                    edge.hyperedge_id,
                ),
            )[: self.config.highest_price_hyperedge_count]
        )

    def _route_selections(self, result, targets):
        target_by_uav: dict[str, list[CapacityConflictHyperedge]] = {}
        for edge in targets:
            for uav_id in edge.participating_uav_ids:
                target_by_uav.setdefault(uav_id, []).append(edge)
        output = []
        for uav_id in sorted(target_by_uav):
            route_indices = {result.decisions[uav_id].route_index}
            for edge in target_by_uav[uav_id]:
                route_indices.update(edge.available_route_alternatives.get(uav_id, ()))
            resources = tuple(sorted({edge.resource_id for edge in target_by_uav[uav_id]}))
            selection = self.selector.select(
                uav_id,
                result.decisions[uav_id],
                result.duals,
                route_indices=route_indices,
                triggering_resource_ids=resources,
            )
            output.append((uav_id, selection, tuple(target_by_uav[uav_id])))
        return output

    def _overload_integral(self, decisions: Mapping[str, UAVDecisionVariables]) -> float:
        residual = self.occupancy.capacity_residual(decisions)
        dt = float(np.mean(np.diff(self.problem.time_grid_s)))
        return float(sum(np.sum(np.maximum(values, 0.0)) * dt for values in residual.values()))

    @staticmethod
    def _peak_price(duals: ResourceTimeDualVariables, resource_ids: tuple[str, ...]) -> float:
        return max((duals.peak_price(resource_id) for resource_id in resource_ids), default=0.0)

    @staticmethod
    def _assignment_signature(decisions: Mapping[str, UAVDecisionVariables]) -> tuple[tuple[str, int, int], ...]:
        return tuple(
            sorted(
                (uav_id, decision.route_index, decision.altitude_layer_index)
                for uav_id, decision in decisions.items()
            )
        )

    def _uav_index(self, uav_id: str) -> int:
        for index, uav in enumerate(self.problem.uavs):
            if uav.uav_id == uav_id:
                return index
        raise KeyError(uav_id)


@dataclass(frozen=True)
class SmallInstanceBranchConfig:
    maximum_uavs: int = 8
    maximum_search_nodes: int = 256
    maximum_assignments_per_uav: int = 3
    overload_penalty: float = 10_000.0

    def __post_init__(self) -> None:
        if min(
            self.maximum_uavs,
            self.maximum_search_nodes,
            self.maximum_assignments_per_uav,
        ) <= 0:
            raise ValueError("small-instance branch limits must be positive")
        if self.overload_penalty < 0.0:
            raise ValueError("overload_penalty cannot be negative")


@dataclass(frozen=True)
class SmallInstanceBranchResult:
    decisions: dict[str, UAVDecisionVariables]
    objective_with_overload_penalty: float
    visited_search_nodes: int
    optimized_leaf_assignments: int
    search_complete: bool
    global_route_optimality_claimed: bool = field(default=False, init=False)


class SmallInstanceBranchAndOptimize:
    """Capped best-first discrete comparison; it never claims global optimality."""

    def __init__(
        self,
        problem: HyperCertProblemDefinition,
        config: SmallInstanceBranchConfig | None = None,
        solver_factory: Callable[[], ContinuousTimingSolver] | None = None,
    ) -> None:
        self.problem = problem
        self.config = config or SmallInstanceBranchConfig()
        if len(problem.uavs) > self.config.maximum_uavs:
            raise ValueError("small-instance branch mode exceeds maximum_uavs")
        self.selector = ReducedCostRouteSelector(problem)
        self.solver_factory = solver_factory or (lambda: HypergraphDistributedPrimalDualSolver(problem))
        self.occupancy = SoftOccupancyModel(problem)

    def solve(
        self,
        initial_decisions: Mapping[str, UAVDecisionVariables],
        duals: ResourceTimeDualVariables | None = None,
    ) -> SmallInstanceBranchResult:
        self.problem.validate_decisions(initial_decisions)
        prices = duals or ResourceTimeDualVariables.zeros(self.problem.resource_ids, self.problem.time_grid_s)
        choices = {
            uav.uav_id: self.selector.rank(uav.uav_id, initial_decisions[uav.uav_id], prices)[
                : self.config.maximum_assignments_per_uav
            ]
            for uav in self.problem.uavs
        }
        uav_ids = tuple(uav.uav_id for uav in self.problem.uavs)
        queue: list[tuple[float, int, int, tuple[RouteReducedCost, ...]]] = [(0.0, 0, 0, tuple())]
        serial = 1
        visited = 0
        leaves = 0
        best_decisions: dict[str, UAVDecisionVariables] | None = None
        best_score = float("inf")
        while queue and visited < self.config.maximum_search_nodes:
            bound, _, depth, selected = heapq.heappop(queue)
            visited += 1
            if depth == len(uav_ids):
                candidate = dict(initial_decisions)
                for uav_id, choice in zip(uav_ids, selected):
                    candidate[uav_id] = choice.candidate_decision
                result = self.solver_factory().solve(candidate)
                leaves += 1
                score = self.problem.global_objective(result.decisions) + self.config.overload_penalty * self._overload(result.decisions)
                if score < best_score:
                    best_score = float(score)
                    best_decisions = dict(result.decisions)
                continue
            uav_id = uav_ids[depth]
            for choice in choices[uav_id]:
                heapq.heappush(
                    queue,
                    (bound + choice.total_reduced_cost, serial, depth + 1, selected + (choice,)),
                )
                serial += 1
        if best_decisions is None:
            raise RuntimeError("small-instance branch mode reached no complete assignment")
        return SmallInstanceBranchResult(
            decisions=best_decisions,
            objective_with_overload_penalty=best_score,
            visited_search_nodes=visited,
            optimized_leaf_assignments=leaves,
            search_complete=not queue,
        )

    def _overload(self, decisions: Mapping[str, UAVDecisionVariables]) -> float:
        dt = float(np.mean(np.diff(self.problem.time_grid_s)))
        return float(
            sum(
                np.sum(np.maximum(values, 0.0)) * dt
                for values in self.occupancy.capacity_residual(decisions).values()
            )
        )
