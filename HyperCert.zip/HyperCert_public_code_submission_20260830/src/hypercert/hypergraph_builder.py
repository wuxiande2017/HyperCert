from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from typing import Mapping

import numpy as np

from .conflict_hypergraph import CapacityConflictHyperedge, CapacityConflictHypergraph
from .certificate_projection import trajectory_fingerprint
from .decision_variables import UAVDecisionVariables
from .dual_variables import ResourceTimeDualVariables
from .problem_definition import HyperCertProblemDefinition
from .soft_occupancy import SoftOccupancyModel


@dataclass(frozen=True)
class HypergraphBuilderConfig:
    participation_threshold: float = 0.05
    activation_tolerance: float = 1e-4
    marginal_epsilon_s: float = 1e-3
    occupancy_cache_capacity: int = 4_096
    enable_occupancy_cache: bool = True

    def __post_init__(self) -> None:
        if self.occupancy_cache_capacity <= 0:
            raise ValueError("occupancy_cache_capacity must be positive")


@dataclass(frozen=True)
class HypergraphBuilderCacheStats:
    hits: int
    misses: int
    evictions: int
    entries: int


class CapacityConflictHypergraphBuilder:
    def __init__(
        self,
        problem: HyperCertProblemDefinition,
        config: HypergraphBuilderConfig | None = None,
    ) -> None:
        self.problem = problem
        self.config = config or HypergraphBuilderConfig()
        self.occupancy = SoftOccupancyModel(problem)
        self._local_occupancy_cache: OrderedDict[
            str,
            dict[str, np.ndarray],
        ] = OrderedDict()
        self._cache_hits = 0
        self._cache_misses = 0
        self._cache_evictions = 0

    def build(
        self,
        decisions: Mapping[str, UAVDecisionVariables],
        duals: ResourceTimeDualVariables | None = None,
    ) -> CapacityConflictHypergraph:
        self.problem.validate_decisions(decisions)
        if duals is None:
            duals = ResourceTimeDualVariables.zeros(self.problem.resource_ids, self.problem.time_grid_s)
        local = {}
        for index, uav in enumerate(self.problem.uavs):
            key = trajectory_fingerprint(uav.uav_id, decisions[uav.uav_id])
            cached = (
                self._local_occupancy_cache.get(key)
                if self.config.enable_occupancy_cache
                else None
            )
            if cached is None:
                self._cache_misses += 1
                cached = self.occupancy.occupancy_by_resource_for_uav(
                    index,
                    decisions[uav.uav_id],
                )
                if self.config.enable_occupancy_cache:
                    self._local_occupancy_cache[key] = cached
                    if (
                        len(self._local_occupancy_cache)
                        > self.config.occupancy_cache_capacity
                    ):
                        self._local_occupancy_cache.popitem(last=False)
                        self._cache_evictions += 1
            else:
                self._cache_hits += 1
                self._local_occupancy_cache.move_to_end(key)
            local[uav.uav_id] = cached
        hyperedges: list[CapacityConflictHyperedge] = []
        grid = self.problem.time_grid_s
        dt = float(np.mean(np.diff(grid)))
        for resource in self.problem.resources:
            aggregate = sum((values[resource.resource_id] for values in local.values()), np.zeros_like(grid))
            participant_count = sum(
                (values[resource.resource_id] > self.config.participation_threshold).astype(int)
                for values in local.values()
            )
            residual = aggregate - float(resource.capacity)
            active = (residual > self.config.activation_tolerance) & (participant_count > resource.capacity)
            for episode_index, (start, stop) in enumerate(_contiguous_regions(active)):
                support_slice = slice(start, stop)
                participants = tuple(
                    sorted(
                        uav_id
                        for uav_id, values in local.items()
                        if np.max(values[resource.resource_id][support_slice], initial=0.0)
                        > self.config.participation_threshold
                    )
                )
                if len(participants) <= resource.capacity:
                    continue
                support = (float(grid[start]), float(grid[stop - 1] + dt))
                exact_nominal = self._nominal_intervals(decisions, participants, resource.resource_id, support)
                relief = self._marginal_relief(
                    decisions,
                    local,
                    aggregate,
                    resource.resource_id,
                    resource.capacity,
                    support_slice,
                    participants,
                    dt,
                )
                alternatives = {
                    uav_id: tuple(
                        route_index
                        for route_index in range(len(self.problem.uavs[self._uav_index(uav_id)].route_candidates))
                        if route_index != decisions[uav_id].route_index
                    )
                    for uav_id in participants
                }
                hyperedges.append(
                    CapacityConflictHyperedge(
                        hyperedge_id=f"{resource.resource_id}:{episode_index}:{start}-{stop}",
                        resource_id=resource.resource_id,
                        time_support_s=support,
                        resource_capacity=resource.capacity,
                        participating_uav_ids=participants,
                        soft_occupancy={
                            uav_id: local[uav_id][resource.resource_id][support_slice]
                            for uav_id in participants
                        },
                        exact_nominal_occupancy=exact_nominal,
                        primal_capacity_residual=residual[support_slice],
                        current_dual_price=duals.values[resource.resource_id][support_slice],
                        marginal_delay_relief=relief["delay"],
                        marginal_speed_relief=relief["speed"],
                        marginal_holding_relief=relief["holding"],
                        available_route_alternatives=alternatives,
                    )
                )
        return CapacityConflictHypergraph(
            uav_ids=tuple(uav.uav_id for uav in self.problem.uavs),
            hyperedges=tuple(hyperedges),
        )

    @property
    def cache_stats(self) -> HypergraphBuilderCacheStats:
        return HypergraphBuilderCacheStats(
            hits=self._cache_hits,
            misses=self._cache_misses,
            evictions=self._cache_evictions,
            entries=len(self._local_occupancy_cache),
        )

    def clear_cache(self) -> None:
        self._local_occupancy_cache.clear()
        self._cache_hits = 0
        self._cache_misses = 0
        self._cache_evictions = 0

    def _nominal_intervals(
        self,
        decisions: Mapping[str, UAVDecisionVariables],
        participants: tuple[str, ...],
        resource_id: str,
        support: tuple[float, float],
    ) -> dict[str, tuple[tuple[float, float], ...]]:
        result = {}
        for uav_id in participants:
            index = self._uav_index(uav_id)
            visits = self.occupancy.visits_for_uav(index, decisions[uav_id])
            result[uav_id] = tuple(
                (visit.nominal_enter_s, visit.nominal_exit_s)
                for visit in visits
                if visit.resource_id == resource_id
                and visit.nominal_enter_s < support[1]
                and visit.nominal_exit_s > support[0]
            )
        return result

    def _marginal_relief(
        self,
        decisions: Mapping[str, UAVDecisionVariables],
        local_occupancy: dict[str, dict[str, np.ndarray]],
        aggregate: np.ndarray,
        resource_id: str,
        capacity: int,
        support_slice: slice,
        participants: tuple[str, ...],
        dt: float,
    ) -> dict[str, dict[str, float]]:
        base = float(np.sum(np.maximum(aggregate[support_slice] - capacity, 0.0)) * dt)
        epsilon = self.config.marginal_epsilon_s
        output = {"delay": {}, "speed": {}, "holding": {}}
        for uav_id in participants:
            index = self._uav_index(uav_id)
            decision = decisions[uav_id]
            route = self.problem.uavs[index].route(decision.route_index)
            variants = {}

            delay_vector = decision.continuous_vector().copy()
            delay_vector[decision.continuous_layout.departure_delay] += epsilon
            variants["delay"] = decision.with_continuous_vector(delay_vector)

            speed_vector = decision.continuous_vector().copy()
            for edge_index, edge_resource in enumerate(route.resource_ids):
                if edge_resource != resource_id:
                    continue
                coordinate = decision.continuous_layout.edge_travel_times.start + edge_index
                speed_vector[coordinate] = max(route.min_edge_times_s[edge_index], speed_vector[coordinate] - epsilon)
            variants["speed"] = decision.with_continuous_vector(speed_vector)

            holding_vector = decision.continuous_vector().copy()
            for hold_index, allowed in enumerate(route.holding_allowed_after_edge):
                if allowed:
                    coordinate = decision.continuous_layout.holding_times.start + hold_index
                    holding_vector[coordinate] += epsilon
            variants["holding"] = decision.with_continuous_vector(holding_vector)

            original = local_occupancy[uav_id][resource_id]
            for kind, variant in variants.items():
                changed = self.occupancy.occupancy_by_resource_for_uav(index, variant)[resource_id]
                new_aggregate = aggregate - original + changed
                changed_overload = float(
                    np.sum(np.maximum(new_aggregate[support_slice] - capacity, 0.0)) * dt
                )
                output[kind][uav_id] = max(0.0, (base - changed_overload) / epsilon)
        return output

    def _uav_index(self, uav_id: str) -> int:
        for index, uav in enumerate(self.problem.uavs):
            if uav.uav_id == uav_id:
                return index
        raise KeyError(uav_id)


def _contiguous_regions(mask: np.ndarray) -> tuple[tuple[int, int], ...]:
    values = np.asarray(mask, dtype=bool)
    padded = np.concatenate(([False], values, [False])).astype(int)
    changes = np.diff(padded)
    starts = np.flatnonzero(changes == 1)
    stops = np.flatnonzero(changes == -1)
    return tuple((int(start), int(stop)) for start, stop in zip(starts, stops))
