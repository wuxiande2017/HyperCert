from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

import numpy as np
from scipy.optimize import minimize

from .decision_variables import UAVDecisionVariables
from .dual_variables import ResourceTimeDualVariables
from .problem_definition import HyperCertProblemDefinition
from .soft_occupancy import SoftOccupancyModel


@dataclass(frozen=True)
class LocalSubproblemResult:
    uav_id: str
    decision: UAVDecisionVariables
    local_objective: float
    resource_price_cost: float
    success: bool
    message: str
    iterations: int
    maximum_local_violation: float


class LocalSubproblemSolver:
    """Solve one fixed-route, fixed-altitude continuous UAV subproblem."""

    def __init__(self, problem: HyperCertProblemDefinition) -> None:
        self.problem = problem
        self.occupancy = SoftOccupancyModel(problem)

    def solve(
        self,
        uav_index: int,
        current: UAVDecisionVariables,
        all_decisions: Mapping[str, UAVDecisionVariables],
        duals: ResourceTimeDualVariables,
        fairness_reference: float,
    ) -> LocalSubproblemResult:
        uav = self.problem.uavs[uav_index]
        if current.route_index < 0 or current.altitude_layer_index < 0:
            raise ValueError("local subproblems require fixed discrete route and altitude assignments")
        current_vector = current.continuous_vector()
        weights = self.problem.config.weights.as_dict()
        settings = self.problem.config.solver

        def unpack(vector: np.ndarray) -> UAVDecisionVariables:
            return current.with_continuous_vector(vector)

        def objective(vector: np.ndarray) -> float:
            decision = unpack(vector)
            components = self.problem.local_objective_components(uav_index, decision, fairness_reference)
            base = sum(weights[name] * components[name] for name in weights)
            price_cost, _ = self.occupancy.integrated_price_cost_and_gradient(
                uav_index, decision, duals.as_mapping()
            )
            proximal = 0.5 * settings.proximal_weight * float(np.sum((vector - current_vector) ** 2))
            return float(base + price_cost + proximal)

        def feasible_slacks(vector: np.ndarray) -> np.ndarray:
            trial = unpack(vector)
            residual = self._local_constraint_residuals(uav_index, trial, all_decisions)
            if residual.size == 0:
                return np.asarray([1.0])
            return -residual

        result = minimize(
            objective,
            x0=current_vector,
            method="SLSQP",
            bounds=self.problem.decision_bounds(uav_index, current),
            constraints=({"type": "ineq", "fun": feasible_slacks},),
            options={
                "maxiter": settings.local_max_iterations,
                "ftol": 1e-10,
                "disp": False,
            },
        )
        candidate = unpack(result.x)
        local_residual = self._local_constraint_residuals(uav_index, candidate, all_decisions)
        maximum_violation = max(0.0, float(np.max(local_residual, initial=0.0)))
        price_cost, _ = self.occupancy.integrated_price_cost_and_gradient(
            uav_index, candidate, duals.as_mapping()
        )
        success = bool(result.success and maximum_violation <= 10.0 * self.problem.config.constraint_tolerance)
        if not success:
            candidate = current
            price_cost, _ = self.occupancy.integrated_price_cost_and_gradient(
                uav_index, current, duals.as_mapping()
            )
        components = self.problem.local_objective_components(uav_index, candidate, fairness_reference)
        local_objective = float(sum(weights[name] * components[name] for name in weights))
        return LocalSubproblemResult(
            uav_id=uav.uav_id,
            decision=candidate,
            local_objective=local_objective,
            resource_price_cost=float(price_cost),
            success=success,
            message=str(result.message),
            iterations=int(result.nit),
            maximum_local_violation=maximum_violation,
        )

    def _local_constraint_residuals(
        self,
        uav_index: int,
        decision: UAVDecisionVariables,
        all_decisions: Mapping[str, UAVDecisionVariables],
    ) -> np.ndarray:
        uav = self.problem.uavs[uav_index]
        local_problem = HyperCertProblemDefinition(
            uavs=(uav,),
            resources=self.problem.resources,
            time_grid_s=self.problem.time_grid_s,
            config=self.problem.config,
        )
        evaluation = local_problem.evaluate_constraints({uav.uav_id: decision})
        residuals = [
            values
            for name, values in evaluation.residuals.items()
            if name not in {"continuous_resource_capacity", "pairwise_geometric_separation"}
        ]
        positions = decision.trajectory_coefficients
        for other in self.problem.uavs:
            if other.uav_id == uav.uav_id:
                continue
            other_positions = all_decisions[other.uav_id].trajectory_coefficients
            count = min(len(positions), len(other_positions))
            distance = np.linalg.norm(positions[:count] - other_positions[:count], axis=1)
            required = max(uav.minimum_separation_m, other.minimum_separation_m)
            residuals.append(required - distance)
        return np.concatenate([np.asarray(values).reshape(-1) for values in residuals if values.size]) if residuals else np.empty(0)

