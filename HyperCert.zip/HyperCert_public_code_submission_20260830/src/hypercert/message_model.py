from __future__ import annotations

from dataclasses import dataclass
import json
from typing import Any

import numpy as np

from .conflict_hypergraph import CapacityConflictHypergraph


@dataclass(frozen=True)
class OptimizationMessage:
    message_id: str
    hyperedge_id: str
    sender_id: str
    receiver_id: str
    message_type: str
    source_iteration: int
    created_iteration: int
    deliver_iteration: int
    payload: dict[str, Any]
    size_bytes: int

    @classmethod
    def create(
        cls,
        message_id: str,
        hyperedge_id: str,
        sender_id: str,
        receiver_id: str,
        message_type: str,
        source_iteration: int,
        created_iteration: int,
        deliver_iteration: int,
        payload: dict[str, Any],
    ) -> "OptimizationMessage":
        normalized = _json_safe(payload)
        size = len(json.dumps(normalized, sort_keys=True, separators=(",", ":")).encode("utf-8"))
        return cls(
            message_id=message_id,
            hyperedge_id=hyperedge_id,
            sender_id=sender_id,
            receiver_id=receiver_id,
            message_type=message_type,
            source_iteration=source_iteration,
            created_iteration=created_iteration,
            deliver_iteration=deliver_iteration,
            payload=normalized,
            size_bytes=size,
        )


class MessageLedger:
    def __init__(self, maximum_delay_iterations: int) -> None:
        if maximum_delay_iterations < 0:
            raise ValueError("maximum communication delay cannot be negative")
        self.maximum_delay_iterations = maximum_delay_iterations
        self._pending: list[OptimizationMessage] = []
        self.sent_messages = 0
        self.sent_bytes = 0
        self.delivered_messages = 0
        self.delivered_bytes = 0

    def enqueue(self, message: OptimizationMessage) -> None:
        delay = message.deliver_iteration - message.created_iteration
        if delay < 0 or delay > self.maximum_delay_iterations:
            raise ValueError("message delivery delay violates the configured bound")
        self._pending.append(message)
        self.sent_messages += 1
        self.sent_bytes += message.size_bytes

    def deliver_ready(self, iteration: int) -> tuple[OptimizationMessage, ...]:
        ready = sorted(
            (message for message in self._pending if message.deliver_iteration <= iteration),
            key=lambda message: (message.deliver_iteration, message.message_id),
        )
        ready_ids = {message.message_id for message in ready}
        self._pending = [message for message in self._pending if message.message_id not in ready_ids]
        self.delivered_messages += len(ready)
        self.delivered_bytes += sum(message.size_bytes for message in ready)
        return tuple(ready)

    @property
    def pending_messages(self) -> int:
        return len(self._pending)


def build_hyperedge_messages(
    hypergraph: CapacityConflictHypergraph,
    iteration: int,
    maximum_delay_iterations: int,
    resource_prices: dict[str, np.ndarray],
) -> tuple[OptimizationMessage, ...]:
    messages = []
    sequence = 0
    for edge in hypergraph.hyperedges:
        for uav_id in edge.participating_uav_ids:
            delay = deterministic_delay(edge.hyperedge_id, uav_id, iteration, maximum_delay_iterations)
            messages.append(
                OptimizationMessage.create(
                    message_id=f"m{iteration}:{sequence}",
                    hyperedge_id=edge.hyperedge_id,
                    sender_id=f"uav:{uav_id}",
                    receiver_id=f"resource:{edge.resource_id}",
                    message_type="primal_occupancy",
                    source_iteration=iteration,
                    created_iteration=iteration,
                    deliver_iteration=iteration + delay,
                    payload={
                        "uav_id": uav_id,
                        "resource_id": edge.resource_id,
                        "maximum_soft_occupancy": float(np.max(edge.soft_occupancy[uav_id], initial=0.0)),
                    },
                )
            )
            sequence += 1
            messages.append(
                OptimizationMessage.create(
                    message_id=f"m{iteration}:{sequence}",
                    hyperedge_id=edge.hyperedge_id,
                    sender_id=f"resource:{edge.resource_id}",
                    receiver_id=f"uav:{uav_id}",
                    message_type="dual_price",
                    source_iteration=iteration,
                    created_iteration=iteration,
                    deliver_iteration=iteration + delay,
                    payload={
                        "uav_id": uav_id,
                        "resource_id": edge.resource_id,
                        "price": resource_prices[edge.resource_id],
                    },
                )
            )
            sequence += 1
    return tuple(messages)


def build_global_coordination_messages(
    uav_ids: tuple[str, ...],
    resource_ids: tuple[str, ...],
    iteration: int,
    maximum_delay_iterations: int,
    resource_prices: dict[str, np.ndarray],
    uav_occupancies: dict[str, dict[str, np.ndarray]],
) -> tuple[OptimizationMessage, ...]:
    """Build dense all-to-all UAV/resource coordination messages.

    Unlike hyperedge messaging, this path communicates every UAV/resource
    pair, including pairs whose current soft occupancy is zero.  It is used by
    the Phase 8 global primal-dual ablation and intentionally exposes the
    communication cost removed by sparse hypergraph coordination.
    """

    messages = []
    sequence = 0
    for resource_id in sorted(resource_ids):
        for uav_id in sorted(uav_ids):
            coordination_id = f"global:{resource_id}"
            delay = deterministic_delay(
                coordination_id,
                uav_id,
                iteration,
                maximum_delay_iterations,
            )
            occupancy = uav_occupancies[uav_id][resource_id]
            messages.append(
                OptimizationMessage.create(
                    message_id=f"g{iteration}:{sequence}",
                    hyperedge_id=coordination_id,
                    sender_id=f"uav:{uav_id}",
                    receiver_id=f"resource:{resource_id}",
                    message_type="global_primal_occupancy",
                    source_iteration=iteration,
                    created_iteration=iteration,
                    deliver_iteration=iteration + delay,
                    payload={
                        "uav_id": uav_id,
                        "resource_id": resource_id,
                        "maximum_soft_occupancy": float(np.max(occupancy, initial=0.0)),
                    },
                )
            )
            sequence += 1
            messages.append(
                OptimizationMessage.create(
                    message_id=f"g{iteration}:{sequence}",
                    hyperedge_id=coordination_id,
                    sender_id=f"resource:{resource_id}",
                    receiver_id=f"uav:{uav_id}",
                    message_type="global_dual_price",
                    source_iteration=iteration,
                    created_iteration=iteration,
                    deliver_iteration=iteration + delay,
                    payload={
                        "uav_id": uav_id,
                        "resource_id": resource_id,
                        "price": resource_prices[resource_id],
                    },
                )
            )
            sequence += 1
    return tuple(messages)


def deterministic_delay(
    hyperedge_id: str,
    receiver_id: str,
    iteration: int,
    maximum_delay_iterations: int,
) -> int:
    if maximum_delay_iterations <= 0:
        return 0
    checksum = sum(ord(char) for char in f"{hyperedge_id}:{receiver_id}:{iteration}")
    return checksum % (maximum_delay_iterations + 1)


def _json_safe(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.floating):
        return float(value)
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    return value
