from __future__ import annotations

from dataclasses import dataclass
from math import comb, floor, ceil
from typing import Iterable

import numpy as np

from certificate.continuous_occupancy_extractor import ContinuousResource
from certificate.occupancy_interval import OccupancyInterval
from models.uncertainty_model import UncertaintyModel

from .closed_loop_validation import MinimumSnapTrajectory


@dataclass(frozen=True)
class PolynomialEnclosureConfig:
    spatial_tolerance_m: float = 1e-3
    temporal_tolerance_s: float = 1e-4
    bisection_tolerance_s: float = 1e-6
    maximum_subdivision_depth: int = 24
    numerical_margin_m: float = 1e-9

    def __post_init__(self) -> None:
        if min(
            self.spatial_tolerance_m,
            self.temporal_tolerance_s,
            self.bisection_tolerance_s,
        ) <= 0.0:
            raise ValueError("polynomial enclosure tolerances must be positive")
        if self.maximum_subdivision_depth <= 0:
            raise ValueError("maximum_subdivision_depth must be positive")
        if self.numerical_margin_m < 0.0:
            raise ValueError("numerical_margin_m must be nonnegative")


@dataclass(frozen=True)
class PolynomialEnclosureStats:
    leaf_count: int
    maximum_curve_chord_bound_m: float
    maximum_leaf_duration_s: float


class ConservativePolynomialOccupancyExtractor:
    """Conservative resource occupancy for piecewise polynomial trajectories.

    Each polynomial subinterval is converted to Bernstein form. The Bernstein
    convex-hull property bounds the curve-to-chord displacement. Intersecting
    that chord with a resource inflated by the bound therefore contains every
    time at which the polynomial curve can occupy the original resource.
    """

    def __init__(
        self,
        uncertainty_model: UncertaintyModel | None = None,
        config: PolynomialEnclosureConfig | None = None,
    ) -> None:
        self.uncertainty_model = uncertainty_model or UncertaintyModel()
        self.config = config or PolynomialEnclosureConfig()
        self.last_stats = PolynomialEnclosureStats(0, 0.0, 0.0)

    def extract(
        self,
        trajectory: MinimumSnapTrajectory,
        resources: Iterable[ContinuousResource],
        uav_id: str,
        trajectory_id: str,
    ) -> tuple[OccupancyInterval, ...]:
        resources = tuple(resources)
        unsupported = [
            resource.resource_id
            for resource in resources
            if resource.segment_intervals_with_margin is None
        ]
        if unsupported:
            raise ValueError(
                "polynomial certificate projection requires margin-aware "
                f"resource intersection for resources: {sorted(unsupported)}"
            )

        leaves = self._enclose(trajectory)
        self.last_stats = PolynomialEnclosureStats(
            leaf_count=len(leaves),
            maximum_curve_chord_bound_m=max(
                (leaf.curve_chord_bound_m for leaf in leaves),
                default=0.0,
            ),
            maximum_leaf_duration_s=max(
                (leaf.t1_s - leaf.t0_s for leaf in leaves),
                default=0.0,
            ),
        )
        intervals: list[OccupancyInterval] = []
        for resource in resources:
            visits: list[tuple[float, float, float]] = []
            for leaf in leaves:
                speed = _leaf_speed_bound(leaf)
                uncertainty = self.uncertainty_model.bounds_for_resource(
                    resource.resource_id,
                    speed,
                )
                margin = (
                    leaf.curve_chord_bound_m
                    + uncertainty.spatial_margin_m
                    + self.config.numerical_margin_m
                )
                for enter, exit_s in resource.segment_intervals_with_margin(
                    leaf.p0_m,
                    leaf.p1_m,
                    leaf.t0_s,
                    leaf.t1_s,
                    margin,
                ):
                    visits.append((enter, exit_s, margin))

            for enter, exit_s, spatial_margin in _merge_visits(
                visits,
                self.config.temporal_tolerance_s,
            ):
                nominal_enter = _round_earlier(
                    enter,
                    self.config.bisection_tolerance_s,
                )
                nominal_exit = _round_later(
                    exit_s,
                    self.config.bisection_tolerance_s,
                )
                midpoint_speed = float(
                    np.linalg.norm(
                        trajectory.evaluate(nominal_exit, 0)
                        - trajectory.evaluate(nominal_enter, 0)
                    )
                    / max(nominal_exit - nominal_enter, 1e-9)
                )
                uncertainty = self.uncertainty_model.bounds_for_resource(
                    resource.resource_id,
                    midpoint_speed,
                )
                intervals.append(
                    OccupancyInterval(
                        uav_id=uav_id,
                        trajectory_id=trajectory_id,
                        resource_id=resource.resource_id,
                        t_enter_nominal=nominal_enter,
                        t_exit_nominal=nominal_exit,
                        t_enter_robust=nominal_enter - uncertainty.epsilon_early_s,
                        t_exit_robust=nominal_exit + uncertainty.epsilon_late_s,
                        entry_position=trajectory.evaluate(nominal_enter, 0),
                        exit_position=trajectory.evaluate(nominal_exit, 0),
                        spatial_margin_m=max(
                            spatial_margin,
                            uncertainty.spatial_margin_m,
                        ),
                        temporal_margin_s=max(
                            uncertainty.epsilon_early_s,
                            uncertainty.epsilon_late_s,
                        ),
                    )
                )
        return tuple(
            sorted(
                intervals,
                key=lambda item: (item.resource_id, item.t_enter_nominal),
            )
        )

    def _enclose(
        self,
        trajectory: MinimumSnapTrajectory,
    ) -> tuple["_EnclosureLeaf", ...]:
        leaves: list[_EnclosureLeaf] = []

        def recurse(
            coefficients: np.ndarray,
            segment_start_s: float,
            local_a_s: float,
            local_b_s: float,
            depth: int,
        ) -> None:
            power = _power_coefficients_on_unit_interval(
                coefficients,
                local_a_s,
                local_b_s,
            )
            bernstein = _power_to_bernstein(power)
            p0 = bernstein[0]
            p1 = bernstein[-1]
            degree = len(bernstein) - 1
            chord_controls = np.asarray(
                [
                    p0 + (p1 - p0) * (index / degree)
                    for index in range(degree + 1)
                ]
            )
            deviation = float(
                np.max(
                    np.linalg.norm(bernstein - chord_controls, axis=1),
                    initial=0.0,
                )
            )
            duration = local_b_s - local_a_s
            if (
                deviation <= self.config.spatial_tolerance_m
                or duration <= self.config.temporal_tolerance_s
                or depth >= self.config.maximum_subdivision_depth
            ):
                leaves.append(
                    _EnclosureLeaf(
                        t0_s=segment_start_s + local_a_s,
                        t1_s=segment_start_s + local_b_s,
                        p0_m=p0,
                        p1_m=p1,
                        curve_chord_bound_m=deviation,
                    )
                )
                return
            midpoint = 0.5 * (local_a_s + local_b_s)
            recurse(
                coefficients,
                segment_start_s,
                local_a_s,
                midpoint,
                depth + 1,
            )
            recurse(
                coefficients,
                segment_start_s,
                midpoint,
                local_b_s,
                depth + 1,
            )

        for start, duration, coefficients in zip(
            trajectory.segment_start_times_s,
            trajectory.segment_durations_s,
            trajectory.coefficients,
        ):
            recurse(coefficients, float(start), 0.0, float(duration), 0)
        return tuple(leaves)


@dataclass(frozen=True)
class _EnclosureLeaf:
    t0_s: float
    t1_s: float
    p0_m: np.ndarray
    p1_m: np.ndarray
    curve_chord_bound_m: float


def _power_coefficients_on_unit_interval(
    coefficients: np.ndarray,
    local_a_s: float,
    local_b_s: float,
) -> np.ndarray:
    coefficients = np.asarray(coefficients, dtype=float)
    degree = coefficients.shape[1] - 1
    duration = local_b_s - local_a_s
    transformed = np.zeros((degree + 1, coefficients.shape[0]), dtype=float)
    for target_power in range(degree + 1):
        for source_power in range(target_power, degree + 1):
            transformed[target_power] += (
                coefficients[:, source_power]
                * comb(source_power, target_power)
                * local_a_s ** (source_power - target_power)
                * duration**target_power
            )
    return transformed


def _power_to_bernstein(power: np.ndarray) -> np.ndarray:
    power = np.asarray(power, dtype=float)
    degree = len(power) - 1
    bernstein = np.zeros_like(power)
    for index in range(degree + 1):
        for source_power in range(index + 1):
            bernstein[index] += (
                comb(index, source_power)
                / comb(degree, source_power)
                * power[source_power]
            )
    return bernstein


def _leaf_speed_bound(leaf: _EnclosureLeaf) -> float:
    return float(
        np.linalg.norm(leaf.p1_m - leaf.p0_m)
        / max(leaf.t1_s - leaf.t0_s, 1e-9)
    )


def _merge_visits(
    visits: list[tuple[float, float, float]],
    tolerance_s: float,
) -> list[tuple[float, float, float]]:
    if not visits:
        return []
    ordered = sorted(visits)
    merged = [ordered[0]]
    for enter, exit_s, margin in ordered[1:]:
        previous_enter, previous_exit, previous_margin = merged[-1]
        if enter <= previous_exit + tolerance_s:
            merged[-1] = (
                previous_enter,
                max(previous_exit, exit_s),
                max(previous_margin, margin),
            )
        else:
            merged.append((enter, exit_s, margin))
    return merged


def _round_earlier(value: float, quantum_s: float) -> float:
    return floor(float(value) / quantum_s) * quantum_s


def _round_later(value: float, quantum_s: float) -> float:
    return ceil(float(value) / quantum_s) * quantum_s
