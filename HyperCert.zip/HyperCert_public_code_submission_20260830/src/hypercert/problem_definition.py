from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping

import numpy as np

from .config import HyperCertConfig
from .decision_variables import UAVDecisionVariables


@dataclass(frozen=True)
class ResourceDefinition:
    resource_id: str
    capacity: int

    def __post_init__(self) -> None:
        if not self.resource_id:
            raise ValueError("resource_id cannot be empty")
        if self.capacity <= 0:
            raise ValueError("resource capacity must be positive")


@dataclass(frozen=True)
class SphericalObstacle:
    center_m: np.ndarray
    radius_m: float

    def __post_init__(self) -> None:
        center = np.asarray(self.center_m, dtype=float).reshape(3).copy()
        if self.radius_m < 0.0:
            raise ValueError("obstacle radius cannot be negative")
        object.__setattr__(self, "center_m", center)


@dataclass(frozen=True)
class RouteCandidateDefinition:
    route_id: str
    edge_ids: tuple[str, ...]
    resource_ids: tuple[str, ...]
    edge_lengths_m: np.ndarray
    nominal_edge_times_s: np.ndarray
    min_edge_times_s: np.ndarray
    max_edge_times_s: np.ndarray
    holding_allowed_after_edge: tuple[bool, ...]
    permitted_altitude_layers: tuple[int, ...]
    allowed_altitude_transitions: tuple[tuple[int, int], ...] = tuple()
    corridor_lower_m: np.ndarray = field(default_factory=lambda: np.asarray([-np.inf, -np.inf, -np.inf]))
    corridor_upper_m: np.ndarray = field(default_factory=lambda: np.asarray([np.inf, np.inf, np.inf]))

    def __post_init__(self) -> None:
        edge_count = len(self.edge_ids)
        if not self.route_id or edge_count == 0:
            raise ValueError("a route requires an id and at least one edge")
        if len(self.resource_ids) != edge_count:
            raise ValueError("resource_ids must map one resource to each edge")
        expected_holds = max(0, edge_count - 1)
        if len(self.holding_allowed_after_edge) != expected_holds:
            raise ValueError("holding_allowed_after_edge must have edge_count - 1 entries")
        if not self.permitted_altitude_layers:
            raise ValueError("at least one altitude layer must be permitted")
        arrays = {
            "edge_lengths_m": self.edge_lengths_m,
            "nominal_edge_times_s": self.nominal_edge_times_s,
            "min_edge_times_s": self.min_edge_times_s,
            "max_edge_times_s": self.max_edge_times_s,
        }
        converted = {name: np.asarray(value, dtype=float).reshape(-1).copy() for name, value in arrays.items()}
        if any(len(value) != edge_count for value in converted.values()):
            raise ValueError("route edge arrays must match edge_count")
        if np.any(converted["edge_lengths_m"] <= 0.0):
            raise ValueError("edge lengths must be positive")
        if np.any(converted["min_edge_times_s"] <= 0.0):
            raise ValueError("minimum edge times must be positive")
        if np.any(converted["max_edge_times_s"] < converted["min_edge_times_s"]):
            raise ValueError("maximum edge times must not be below minimum edge times")
        if np.any(converted["nominal_edge_times_s"] < converted["min_edge_times_s"]) or np.any(
            converted["nominal_edge_times_s"] > converted["max_edge_times_s"]
        ):
            raise ValueError("nominal edge times must lie within their bounds")
        lower = np.asarray(self.corridor_lower_m, dtype=float).reshape(3).copy()
        upper = np.asarray(self.corridor_upper_m, dtype=float).reshape(3).copy()
        if np.any(lower > upper):
            raise ValueError("corridor lower bounds must not exceed upper bounds")
        for name, value in converted.items():
            object.__setattr__(self, name, value)
        object.__setattr__(self, "corridor_lower_m", lower)
        object.__setattr__(self, "corridor_upper_m", upper)

    @property
    def edge_count(self) -> int:
        return len(self.edge_ids)

    @property
    def holding_count(self) -> int:
        return max(0, self.edge_count - 1)

    @property
    def route_length_m(self) -> float:
        return float(np.sum(self.edge_lengths_m))


@dataclass(frozen=True)
class FrozenCommittedPrefix:
    departure_delay_s: float | None = None
    edge_travel_times_s: np.ndarray = field(default_factory=lambda: np.empty(0, dtype=float))
    holding_times_s: np.ndarray = field(default_factory=lambda: np.empty(0, dtype=float))
    trajectory_coefficients: np.ndarray = field(default_factory=lambda: np.empty((0, 3), dtype=float))
    tolerance: float = 1e-8

    def __post_init__(self) -> None:
        if self.tolerance < 0.0:
            raise ValueError("frozen-prefix tolerance cannot be negative")
        object.__setattr__(self, "edge_travel_times_s", np.asarray(self.edge_travel_times_s, dtype=float).reshape(-1).copy())
        object.__setattr__(self, "holding_times_s", np.asarray(self.holding_times_s, dtype=float).reshape(-1).copy())
        coefficients = np.asarray(self.trajectory_coefficients, dtype=float)
        if coefficients.size == 0:
            coefficients = np.empty((0, 3), dtype=float)
        object.__setattr__(self, "trajectory_coefficients", coefficients.copy())


@dataclass(frozen=True)
class UAVPlanningDefinition:
    uav_id: str
    release_time_s: float
    route_candidates: tuple[RouteCandidateDefinition, ...]
    initial_route_index: int
    initial_altitude_layer_index: int
    priority_weight: float = 1.0
    starvation_age_s: float = 0.0
    max_speed_mps: float = 15.0
    max_acceleration_mps2: float = 8.0
    max_jerk_mps3: float = 20.0
    minimum_separation_m: float = 5.0
    vehicle_radius_m: float = 0.5
    obstacles: tuple[SphericalObstacle, ...] = tuple()
    frozen_prefix: FrozenCommittedPrefix = field(default_factory=FrozenCommittedPrefix)
    repair_reference: UAVDecisionVariables | None = None

    def __post_init__(self) -> None:
        if not self.uav_id:
            raise ValueError("uav_id cannot be empty")
        if not self.route_candidates:
            raise ValueError("each UAV requires at least one route candidate")
        if not 0 <= self.initial_route_index < len(self.route_candidates):
            raise ValueError("initial_route_index is out of range")
        if self.priority_weight <= 0.0:
            raise ValueError("priority_weight must be positive")
        if min(self.max_speed_mps, self.max_acceleration_mps2, self.max_jerk_mps3) <= 0.0:
            raise ValueError("dynamic limits must be positive")
        if self.minimum_separation_m < 0.0 or self.vehicle_radius_m < 0.0:
            raise ValueError("distance limits cannot be negative")

    def route(self, route_index: int) -> RouteCandidateDefinition:
        if not 0 <= route_index < len(self.route_candidates):
            raise ValueError(f"route index {route_index} is invalid for UAV {self.uav_id}")
        return self.route_candidates[route_index]


@dataclass(frozen=True)
class ConstraintEvaluation:
    residuals: dict[str, np.ndarray]
    tolerance: float

    @property
    def maximum_violation(self) -> float:
        values = [float(np.max(value, initial=-np.inf)) for value in self.residuals.values() if value.size]
        return max(0.0, max(values, default=0.0))

    @property
    def is_satisfied(self) -> bool:
        return self.maximum_violation <= self.tolerance

    def maxima(self) -> dict[str, float]:
        return {
            name: max(0.0, float(np.max(values, initial=0.0)))
            for name, values in self.residuals.items()
        }


@dataclass(frozen=True)
class HyperCertProblemDefinition:
    uavs: tuple[UAVPlanningDefinition, ...]
    resources: tuple[ResourceDefinition, ...]
    time_grid_s: np.ndarray
    config: HyperCertConfig = field(default_factory=HyperCertConfig)

    def __post_init__(self) -> None:
        if not self.uavs or not self.resources:
            raise ValueError("HyperCert requires at least one UAV and one resource")
        uav_ids = [uav.uav_id for uav in self.uavs]
        resource_ids = [resource.resource_id for resource in self.resources]
        if len(set(uav_ids)) != len(uav_ids):
            raise ValueError("UAV ids must be unique")
        if len(set(resource_ids)) != len(resource_ids):
            raise ValueError("resource ids must be unique")
        grid = np.asarray(self.time_grid_s, dtype=float).reshape(-1).copy()
        if len(grid) < 2 or np.any(np.diff(grid) <= 0.0):
            raise ValueError("time_grid_s must be strictly increasing")
        known_resources = set(resource_ids)
        unknown = {
            resource_id
            for uav in self.uavs
            for route in uav.route_candidates
            for resource_id in route.resource_ids
            if resource_id not in known_resources
        }
        if unknown:
            raise ValueError(f"routes reference unknown resources: {sorted(unknown)}")
        object.__setattr__(self, "time_grid_s", grid)

    @property
    def resource_ids(self) -> tuple[str, ...]:
        return tuple(resource.resource_id for resource in self.resources)

    def resource_capacity(self, resource_id: str) -> int:
        for resource in self.resources:
            if resource.resource_id == resource_id:
                return resource.capacity
        raise KeyError(resource_id)

    def validate_decisions(self, decisions: Mapping[str, UAVDecisionVariables]) -> None:
        expected = {uav.uav_id for uav in self.uavs}
        if set(decisions) != expected:
            raise ValueError(f"decision ids must equal {sorted(expected)}")
        for uav in self.uavs:
            decision = decisions[uav.uav_id]
            route = uav.route(decision.route_index)
            if len(decision.edge_travel_times_s) != route.edge_count:
                raise ValueError(f"edge-time count does not match route for {uav.uav_id}")
            if len(decision.holding_times_s) != route.holding_count:
                raise ValueError(f"holding-time count does not match route for {uav.uav_id}")
            if decision.trajectory_coefficients.ndim != 2 or decision.trajectory_coefficients.shape[1] != 3:
                raise ValueError("trajectory_coefficients must be an N x 3 position-control array in Phase 2")

    def decision_bounds(self, uav_index: int, decision: UAVDecisionVariables) -> tuple[tuple[float, float], ...]:
        uav = self.uavs[uav_index]
        route = uav.route(decision.route_index)
        bounds: list[tuple[float, float]] = [(0.0, self.config.max_departure_delay_s)]
        bounds.extend(zip(route.min_edge_times_s.tolist(), route.max_edge_times_s.tolist()))
        bounds.extend(
            (0.0, self.config.max_holding_time_s if allowed else 0.0)
            for allowed in route.holding_allowed_after_edge
        )
        coefficient_bound = self.config.coefficient_bound_m
        bounds.extend([(-coefficient_bound, coefficient_bound)] * decision.trajectory_coefficients.size)
        return tuple(bounds)

    def objective_components(self, decisions: Mapping[str, UAVDecisionVariables]) -> dict[str, float]:
        self.validate_decisions(decisions)
        weighted_delays = np.asarray(
            [uav.priority_weight * decisions[uav.uav_id].departure_delay_s for uav in self.uavs],
            dtype=float,
        )
        fairness_reference = float(np.mean(weighted_delays))
        totals = {name: 0.0 for name in self.config.weights.as_dict()}
        for index, uav in enumerate(self.uavs):
            local = self.local_objective_components(index, decisions[uav.uav_id], fairness_reference)
            for name, value in local.items():
                totals[name] += value
        return totals

    def local_objective_components(
        self,
        uav_index: int,
        decision: UAVDecisionVariables,
        fairness_reference: float,
    ) -> dict[str, float]:
        uav = self.uavs[uav_index]
        route = uav.route(decision.route_index)
        coefficients = decision.trajectory_coefficients
        first_difference = np.diff(coefficients, axis=0)
        second_difference = np.diff(coefficients, n=2, axis=0)
        weighted_delay = uav.priority_weight * decision.departure_delay_s
        repair_deviation = 0.0
        if uav.repair_reference is not None:
            try:
                repair_deviation = decision.continuous_distance_squared(uav.repair_reference)
            except ValueError:
                reference = uav.repair_reference
                coefficient_count = min(len(coefficients), len(reference.trajectory_coefficients))
                coefficient_delta = coefficients[:coefficient_count] - reference.trajectory_coefficients[:coefficient_count]
                repair_deviation = (
                    (decision.departure_delay_s - reference.departure_delay_s) ** 2
                    + (float(np.sum(decision.edge_travel_times_s)) - float(np.sum(reference.edge_travel_times_s))) ** 2
                    + (float(np.sum(decision.holding_times_s)) - float(np.sum(reference.holding_times_s))) ** 2
                    + float(np.sum(coefficient_delta**2))
                )
        return {
            "departure_delay": weighted_delay,
            "travel_time": float(np.sum(decision.edge_travel_times_s)),
            "route_length": route.route_length_m,
            "control_effort": float(np.sum(first_difference**2)),
            "trajectory_smoothness": float(np.sum(second_difference**2)),
            "holding_time": float(np.sum(decision.holding_times_s)),
            "route_switching": float(decision.route_index != uav.initial_route_index),
            "fairness": float((weighted_delay - fairness_reference) ** 2),
            "starvation": float(uav.starvation_age_s * weighted_delay),
            "execution_repair_deviation": repair_deviation,
        }

    def global_objective(self, decisions: Mapping[str, UAVDecisionVariables]) -> float:
        components = self.objective_components(decisions)
        weights = self.config.weights.as_dict()
        return float(sum(weights[name] * components[name] for name in weights))

    def evaluate_constraints(self, decisions: Mapping[str, UAVDecisionVariables]) -> ConstraintEvaluation:
        self.validate_decisions(decisions)
        buckets: dict[str, list[np.ndarray]] = {
            "corridor_containment": [],
            "speed": [],
            "acceleration": [],
            "jerk": [],
            "obstacle_clearance": [],
            "pairwise_geometric_separation": [],
            "continuous_resource_capacity": [],
            "frozen_committed_prefix": [],
            "permitted_holding_locations": [],
            "permitted_altitude_transitions": [],
        }
        dt = self.config.trajectory_sample_dt_s
        for uav in self.uavs:
            decision = decisions[uav.uav_id]
            route = uav.route(decision.route_index)
            positions = decision.trajectory_coefficients
            buckets["corridor_containment"].extend(
                [route.corridor_lower_m[None, :] - positions, positions - route.corridor_upper_m[None, :]]
            )
            velocity = np.diff(positions, axis=0) / dt
            acceleration = np.diff(positions, n=2, axis=0) / (dt**2)
            jerk = np.diff(positions, n=3, axis=0) / (dt**3)
            buckets["speed"].append(_norm_residual(velocity, uav.max_speed_mps))
            buckets["acceleration"].append(_norm_residual(acceleration, uav.max_acceleration_mps2))
            buckets["jerk"].append(_norm_residual(jerk, uav.max_jerk_mps3))
            for obstacle in uav.obstacles:
                distance = np.linalg.norm(positions - obstacle.center_m[None, :], axis=1)
                buckets["obstacle_clearance"].append(obstacle.radius_m + uav.vehicle_radius_m - distance)
            buckets["frozen_committed_prefix"].append(_frozen_prefix_residual(uav.frozen_prefix, decision))
            holding_residual = np.asarray(
                [hold if not allowed else -hold for hold, allowed in zip(decision.holding_times_s, route.holding_allowed_after_edge)],
                dtype=float,
            )
            buckets["permitted_holding_locations"].append(holding_residual)
            altitude_ok = decision.altitude_layer_index in route.permitted_altitude_layers
            transition_ok = (
                decision.altitude_layer_index == uav.initial_altitude_layer_index
                or (uav.initial_altitude_layer_index, decision.altitude_layer_index) in route.allowed_altitude_transitions
            )
            buckets["permitted_altitude_transitions"].append(
                np.asarray([-1.0 if altitude_ok and transition_ok else 1.0])
            )

        for left_index, left_uav in enumerate(self.uavs):
            left_positions = decisions[left_uav.uav_id].trajectory_coefficients
            for right_uav in self.uavs[left_index + 1 :]:
                right_positions = decisions[right_uav.uav_id].trajectory_coefficients
                count = min(len(left_positions), len(right_positions))
                distance = np.linalg.norm(left_positions[:count] - right_positions[:count], axis=1)
                required = max(left_uav.minimum_separation_m, right_uav.minimum_separation_m)
                buckets["pairwise_geometric_separation"].append(required - distance)

        from .soft_occupancy import SoftOccupancyModel

        occupancy = SoftOccupancyModel(self).aggregate_by_resource(decisions)
        for resource in self.resources:
            buckets["continuous_resource_capacity"].append(
                occupancy[resource.resource_id] - float(resource.capacity)
            )

        residuals = {
            name: np.concatenate([np.asarray(value, dtype=float).reshape(-1) for value in values]) if values else np.empty(0)
            for name, values in buckets.items()
        }
        return ConstraintEvaluation(residuals=residuals, tolerance=self.config.constraint_tolerance)


def _norm_residual(values: np.ndarray, limit: float) -> np.ndarray:
    if values.size == 0:
        return np.empty(0, dtype=float)
    return np.linalg.norm(values, axis=1) - limit


def _frozen_prefix_residual(prefix: FrozenCommittedPrefix, decision: UAVDecisionVariables) -> np.ndarray:
    residuals: list[np.ndarray] = []
    if prefix.departure_delay_s is not None:
        residuals.append(np.asarray([abs(decision.departure_delay_s - prefix.departure_delay_s) - prefix.tolerance]))
    if len(prefix.edge_travel_times_s):
        count = len(prefix.edge_travel_times_s)
        residuals.append(np.abs(decision.edge_travel_times_s[:count] - prefix.edge_travel_times_s) - prefix.tolerance)
    if len(prefix.holding_times_s):
        count = len(prefix.holding_times_s)
        residuals.append(np.abs(decision.holding_times_s[:count] - prefix.holding_times_s) - prefix.tolerance)
    if len(prefix.trajectory_coefficients):
        count = len(prefix.trajectory_coefficients)
        residuals.append(
            np.abs(decision.trajectory_coefficients[:count] - prefix.trajectory_coefficients).reshape(-1) - prefix.tolerance
        )
    return np.concatenate(residuals) if residuals else np.empty(0, dtype=float)
