from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping

import numpy as np

from .decision_variables import UAVDecisionVariables
from .dual_variables import ResourceTimeDualVariables
from .problem_definition import HyperCertProblemDefinition, RouteCandidateDefinition
from .soft_occupancy import SoftOccupancyModel


@dataclass(frozen=True, order=True)
class DiscreteRouteAssignment:
    route_index: int
    altitude_layer_index: int


@dataclass(frozen=True)
class RouteReducedCost:
    uav_id: str
    assignment: DiscreteRouteAssignment
    route_id: str
    nominal_route_cost: float
    integrated_resource_price: float
    route_switch_penalty: float
    total_reduced_cost: float
    resource_ids: tuple[str, ...]
    candidate_decision: UAVDecisionVariables


@dataclass(frozen=True)
class ReducedCostSelection:
    incumbent: RouteReducedCost
    selected: RouteReducedCost
    improvement: float
    reason: str

    @property
    def changes_assignment(self) -> bool:
        return self.selected.assignment != self.incumbent.assignment


class ReducedCostRouteSelector:
    """Prices complete route occupancy rather than a fixed route score."""

    def __init__(
        self,
        problem: HyperCertProblemDefinition,
        minimum_improvement: float = 1e-6,
        altitude_switch_penalty: float | None = None,
    ) -> None:
        if minimum_improvement < 0.0:
            raise ValueError("minimum_improvement cannot be negative")
        self.problem = problem
        self.occupancy = SoftOccupancyModel(problem)
        self.minimum_improvement = minimum_improvement
        self.altitude_switch_penalty = (
            problem.config.weights.route_switching
            if altitude_switch_penalty is None
            else float(altitude_switch_penalty)
        )

    def rank(
        self,
        uav_id: str,
        current: UAVDecisionVariables,
        duals: ResourceTimeDualVariables,
        route_indices: Iterable[int] | None = None,
    ) -> tuple[RouteReducedCost, ...]:
        uav_index = self._uav_index(uav_id)
        uav = self.problem.uavs[uav_index]
        indices = tuple(range(len(uav.route_candidates))) if route_indices is None else tuple(sorted(set(route_indices)))
        costs: list[RouteReducedCost] = []
        for route_index in indices:
            route = uav.route(route_index)
            for altitude_layer_index in route.permitted_altitude_layers:
                assignment = DiscreteRouteAssignment(route_index, altitude_layer_index)
                if not self._assignment_allowed(uav_index, current, assignment):
                    continue
                candidate = remap_decision_to_assignment(self.problem, uav_index, current, assignment)
                price_cost, _ = self.occupancy.integrated_price_cost_and_gradient(
                    uav_index, candidate, duals.as_mapping()
                )
                weights = self.problem.config.weights
                nominal_cost = (
                    weights.travel_time * float(np.sum(candidate.edge_travel_times_s))
                    + weights.route_length * route.route_length_m
                )
                switch_penalty = weights.route_switching * float(route_index != uav.initial_route_index)
                switch_penalty += self.altitude_switch_penalty * float(
                    altitude_layer_index != uav.initial_altitude_layer_index
                )
                costs.append(
                    RouteReducedCost(
                        uav_id=uav_id,
                        assignment=assignment,
                        route_id=route.route_id,
                        nominal_route_cost=float(nominal_cost),
                        integrated_resource_price=float(price_cost),
                        route_switch_penalty=float(switch_penalty),
                        total_reduced_cost=float(nominal_cost + price_cost + switch_penalty),
                        resource_ids=tuple(dict.fromkeys(route.resource_ids)),
                        candidate_decision=candidate,
                    )
                )
        return tuple(
            sorted(
                costs,
                key=lambda item: (
                    item.total_reduced_cost,
                    item.assignment.route_index,
                    item.assignment.altitude_layer_index,
                ),
            )
        )

    def select(
        self,
        uav_id: str,
        current: UAVDecisionVariables,
        duals: ResourceTimeDualVariables,
        route_indices: Iterable[int] | None = None,
        triggering_resource_ids: tuple[str, ...] = tuple(),
    ) -> ReducedCostSelection:
        ranking = self.rank(uav_id, current, duals, route_indices)
        if not ranking:
            raise ValueError(f"no feasible discrete assignments for {uav_id}")
        current_assignment = DiscreteRouteAssignment(current.route_index, current.altitude_layer_index)
        incumbent = next((entry for entry in ranking if entry.assignment == current_assignment), None)
        if incumbent is None:
            raise ValueError(f"current discrete assignment for {uav_id} is not feasible")
        best = ranking[0]
        improvement = incumbent.total_reduced_cost - best.total_reduced_cost
        if best.assignment == current_assignment or improvement <= self.minimum_improvement:
            best = incumbent
            improvement = 0.0
            reason = "incumbent has minimum reduced cost within tolerance"
        else:
            resources = ",".join(triggering_resource_ids) or "active capacity hyperedge"
            price_relief = incumbent.integrated_resource_price - best.integrated_resource_price
            reason = (
                f"reduced-cost improvement {improvement:.6g}; integrated price relief "
                f"{price_relief:.6g} on {resources}"
            )
        return ReducedCostSelection(incumbent, best, float(improvement), reason)

    def _assignment_allowed(
        self,
        uav_index: int,
        current: UAVDecisionVariables,
        assignment: DiscreteRouteAssignment,
    ) -> bool:
        uav = self.problem.uavs[uav_index]
        route = uav.route(assignment.route_index)
        altitude = assignment.altitude_layer_index
        if altitude not in route.permitted_altitude_layers:
            return False
        if altitude != current.altitude_layer_index and (
            current.altitude_layer_index,
            altitude,
        ) not in route.allowed_altitude_transitions:
            return False
        frozen_edge_count = len(uav.frozen_prefix.edge_travel_times_s)
        frozen_hold_count = len(uav.frozen_prefix.holding_times_s)
        current_route = uav.route(current.route_index)
        if frozen_edge_count > route.edge_count or frozen_hold_count > route.holding_count:
            return False
        if route.edge_ids[:frozen_edge_count] != current_route.edge_ids[:frozen_edge_count]:
            return False
        return True

    def _uav_index(self, uav_id: str) -> int:
        for index, uav in enumerate(self.problem.uavs):
            if uav.uav_id == uav_id:
                return index
        raise KeyError(uav_id)


def remap_decision_to_assignment(
    problem: HyperCertProblemDefinition,
    uav_index: int,
    current: UAVDecisionVariables,
    assignment: DiscreteRouteAssignment,
) -> UAVDecisionVariables:
    uav = problem.uavs[uav_index]
    old_route = uav.route(current.route_index)
    new_route = uav.route(assignment.route_index)
    if assignment.route_index == current.route_index:
        edge_times = current.edge_travel_times_s.copy()
        holding_times = current.holding_times_s.copy()
    else:
        old_occurrences: dict[str, list[int]] = {}
        for index, edge_id in enumerate(old_route.edge_ids):
            old_occurrences.setdefault(edge_id, []).append(index)
        used: dict[str, int] = {}
        edge_times = new_route.nominal_edge_times_s.copy()
        for index, edge_id in enumerate(new_route.edge_ids):
            occurrence = used.get(edge_id, 0)
            matches = old_occurrences.get(edge_id, [])
            if occurrence < len(matches):
                edge_times[index] = current.edge_travel_times_s[matches[occurrence]]
                used[edge_id] = occurrence + 1
        edge_times = np.clip(edge_times, new_route.min_edge_times_s, new_route.max_edge_times_s)
        old_holds = {
            (old_route.edge_ids[index], old_route.edge_ids[index + 1]): current.holding_times_s[index]
            for index in range(old_route.holding_count)
        }
        holding_times = np.zeros(new_route.holding_count, dtype=float)
        for index, allowed in enumerate(new_route.holding_allowed_after_edge):
            if allowed:
                holding_times[index] = old_holds.get(
                    (new_route.edge_ids[index], new_route.edge_ids[index + 1]),
                    0.0,
                )
        holding_times = np.clip(holding_times, 0.0, problem.config.max_holding_time_s)
    return UAVDecisionVariables(
        route_index=assignment.route_index,
        departure_delay_s=current.departure_delay_s,
        edge_travel_times_s=edge_times,
        holding_times_s=holding_times,
        trajectory_coefficients=current.trajectory_coefficients.copy(),
        altitude_layer_index=assignment.altitude_layer_index,
    )
