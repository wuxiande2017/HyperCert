from __future__ import annotations

from dataclasses import dataclass, field, replace
import heapq
import math
from time import perf_counter
from typing import Literal, Mapping

import numpy as np

from certificate.resource_certificate import ResourceCertificate
from reservation.reservation_manager import ReservationManager

from .acceptance_telemetry import (
    AcceptanceFunnel,
    CertificateFeedbackEvent,
    FailureReasonCount,
    PlannerRuntimeBreakdown,
    summarize_failure_reasons,
)
from .certificate_feedback import (
    CertificateEvaluation,
    CertificateFailureType,
    evaluate_certificate,
)
from .certificate_projection import (
    CertificateProjectionResult,
    ExactRobustCertificateProjector,
    decision_fingerprint,
    trajectory_fingerprint,
)
from .closed_loop_validation import MinimumSnapTrajectory
from .decision_variables import UAVDecisionVariables
from .geometric_separation import (
    ContinuousSeparationResult,
    ContinuousSeparationVerifier,
    apply_conservative_geometric_admission_gate,
)
from .hypergraph_branching import HypergraphBranchAndOptimize
from .problem_definition import HyperCertProblemDefinition
from .reduced_cost_route_selector import (
    DiscreteRouteAssignment,
    remap_decision_to_assignment,
)


FeedbackInformationMode = Literal[
    "binary",
    "generic",
    "resource_only",
    "resource_time",
    "resource_time_responsible",
    "full_witness",
    "structured",
]


@dataclass(frozen=True)
class SafeAnytimePlannerConfig:
    planning_budget_s: float = 30.0
    run_abstract_optimizer: bool = False
    abstract_budget_fraction: float = 0.25
    maximum_candidate_evaluations_per_uav: int = 32
    maximum_geometry_candidate_evaluations_per_uav: int = 96
    maximum_joint_geometry_repairs: int = 16
    maximum_global_feedback_iterations: int = 128
    maximum_total_candidate_evaluations: int = 2_000
    maximum_route_evaluations: int = 2_000
    maximum_replanning_calls: int = 2_000
    delay_guard_s: float = 0.05
    geometry_delay_step_s: float = 1.0
    generic_delay_step_s: float = 5.0
    generic_holding_step_s: float = 5.0
    departure_delay_score_weight: float = 1.0
    travel_time_score_weight: float = 0.1
    holding_time_score_weight: float = 0.25
    route_length_score_weight: float = 1e-4
    route_switch_score_penalty: float = 0.25
    admission_rejection_penalty: float = math.inf
    minimum_separation_m: float = 5.0
    tracking_bounds_m: Mapping[str, float] = field(default_factory=dict)
    tracking_tube_certified: bool = True
    try_route_alternatives: bool = True
    try_minimum_edge_times: bool = True
    commit_certified_incumbent: bool = True
    feedback_information_mode: FeedbackInformationMode = "structured"
    search_queue_mode: Literal["best_first", "fifo_coordinate"] = "best_first"

    def __post_init__(self) -> None:
        if self.planning_budget_s <= 0.0:
            raise ValueError("planning_budget_s must be positive")
        if not 0.0 <= self.abstract_budget_fraction <= 1.0:
            raise ValueError("abstract_budget_fraction must lie in [0, 1]")
        if min(
            self.maximum_candidate_evaluations_per_uav,
            self.maximum_geometry_candidate_evaluations_per_uav,
            self.maximum_total_candidate_evaluations,
            self.maximum_route_evaluations,
            self.maximum_replanning_calls,
        ) <= 0:
            raise ValueError("candidate evaluation limits must be positive")
        if min(
            self.maximum_joint_geometry_repairs,
            self.maximum_global_feedback_iterations,
        ) < 0:
            raise ValueError("feedback repair limits must be nonnegative")
        if min(
            self.delay_guard_s,
            self.geometry_delay_step_s,
            self.generic_delay_step_s,
            self.generic_holding_step_s,
        ) <= 0.0:
            raise ValueError("feedback timing increments must be positive")
        if self.minimum_separation_m < 0.0:
            raise ValueError("minimum_separation_m must be nonnegative")
        score_parameters = (
            self.departure_delay_score_weight,
            self.travel_time_score_weight,
            self.holding_time_score_weight,
            self.route_length_score_weight,
            self.route_switch_score_penalty,
            self.admission_rejection_penalty,
        )
        if any(value < 0.0 or math.isnan(value) for value in score_parameters):
            raise ValueError("candidate score weights and admission penalty must be nonnegative")
        if any(float(value) < 0.0 for value in self.tracking_bounds_m.values()):
            raise ValueError("tracking bounds must be nonnegative")
        if self.feedback_information_mode not in {
            "binary",
            "generic",
            "resource_only",
            "resource_time",
            "resource_time_responsible",
            "full_witness",
            "structured",
        }:
            raise ValueError(
                "feedback_information_mode must be binary/generic, resource_only, "
                "resource_time, resource_time_responsible, full_witness, or structured"
            )
        if self.search_queue_mode not in {"best_first", "fifo_coordinate"}:
            raise ValueError("search_queue_mode must be best_first or fifo_coordinate")


@dataclass(frozen=True)
class SafeAnytimePlannerResult:
    decisions: dict[str, UAVDecisionVariables]
    accepted_uav_ids: tuple[str, ...]
    rejected_uav_ids: tuple[str, ...]
    resource_certificate_uav_ids: tuple[str, ...]
    certificates: tuple[ResourceCertificate, ...]
    final_evaluation: CertificateEvaluation
    funnel: AcceptanceFunnel
    feedback_events: tuple[CertificateFeedbackEvent, ...]
    failure_summary: tuple[FailureReasonCount, ...]
    runtime: PlannerRuntimeBreakdown
    deadline_exceeded: bool
    wallclock_budget_exceeded: bool
    evaluation_budget_exhausted: bool
    replanning_budget_exhausted: bool
    stopping_reason: str
    atomic_commit_success: bool
    atomic_commit_reason: str
    candidate_evaluations: int
    route_evaluations: int
    replanning_calls: int
    abstract_optimizer_used: bool
    abstract_optimizer_converged: bool | None

    @property
    def returned_candidate_is_certified(self) -> bool:
        return self.final_evaluation.fully_certified

    @property
    def accepted_for_execution(self) -> bool:
        return self.returned_candidate_is_certified and self.atomic_commit_success


@dataclass(frozen=True)
class _InsertionSearchResult:
    accepted: bool
    decision: UAVDecisionVariables
    projection: CertificateProjectionResult | None
    trajectory: MinimumSnapTrajectory | None
    evaluation: CertificateEvaluation | None
    events: tuple[CertificateFeedbackEvent, ...]
    deadline_exceeded: bool
    candidate_evaluations: int


@dataclass(frozen=True)
class _GlobalFeedbackResult:
    decisions: dict[str, UAVDecisionVariables]
    certificates: dict[str, ResourceCertificate]
    trajectories: dict[str, MinimumSnapTrajectory]
    events: tuple[CertificateFeedbackEvent, ...]
    certified: bool
    deadline_exceeded: bool
    candidate_evaluations: int


class SafeAnytimeHyperCertPlanner:
    """Certificate-feedback planner with a fail-closed anytime contract.

    The soft route/timing optimizer is optional and only proposes a starting
    point. Execution admission is built incrementally from final minimum-snap
    polynomial resource certificates and continuous geometric separation.
    """

    def __init__(
        self,
        problem: HyperCertProblemDefinition,
        projector: ExactRobustCertificateProjector,
        *,
        config: SafeAnytimePlannerConfig | None = None,
        separation_verifier: ContinuousSeparationVerifier | None = None,
        reservation_manager: ReservationManager | None = None,
        abstract_optimizer: HypergraphBranchAndOptimize | None = None,
    ) -> None:
        if projector.problem is not problem:
            raise ValueError("projector must reference the planner problem")
        if projector.config.trajectory_model != "minimum_snap":
            raise ValueError(
                "safe anytime planning requires the final minimum-snap projector"
            )
        self.problem = problem
        self.projector = projector
        self.config = config or SafeAnytimePlannerConfig()
        self.separation_verifier = separation_verifier or (
            ContinuousSeparationVerifier()
        )
        self.reservation_manager = reservation_manager or ReservationManager(
            {
                resource.resource_id: resource.capacity
                for resource in problem.resources
            }
        )
        self.abstract_optimizer = abstract_optimizer or (
            HypergraphBranchAndOptimize(problem)
        )
        self._event_sequence = 0
        self._replanning_calls = 0

    def plan(
        self,
        initial_decisions: Mapping[str, UAVDecisionVariables],
        *,
        deadline_s: float | None = None,
        eligible_uav_ids: tuple[str, ...] | None = None,
    ) -> SafeAnytimePlannerResult:
        self.problem.validate_decisions(initial_decisions)
        self._event_sequence = 0
        self._replanning_calls = 0
        known_uav_ids = {uav.uav_id for uav in self.problem.uavs}
        eligible = (
            known_uav_ids
            if eligible_uav_ids is None
            else set(eligible_uav_ids)
        )
        if not eligible <= known_uav_ids:
            raise ValueError(
                f"eligible_uav_ids contains unknown UAVs: "
                f"{sorted(eligible - known_uav_ids)}"
            )
        if eligible_uav_ids is not None and len(eligible_uav_ids) != len(eligible):
            raise ValueError("eligible_uav_ids contains duplicates")
        started = perf_counter()
        budget_deadline = started + self.config.planning_budget_s
        effective_deadline = (
            budget_deadline
            if deadline_s is None
            else min(float(deadline_s), budget_deadline)
        )
        decisions = dict(initial_decisions)
        abstract_started = perf_counter()
        abstract_converged: bool | None = None
        if self.config.run_abstract_optimizer and perf_counter() < effective_deadline:
            abstract_deadline = min(
                effective_deadline,
                started
                + self.config.planning_budget_s
                * self.config.abstract_budget_fraction,
            )
            optimized = self.abstract_optimizer.solve(
                decisions,
                deadline_s=abstract_deadline,
            )
            decisions = dict(optimized.decisions)
            abstract_converged = bool(optimized.continuous_result.converged)
        abstract_runtime = perf_counter() - abstract_started

        events: list[CertificateFeedbackEvent] = []
        total_evaluations = 0
        priority_order = tuple(
            uav.uav_id
            for uav in sorted(
                self.problem.uavs,
                key=lambda item: (
                    item.release_time_s,
                    -item.priority_weight,
                    item.uav_id,
                ),
            )
            if uav.uav_id in eligible
        )

        resource_started = perf_counter()
        resource_ids: list[str] = []
        resource_certificates: dict[str, ResourceCertificate] = {}
        resource_trajectories: dict[str, MinimumSnapTrajectory] = {}
        resource_decisions = dict(decisions)

        # A fully certified shadow incumbent is maintained during the resource
        # stage so an early timeout never forces an uncertified return.
        shadow_ids: list[str] = []
        shadow_certificates: dict[str, ResourceCertificate] = {}
        shadow_trajectories: dict[str, MinimumSnapTrajectory] = {}
        shadow_decisions = dict(decisions)
        deadline_exceeded = False

        for uav_id in priority_order:
            if self._deadline_reached(effective_deadline, total_evaluations):
                deadline_exceeded = True
                break
            result = self._search_insertion(
                resource_decisions,
                uav_id,
                tuple(resource_certificates.values()),
                resource_trajectories,
                require_geometry=False,
                stage="resource_feedback",
                deadline_s=effective_deadline,
                remaining_total_evaluations=(
                    self._remaining_candidate_evaluations(total_evaluations)
                ),
            )
            events.extend(result.events)
            total_evaluations += result.candidate_evaluations
            deadline_exceeded = deadline_exceeded or result.deadline_exceeded
            if not result.accepted:
                if result.deadline_exceeded:
                    break
                continue
            resource_decisions[uav_id] = result.decision
            resource_ids.append(uav_id)
            certificate = result.projection.candidate_certificates[0]
            resource_certificates[uav_id] = certificate
            resource_trajectories[uav_id] = result.trajectory

            shadow_geometry = self.separation_verifier.verify(
                {
                    **shadow_trajectories,
                    uav_id: result.trajectory,
                },
                minimum_separation_m=self.config.minimum_separation_m,
                tracking_bounds_m=self.config.tracking_bounds_m,
            )
            if (
                shadow_geometry.certified_safe
                and self.config.tracking_tube_certified
            ):
                shadow_ids.append(uav_id)
                shadow_certificates[uav_id] = certificate
                shadow_trajectories[uav_id] = result.trajectory
                shadow_decisions[uav_id] = result.decision
            elif self.config.tracking_tube_certified:
                # Greedy insertion can leave a smaller independent set than
                # the deterministic admission gate. Refresh the certified
                # incumbent immediately, while the current resource insertion
                # is still within budget, so a later timeout cannot fall back
                # to an avoidably small shadow set.
                current_priority = tuple(
                    candidate_id
                    for candidate_id in reversed(priority_order)
                    if candidate_id in resource_trajectories
                )
                shadow_admission = (
                    apply_conservative_geometric_admission_gate(
                        resource_trajectories,
                        minimum_separation_m=(
                            self.config.minimum_separation_m
                        ),
                        tracking_bounds_m=self.config.tracking_bounds_m,
                        rejection_order=current_priority,
                        verifier=self.separation_verifier,
                    )
                )
                if len(shadow_admission.accepted_uav_ids) > len(
                    shadow_ids
                ):
                    shadow_ids = list(
                        shadow_admission.accepted_uav_ids
                    )
                    shadow_certificates = {
                        candidate_id: resource_certificates[candidate_id]
                        for candidate_id in shadow_ids
                    }
                    shadow_trajectories = {
                        candidate_id: resource_trajectories[candidate_id]
                        for candidate_id in shadow_ids
                    }
                    shadow_decisions = dict(resource_decisions)

        resource_runtime = perf_counter() - resource_started

        geometry_started = perf_counter()
        accepted_ids = list(shadow_ids)
        accepted_certificates = dict(shadow_certificates)
        accepted_trajectories = dict(shadow_trajectories)
        accepted_decisions = dict(shadow_decisions)

        if (
            not deadline_exceeded
            and self.config.tracking_tube_certified
            and resource_ids
        ):
            priority_rank = {
                uav_id: index
                for index, uav_id in enumerate(priority_order)
            }
            lower_priority_first = tuple(
                uav_id
                for uav_id in reversed(priority_order)
                if uav_id in resource_trajectories
            )

            # Establish the best currently certified geometric incumbent
            # before spending time on the joint repair search. This protects
            # the anytime contract when the joint search crosses its budget.
            preliminary_admission = (
                apply_conservative_geometric_admission_gate(
                    resource_trajectories,
                    minimum_separation_m=self.config.minimum_separation_m,
                    tracking_bounds_m=self.config.tracking_bounds_m,
                    rejection_order=lower_priority_first,
                    verifier=self.separation_verifier,
                )
            )
            if len(preliminary_admission.accepted_uav_ids) > len(
                accepted_ids
            ):
                accepted_ids = list(
                    preliminary_admission.accepted_uav_ids
                )
                accepted_certificates = {
                    uav_id: resource_certificates[uav_id]
                    for uav_id in accepted_ids
                }
                accepted_trajectories = {
                    uav_id: resource_trajectories[uav_id]
                    for uav_id in accepted_ids
                }
                accepted_decisions = dict(resource_decisions)

            # Complete the inexpensive local certificate-feedback pass before
            # entering the global joint search. Full feedback is therefore an
            # anytime extension of local feedback: it can improve the saved
            # incumbent, but can never consume the budget needed to obtain it.
            preliminary_rejected = tuple(
                uav_id
                for uav_id in resource_ids
                if uav_id not in set(accepted_ids)
            )
            for uav_id in preliminary_rejected:
                if self._deadline_reached(
                    effective_deadline,
                    total_evaluations,
                ):
                    deadline_exceeded = True
                    break
                result = self._search_insertion(
                    accepted_decisions,
                    uav_id,
                    tuple(accepted_certificates.values()),
                    accepted_trajectories,
                    require_geometry=True,
                    stage="geometry_feedback_incumbent",
                    deadline_s=effective_deadline,
                    remaining_total_evaluations=(
                        self._remaining_candidate_evaluations(total_evaluations)
                    ),
                )
                events.extend(result.events)
                total_evaluations += result.candidate_evaluations
                deadline_exceeded = (
                    deadline_exceeded or result.deadline_exceeded
                )
                if result.accepted:
                    accepted_decisions[uav_id] = result.decision
                    accepted_ids.append(uav_id)
                    accepted_certificates[uav_id] = (
                        result.projection.candidate_certificates[0]
                    )
                    accepted_trajectories[uav_id] = result.trajectory
                elif result.deadline_exceeded:
                    break

            global_feedback = self._joint_global_feedback(
                resource_decisions,
                tuple(resource_ids),
                priority_rank,
                deadline_s=effective_deadline,
                remaining_total_evaluations=(
                    self._remaining_candidate_evaluations(total_evaluations)
                ),
            )
            events.extend(global_feedback.events)
            total_evaluations += global_feedback.candidate_evaluations
            deadline_exceeded = (
                deadline_exceeded or global_feedback.deadline_exceeded
            )
            if global_feedback.certified:
                resource_decisions = global_feedback.decisions
                resource_certificates = global_feedback.certificates
                resource_trajectories = global_feedback.trajectories

            for _ in range(self.config.maximum_joint_geometry_repairs):
                current_geometry = self.separation_verifier.verify(
                    resource_trajectories,
                    minimum_separation_m=self.config.minimum_separation_m,
                    tracking_bounds_m=self.config.tracking_bounds_m,
                )
                if current_geometry.certified_safe:
                    break
                if self._deadline_reached(
                    effective_deadline,
                    total_evaluations,
                ):
                    deadline_exceeded = True
                    break
                conflict = next(
                    pair
                    for pair in current_geometry.pairs
                    if not pair.certified_safe
                )
                repair_candidates = sorted(
                    (conflict.first_uav_id, conflict.second_uav_id),
                    key=lambda uav_id: priority_rank[uav_id],
                    reverse=True,
                )
                repaired_pair = False
                for uav_id in repair_candidates:
                    other_certificates = tuple(
                        certificate
                        for other_id, certificate in resource_certificates.items()
                        if other_id != uav_id
                    )
                    other_trajectories = {
                        other_id: trajectory
                        for other_id, trajectory in resource_trajectories.items()
                        if other_id != uav_id
                    }
                    result = self._search_insertion(
                        resource_decisions,
                        uav_id,
                        other_certificates,
                        other_trajectories,
                        require_geometry=True,
                        stage="geometry_joint_repair",
                        deadline_s=effective_deadline,
                        remaining_total_evaluations=(
                            self._remaining_candidate_evaluations(total_evaluations)
                        ),
                    )
                    events.extend(result.events)
                    total_evaluations += result.candidate_evaluations
                    deadline_exceeded = (
                        deadline_exceeded or result.deadline_exceeded
                    )
                    if result.accepted:
                        resource_decisions[uav_id] = result.decision
                        resource_certificates[uav_id] = (
                            result.projection.candidate_certificates[0]
                        )
                        resource_trajectories[uav_id] = result.trajectory
                        repaired_pair = True
                        break
                    if result.deadline_exceeded:
                        break
                if deadline_exceeded or not repaired_pair:
                    break

            admission = apply_conservative_geometric_admission_gate(
                resource_trajectories,
                minimum_separation_m=self.config.minimum_separation_m,
                tracking_bounds_m=self.config.tracking_bounds_m,
                rejection_order=lower_priority_first,
                verifier=self.separation_verifier,
            )
            if len(admission.accepted_uav_ids) >= len(accepted_ids):
                accepted_ids = list(admission.accepted_uav_ids)
                accepted_certificates = {
                    uav_id: resource_certificates[uav_id]
                    for uav_id in accepted_ids
                }
                accepted_trajectories = {
                    uav_id: resource_trajectories[uav_id]
                    for uav_id in accepted_ids
                }
                accepted_decisions = dict(resource_decisions)

            # Reinsert geometry-rejected trajectories with the same typed
            # resource and geometry feedback used during initial admission.
            rejected_for_reinsertion = tuple(
                uav_id
                for uav_id in resource_ids
                if uav_id not in set(accepted_ids)
            )
            for uav_id in rejected_for_reinsertion:
                if self._deadline_reached(effective_deadline, total_evaluations):
                    deadline_exceeded = True
                    break
                result = self._search_insertion(
                    accepted_decisions,
                    uav_id,
                    tuple(accepted_certificates.values()),
                    accepted_trajectories,
                    require_geometry=True,
                    stage="geometry_feedback",
                    deadline_s=effective_deadline,
                    remaining_total_evaluations=(
                        self._remaining_candidate_evaluations(total_evaluations)
                    ),
                )
                events.extend(result.events)
                total_evaluations += result.candidate_evaluations
                deadline_exceeded = (
                    deadline_exceeded or result.deadline_exceeded
                )
                if not result.accepted:
                    if result.deadline_exceeded:
                        break
                    continue
                accepted_decisions[uav_id] = result.decision
                accepted_ids.append(uav_id)
                accepted_certificates[uav_id] = (
                    result.projection.candidate_certificates[0]
                )
                accepted_trajectories[uav_id] = result.trajectory

        geometry_runtime = perf_counter() - geometry_started

        final_projection, final_geometry, final_evaluation = (
            self._evaluate_incumbent(
                accepted_decisions,
                tuple(sorted(accepted_ids)),
            )
        )
        if not final_evaluation.fully_certified:
            # This path should be unreachable, but the fail-closed fallback is
            # deliberately explicit and testable.
            accepted_ids = list(shadow_ids)
            accepted_decisions = dict(shadow_decisions)
            accepted_certificates = dict(shadow_certificates)
            accepted_trajectories = dict(shadow_trajectories)
            final_projection, final_geometry, final_evaluation = (
                self._evaluate_incumbent(
                    accepted_decisions,
                    tuple(sorted(accepted_ids)),
                )
            )
        if not final_evaluation.fully_certified:
            accepted_ids = []
            accepted_certificates = {}
            accepted_trajectories = {}
            final_projection, final_geometry, final_evaluation = (
                self._evaluate_incumbent(
                    decisions,
                    tuple(),
                )
            )

        commit_started = perf_counter()
        commit_success = not accepted_ids
        commit_reason = "empty_certified_incumbent"
        if (
            accepted_ids
            and self.config.commit_certified_incumbent
            and not self._time_expired(effective_deadline)
        ):
            snapshot = self.reservation_manager.snapshot()
            commit_projection = self.projector.project(
                accepted_decisions,
                existing_certificates=snapshot.certificates,
                snapshot_version=snapshot.version,
                uav_ids=tuple(sorted(accepted_ids)),
            )
            if commit_projection.is_safe:
                transaction = self.reservation_manager.make_transaction(
                    "hypercert_phase13",
                    snapshot,
                    commit_projection.candidate_certificates,
                    self.reservation_manager.create_lease(
                        "hypercert_phase13"
                    ),
                )
                commit = self.reservation_manager.commit(transaction)
                commit_success = bool(commit.success)
                commit_reason = commit.reason or "committed"
            else:
                commit_success = False
                commit_reason = "commit_snapshot_capacity_conflict"
        elif accepted_ids and self.config.commit_certified_incumbent:
            commit_success = False
            commit_reason = "deadline_exceeded_before_commit"
            deadline_exceeded = True
        elif accepted_ids:
            commit_success = False
            commit_reason = "commit_disabled"
        commit_runtime = perf_counter() - commit_started

        # A single exact Bernstein projection is deliberately non-preemptive.
        # Re-sample the clock after the final projection/commit so a call that
        # crosses the budget inside that atomic safety operation is reported
        # as a deadline overrun while still returning only its safe incumbent.
        deadline_exceeded = (
            deadline_exceeded or self._time_expired(effective_deadline)
        )
        if deadline_exceeded:
            representative = (
                accepted_decisions[accepted_ids[0]]
                if accepted_ids
                else next(iter(accepted_decisions.values()))
            )
            self._event_sequence += 1
            events.append(
                CertificateFeedbackEvent(
                    sequence=self._event_sequence,
                    stage="deadline",
                    uav_id="__planner__",
                    attempt=total_evaluations,
                    action="return_certified_incumbent",
                    candidate_fingerprint=decision_fingerprint(
                        accepted_decisions
                    ),
                    route_index=representative.route_index,
                    departure_delay_s=representative.departure_delay_s,
                    edge_travel_time_s=float(
                        np.sum(representative.edge_travel_times_s)
                    ),
                    holding_time_s=float(
                        np.sum(representative.holding_times_s)
                    ),
                    accepted=final_evaluation.fully_certified,
                    fully_certified=final_evaluation.fully_certified,
                    failure_types=(
                        CertificateFailureType.DEADLINE_EXCEEDED,
                    ),
                    resource_witness_count=0,
                    geometry_witness_count=0,
                    responsible_uav_ids=tuple(),
                    projection_runtime_s=(
                        final_projection.projection_runtime_s
                    ),
                    geometry_runtime_s=0.0,
                    cache_hits=final_projection.trajectory_cache_hits,
                    cache_misses=final_projection.trajectory_cache_misses,
                )
            )

        accepted_tuple = tuple(sorted(accepted_ids))
        resource_tuple = tuple(sorted(resource_ids))
        rejected = tuple(
            sorted(eligible - set(accepted_tuple))
        )
        funnel = AcceptanceFunnel(
            abstract_scheduled=len(eligible),
            resource_certificate_accepted=len(resource_tuple),
            geometry_certificate_accepted=len(accepted_tuple),
            committed=len(accepted_tuple) if commit_success else 0,
        )
        total_runtime = perf_counter() - started
        wallclock_budget_exceeded = total_runtime >= self.config.planning_budget_s
        evaluation_budget_exhausted = total_evaluations >= min(
            self.config.maximum_total_candidate_evaluations,
            self.config.maximum_route_evaluations,
        )
        replanning_budget_exhausted = (
            self._replanning_calls >= self.config.maximum_replanning_calls
        )
        stopping_reason = (
            "wallclock_budget_exceeded_certified_incumbent_returned"
            if wallclock_budget_exceeded
            else "evaluation_budget_exhausted_certified_incumbent_returned"
            if evaluation_budget_exhausted
            else "replanning_budget_exhausted_certified_incumbent_returned"
            if replanning_budget_exhausted
            else "combined_search_limit_certified_incumbent_returned"
            if deadline_exceeded
            else "certified_search_complete"
        )
        return SafeAnytimePlannerResult(
            decisions=accepted_decisions,
            accepted_uav_ids=accepted_tuple,
            rejected_uav_ids=rejected,
            resource_certificate_uav_ids=resource_tuple,
            certificates=final_projection.candidate_certificates,
            final_evaluation=final_evaluation,
            funnel=funnel,
            feedback_events=tuple(events),
            failure_summary=summarize_failure_reasons(events),
            runtime=PlannerRuntimeBreakdown(
                abstract_optimization_s=abstract_runtime,
                resource_feedback_s=resource_runtime,
                geometry_feedback_s=geometry_runtime,
                commit_s=commit_runtime,
                total_s=total_runtime,
            ),
            deadline_exceeded=deadline_exceeded,
            wallclock_budget_exceeded=wallclock_budget_exceeded,
            evaluation_budget_exhausted=evaluation_budget_exhausted,
            replanning_budget_exhausted=replanning_budget_exhausted,
            stopping_reason=stopping_reason,
            atomic_commit_success=commit_success,
            atomic_commit_reason=commit_reason,
            candidate_evaluations=total_evaluations,
            route_evaluations=total_evaluations,
            replanning_calls=self._replanning_calls,
            abstract_optimizer_used=self.config.run_abstract_optimizer,
            abstract_optimizer_converged=abstract_converged,
        )

    def _search_insertion(
        self,
        decisions: Mapping[str, UAVDecisionVariables],
        uav_id: str,
        existing_certificates: tuple[ResourceCertificate, ...],
        existing_trajectories: Mapping[str, MinimumSnapTrajectory],
        *,
        require_geometry: bool,
        stage: str,
        deadline_s: float,
        remaining_total_evaluations: int,
    ) -> _InsertionSearchResult:
        uav_index = self._uav_index(uav_id)
        queue: list[tuple[float, int, str, UAVDecisionVariables]] = []
        serial = 0
        for action, candidate in self._root_candidates(
            uav_index,
            decisions[uav_id],
        ):
            heapq.heappush(
                queue,
                (self._queue_priority(uav_index, candidate, serial), serial, action, candidate),
            )
            serial += 1
        seen: set[str] = set()
        events = []
        evaluations = 0
        stage_limit = (
            self.config.maximum_geometry_candidate_evaluations_per_uav
            if require_geometry
            else self.config.maximum_candidate_evaluations_per_uav
        )
        maximum_evaluations = min(
            stage_limit,
            max(0, remaining_total_evaluations),
        )

        while queue and evaluations < maximum_evaluations:
            if self._time_expired(deadline_s):
                return _InsertionSearchResult(
                    False,
                    decisions[uav_id],
                    None,
                    None,
                    None,
                    tuple(events),
                    True,
                    evaluations,
                )
            _, _, action, candidate = heapq.heappop(queue)
            if (
                self._candidate_score(uav_index, candidate)
                > self.config.admission_rejection_penalty
            ):
                break
            fingerprint = trajectory_fingerprint(uav_id, candidate)
            if fingerprint in seen:
                continue
            seen.add(fingerprint)
            evaluations += 1
            trial_decisions = dict(decisions)
            trial_decisions[uav_id] = candidate
            projection = self.projector.project(
                trial_decisions,
                existing_certificates=existing_certificates,
                uav_ids=(uav_id,),
            )
            geometry_runtime = 0.0
            geometry: ContinuousSeparationResult | None = None
            trajectory = projection.polynomial_trajectories.get(
                uav_id
            ) or self.projector.polynomial_trajectory_provider(
                uav_index,
                candidate,
            )
            if require_geometry:
                geometry_started = perf_counter()
                geometry = self.separation_verifier.verify(
                    {
                        **existing_trajectories,
                        uav_id: trajectory,
                    },
                    minimum_separation_m=self.config.minimum_separation_m,
                    tracking_bounds_m=self.config.tracking_bounds_m,
                )
                geometry_runtime = perf_counter() - geometry_started
            evaluation = evaluate_certificate(
                f"{stage}:{uav_id}:{fingerprint[:16]}",
                projection,
                geometry=geometry,
                require_geometry=require_geometry,
                tracking_tube_safe=self.config.tracking_tube_certified,
                certificate_runtime_s=(
                    projection.projection_runtime_s + geometry_runtime
                ),
            )
            accepted = evaluation.fully_certified
            self._event_sequence += 1
            events.append(
                CertificateFeedbackEvent(
                    sequence=self._event_sequence,
                    stage=stage,
                    uav_id=uav_id,
                    attempt=evaluations,
                    action=action,
                    candidate_fingerprint=fingerprint,
                    route_index=candidate.route_index,
                    departure_delay_s=candidate.departure_delay_s,
                    edge_travel_time_s=float(
                        np.sum(candidate.edge_travel_times_s)
                    ),
                    holding_time_s=float(
                        np.sum(candidate.holding_times_s)
                    ),
                    accepted=accepted,
                    fully_certified=evaluation.fully_certified,
                    failure_types=evaluation.failure_types,
                    resource_witness_count=len(
                        evaluation.resource_witnesses
                    ),
                    geometry_witness_count=len(
                        evaluation.geometry_witnesses
                    ),
                    responsible_uav_ids=evaluation.responsible_uav_ids,
                    projection_runtime_s=projection.projection_runtime_s,
                    geometry_runtime_s=geometry_runtime,
                    cache_hits=projection.trajectory_cache_hits,
                    cache_misses=projection.trajectory_cache_misses,
                    feedback_information_mode=self.config.feedback_information_mode,
                    witness_resource_ids=tuple(
                        witness.resource_id for witness in evaluation.resource_witnesses
                    ),
                    witness_time_supports_s=tuple(
                        (witness.start_time_s, witness.end_time_s)
                        for witness in evaluation.resource_witnesses
                    ),
                    witness_peak_excess=max(
                        (witness.peak_occupancy - witness.capacity for witness in evaluation.resource_witnesses),
                        default=0,
                    ),
                    witness_overload_integral_uav_s=sum(
                        witness.overload_integral_uav_s for witness in evaluation.resource_witnesses
                    ),
                    modified_uav_count=1,
                    active_uav_count=max(len(trial_decisions), 1),
                )
            )
            if accepted:
                return _InsertionSearchResult(
                    True,
                    candidate,
                    projection,
                    trajectory,
                    evaluation,
                    tuple(events),
                    False,
                    evaluations,
                )

            if self._replanning_calls >= self.config.maximum_replanning_calls:
                continue
            if self.config.feedback_information_mode in {"binary", "generic"}:
                neighbors = self._generic_feedback_neighbors(
                    uav_index,
                    candidate,
                )
            else:
                neighbors = self._information_limited_feedback_neighbors(
                    uav_index,
                    candidate,
                    projection,
                    evaluation,
                    self.config.feedback_information_mode,
                )
            if neighbors:
                self._replanning_calls += 1
            for next_action, neighbor in neighbors:
                next_fingerprint = trajectory_fingerprint(uav_id, neighbor)
                if next_fingerprint in seen:
                    continue
                heapq.heappush(
                    queue,
                    (
                        self._queue_priority(uav_index, neighbor, serial),
                        serial,
                        f"{action}|{next_action}",
                        neighbor,
                    ),
                )
                serial += 1

        return _InsertionSearchResult(
            False,
            decisions[uav_id],
            None,
            None,
            None,
            tuple(events),
            False,
            evaluations,
        )

    def _joint_global_feedback(
        self,
        decisions: Mapping[str, UAVDecisionVariables],
        uav_ids: tuple[str, ...],
        priority_rank: Mapping[str, int],
        *,
        deadline_s: float,
        remaining_total_evaluations: int,
    ) -> _GlobalFeedbackResult:
        current = dict(decisions)
        events = []
        evaluations = 0
        limit = min(
            self.config.maximum_global_feedback_iterations,
            max(0, remaining_total_evaluations),
        )
        last_projection: CertificateProjectionResult | None = None
        last_trajectories: dict[str, MinimumSnapTrajectory] = {}
        while evaluations < limit:
            if self._time_expired(deadline_s):
                return _GlobalFeedbackResult(
                    current,
                    {},
                    {},
                    tuple(events),
                    False,
                    True,
                    evaluations,
                )
            projection = self.projector.project(
                current,
                uav_ids=tuple(sorted(uav_ids)),
            )
            trajectories = dict(projection.polynomial_trajectories)
            geometry_started = perf_counter()
            geometry = self.separation_verifier.verify(
                trajectories,
                minimum_separation_m=self.config.minimum_separation_m,
                tracking_bounds_m=self.config.tracking_bounds_m,
            )
            geometry_runtime = perf_counter() - geometry_started
            evaluation = evaluate_certificate(
                f"geometry_joint_global:{decision_fingerprint(current)[:16]}",
                projection,
                geometry=geometry,
                require_geometry=True,
                tracking_tube_safe=self.config.tracking_tube_certified,
                certificate_runtime_s=(
                    projection.projection_runtime_s + geometry_runtime
                ),
            )
            evaluations += 1
            if self.config.feedback_information_mode in {"binary", "generic"}:
                action = self._generic_global_feedback_action(
                    current,
                    uav_ids,
                    priority_rank,
                )
            else:
                action = self._information_limited_global_feedback_action(
                    current,
                    projection,
                    evaluation,
                    priority_rank,
                    self.config.feedback_information_mode,
                )
            if evaluation.fully_certified:
                chosen_uav = uav_ids[0] if uav_ids else ""
                action_label = "joint_candidate_certified"
            elif action is None:
                chosen_uav = (
                    evaluation.responsible_uav_ids[0]
                    if evaluation.responsible_uav_ids
                    else (uav_ids[0] if uav_ids else "")
                )
                action_label = "no_feasible_feedback_action"
            else:
                chosen_uav, action_label, next_decision = action
            event_decision = current[chosen_uav] if chosen_uav else next(
                iter(current.values())
            )
            self._event_sequence += 1
            events.append(
                CertificateFeedbackEvent(
                    sequence=self._event_sequence,
                    stage="geometry_joint_global",
                    uav_id=chosen_uav,
                    attempt=evaluations,
                    action=action_label,
                    candidate_fingerprint=trajectory_fingerprint(
                        chosen_uav,
                        event_decision,
                    ),
                    route_index=event_decision.route_index,
                    departure_delay_s=event_decision.departure_delay_s,
                    edge_travel_time_s=float(
                        np.sum(event_decision.edge_travel_times_s)
                    ),
                    holding_time_s=float(
                        np.sum(event_decision.holding_times_s)
                    ),
                    accepted=evaluation.fully_certified,
                    fully_certified=evaluation.fully_certified,
                    failure_types=evaluation.failure_types,
                    resource_witness_count=len(
                        evaluation.resource_witnesses
                    ),
                    geometry_witness_count=len(
                        evaluation.geometry_witnesses
                    ),
                    responsible_uav_ids=evaluation.responsible_uav_ids,
                    projection_runtime_s=projection.projection_runtime_s,
                    geometry_runtime_s=geometry_runtime,
                    cache_hits=projection.trajectory_cache_hits,
                    cache_misses=projection.trajectory_cache_misses,
                    feedback_information_mode=self.config.feedback_information_mode,
                    witness_resource_ids=tuple(
                        witness.resource_id for witness in evaluation.resource_witnesses
                    ),
                    witness_time_supports_s=tuple(
                        (witness.start_time_s, witness.end_time_s)
                        for witness in evaluation.resource_witnesses
                    ),
                    witness_peak_excess=max(
                        (witness.peak_occupancy - witness.capacity for witness in evaluation.resource_witnesses),
                        default=0,
                    ),
                    witness_overload_integral_uav_s=sum(
                        witness.overload_integral_uav_s for witness in evaluation.resource_witnesses
                    ),
                    modified_uav_count=1,
                    active_uav_count=max(len(current), 1),
                )
            )
            last_projection = projection
            last_trajectories = trajectories
            if evaluation.fully_certified:
                return _GlobalFeedbackResult(
                    current,
                    {
                        certificate.uav_id: certificate
                        for certificate in projection.candidate_certificates
                    },
                    trajectories,
                    tuple(events),
                    True,
                    False,
                    evaluations,
                )
            if action is None:
                break
            if self._replanning_calls >= self.config.maximum_replanning_calls:
                break
            self._replanning_calls += 1
            current[chosen_uav] = next_decision

        certificates = (
            {
                certificate.uav_id: certificate
                for certificate in last_projection.candidate_certificates
            }
            if last_projection is not None
            else {}
        )
        return _GlobalFeedbackResult(
            current,
            certificates,
            last_trajectories,
            tuple(events),
            False,
            False,
            evaluations,
        )

    def _global_feedback_action(
        self,
        decisions: Mapping[str, UAVDecisionVariables],
        projection: CertificateProjectionResult,
        evaluation: CertificateEvaluation,
        priority_rank: Mapping[str, int],
    ) -> tuple[str, str, UAVDecisionVariables] | None:
        if CertificateFailureType.RESOURCE_OVERLOAD in evaluation.failure_types:
            resource_candidates = tuple(
                sorted(
                    {
                        uav_id
                        for witness in evaluation.resource_witnesses
                        for uav_id in witness.responsible_uav_ids
                    },
                    key=lambda uav_id: priority_rank[uav_id],
                    reverse=True,
                )
            )
            for uav_id in resource_candidates:
                shift = self._required_candidate_delay_shift(
                    uav_id,
                    projection,
                )
                delayed = self._add_departure_delay(
                    decisions[uav_id],
                    shift,
                )
                if delayed is not None:
                    return (
                        uav_id,
                        f"joint_resource_delay_{shift:.6g}",
                        delayed,
                    )
                uav_index = self._uav_index(uav_id)
                held = self._add_holding_before_witness(
                    uav_index,
                    decisions[uav_id],
                    evaluation,
                    shift,
                )
                if held is not None:
                    return (
                        uav_id,
                        f"joint_resource_holding_{shift:.6g}",
                        held,
                    )
                rerouted = self._reroute_away_from_witness(
                    uav_index,
                    decisions[uav_id],
                    evaluation,
                )
                if rerouted is not None:
                    return (uav_id, "joint_resource_reroute", rerouted)
        geometry_candidates = tuple(
            sorted(
                {
                    uav_id
                    for witness in evaluation.geometry_witnesses
                    for uav_id in (witness.uav_i, witness.uav_j)
                },
                key=lambda uav_id: priority_rank[uav_id],
                reverse=True,
            )
        )
        for uav_id in geometry_candidates:
            delayed = self._add_departure_delay(
                decisions[uav_id],
                self.config.geometry_delay_step_s,
            )
            if delayed is not None:
                return (
                    uav_id,
                    f"joint_geometry_delay_{self.config.geometry_delay_step_s:.6g}",
                    delayed,
                )
            rerouted = self._reroute_away_from_witness(
                self._uav_index(uav_id),
                decisions[uav_id],
                evaluation,
            )
            if rerouted is not None:
                return (uav_id, "joint_geometry_reroute", rerouted)
        return None

    def _information_limited_global_feedback_action(
        self,
        decisions: Mapping[str, UAVDecisionVariables],
        projection: CertificateProjectionResult,
        evaluation: CertificateEvaluation,
        priority_rank: Mapping[str, int],
        mode: FeedbackInformationMode,
    ) -> tuple[str, str, UAVDecisionVariables] | None:
        if mode in {"full_witness", "structured"}:
            return self._global_feedback_action(
                decisions,
                projection,
                evaluation,
                priority_rank,
            )
        if CertificateFailureType.RESOURCE_OVERLOAD not in evaluation.failure_types:
            return self._global_feedback_action(
                decisions,
                projection,
                evaluation,
                priority_rank,
            )
        candidates = self._information_limited_responsible_ids(
            tuple(decisions),
            evaluation,
            mode,
        )
        for uav_id in sorted(
            candidates,
            key=lambda candidate_id: priority_rank[candidate_id],
            reverse=True,
        ):
            uav_index = self._uav_index(uav_id)
            decision = decisions[uav_id]
            if mode == "resource_only":
                rerouted = self._reroute_away_from_resource_ids(
                    uav_index,
                    decision,
                    self._resource_ids(evaluation),
                )
                if rerouted is not None:
                    return uav_id, "joint_resource_only_reroute", rerouted
                delayed = self._add_departure_delay(
                    decision,
                    self.config.generic_delay_step_s,
                )
                if delayed is not None:
                    return uav_id, "joint_resource_only_delay", delayed
            else:
                shift = self._required_resource_time_shift(
                    uav_id,
                    projection,
                    evaluation,
                )
                delayed = self._add_departure_delay(decision, shift)
                if delayed is not None:
                    return uav_id, f"joint_resource_time_delay_{shift:.6g}", delayed
                held = self._add_holding_before_resource_time(
                    uav_index,
                    decision,
                    self._resource_time_supports(evaluation),
                    shift,
                )
                if held is not None:
                    return uav_id, f"joint_resource_time_holding_{shift:.6g}", held
                rerouted = self._reroute_away_from_resource_ids(
                    uav_index,
                    decision,
                    self._resource_ids(evaluation),
                )
                if rerouted is not None:
                    return uav_id, "joint_resource_time_reroute", rerouted
        return None

    def _generic_global_feedback_action(
        self,
        decisions: Mapping[str, UAVDecisionVariables],
        uav_ids: tuple[str, ...],
        priority_rank: Mapping[str, int],
    ) -> tuple[str, str, UAVDecisionVariables] | None:
        """Choose a blind global action using no certificate witness fields."""

        for uav_id in sorted(
            uav_ids,
            key=lambda candidate_id: priority_rank[candidate_id],
            reverse=True,
        ):
            delayed = self._add_departure_delay(
                decisions[uav_id],
                self.config.generic_delay_step_s,
            )
            if delayed is not None:
                return (uav_id, "generic_global_delay", delayed)
        return None

    def _reroute_away_from_witness(
        self,
        uav_index: int,
        candidate: UAVDecisionVariables,
        evaluation: CertificateEvaluation,
    ) -> UAVDecisionVariables | None:
        uav = self.problem.uavs[uav_index]
        blocked_resources = {
            witness.resource_id
            for witness in evaluation.resource_witnesses
            if uav.uav_id in witness.responsible_uav_ids
        }
        return self._reroute_away_from_resource_ids(
            uav_index,
            candidate,
            blocked_resources,
        )

    def _reroute_away_from_resource_ids(
        self,
        uav_index: int,
        candidate: UAVDecisionVariables,
        blocked_resources: set[str],
    ) -> UAVDecisionVariables | None:
        uav = self.problem.uavs[uav_index]
        alternatives = []
        for route_index, route in enumerate(uav.route_candidates):
            if route_index == candidate.route_index:
                continue
            overlap = len(blocked_resources.intersection(route.resource_ids))
            alternatives.append((overlap, route.route_length_m, route_index))
        if not alternatives:
            return None
        _, _, route_index = min(alternatives)
        route = uav.route(route_index)
        altitude = (
            candidate.altitude_layer_index
            if candidate.altitude_layer_index in route.permitted_altitude_layers
            else route.permitted_altitude_layers[0]
        )
        remapped = remap_decision_to_assignment(
            self.problem,
            uav_index,
            candidate,
            DiscreteRouteAssignment(route_index, altitude),
        )
        return replace(
            remapped,
            edge_travel_times_s=route.min_edge_times_s.copy(),
        )

    def _root_candidates(
        self,
        uav_index: int,
        current: UAVDecisionVariables,
    ) -> tuple[tuple[str, UAVDecisionVariables], ...]:
        uav = self.problem.uavs[uav_index]
        route_indices = (
            range(len(uav.route_candidates))
            if self.config.try_route_alternatives
            else (current.route_index,)
        )
        output = []
        for route_index in route_indices:
            route = uav.route(route_index)
            altitude = (
                current.altitude_layer_index
                if current.altitude_layer_index in route.permitted_altitude_layers
                else route.permitted_altitude_layers[0]
            )
            remapped = remap_decision_to_assignment(
                self.problem,
                uav_index,
                current,
                DiscreteRouteAssignment(route_index, altitude),
            )
            speed_profiles = (
                [("minimum_edge_times", route.min_edge_times_s)]
                if self.config.try_minimum_edge_times
                else [("current_speed", remapped.edge_travel_times_s)]
            )
            delays = tuple(
                sorted(
                    {
                        0.0,
                        float(
                            np.clip(
                                remapped.departure_delay_s,
                                0.0,
                                self.problem.config.max_departure_delay_s,
                            )
                        ),
                    }
                )
            )
            for speed_label, edge_times in speed_profiles:
                for delay in delays:
                    output.append(
                        (
                            f"route_{route_index}:{speed_label}:delay_{delay:.6g}",
                            replace(
                                remapped,
                                departure_delay_s=delay,
                                edge_travel_times_s=np.asarray(
                                    edge_times,
                                    dtype=float,
                                ).copy(),
                            ),
                        )
                    )
        return tuple(output)

    def _feedback_neighbors(
        self,
        uav_index: int,
        candidate: UAVDecisionVariables,
        projection: CertificateProjectionResult,
        evaluation: CertificateEvaluation,
    ) -> tuple[tuple[str, UAVDecisionVariables], ...]:
        output = []
        if CertificateFailureType.RESOURCE_OVERLOAD in evaluation.failure_types:
            shift = self._required_candidate_delay_shift(
                self.problem.uavs[uav_index].uav_id,
                projection,
            )
            if shift > 0.0:
                delayed = self._add_departure_delay(candidate, shift)
                if delayed is not None:
                    output.append((f"resource_delay_{shift:.6g}", delayed))
                else:
                    held = self._add_holding_before_witness(
                        uav_index,
                        candidate,
                        evaluation,
                        shift,
                    )
                    if held is not None:
                        output.append((f"resource_holding_{shift:.6g}", held))
            faster = self._speed_up_witness_edges(
                uav_index,
                candidate,
                evaluation,
            )
            if faster is not None:
                output.append(("resource_speed_up", faster))
        if (
            CertificateFailureType.RESOURCE_OVERLOAD
            not in evaluation.failure_types
            and (
                CertificateFailureType.GEOMETRY_SEPARATION
                in evaluation.failure_types
                or CertificateFailureType.NUMERICAL_UNRESOLVED
                in evaluation.failure_types
            )
        ):
            delayed = self._add_departure_delay(
                candidate,
                self.config.geometry_delay_step_s,
            )
            if delayed is not None:
                output.append(
                    (
                        f"geometry_delay_{self.config.geometry_delay_step_s:.6g}",
                        delayed,
                    )
                )
        return tuple(output)

    def _information_limited_feedback_neighbors(
        self,
        uav_index: int,
        candidate: UAVDecisionVariables,
        projection: CertificateProjectionResult,
        evaluation: CertificateEvaluation,
        mode: FeedbackInformationMode,
    ) -> tuple[tuple[str, UAVDecisionVariables], ...]:
        if mode in {"full_witness", "structured"}:
            return self._feedback_neighbors(
                uav_index,
                candidate,
                projection,
                evaluation,
            )
        if CertificateFailureType.RESOURCE_OVERLOAD not in evaluation.failure_types:
            return self._feedback_neighbors(
                uav_index,
                candidate,
                projection,
                evaluation,
            )
        uav_id = self.problem.uavs[uav_index].uav_id
        allowed = self._information_limited_responsible_ids(
            tuple(uav.uav_id for uav in self.problem.uavs),
            evaluation,
            mode,
        )
        if uav_id not in allowed:
            return tuple()
        resources = self._resource_ids(evaluation)
        output: list[tuple[str, UAVDecisionVariables]] = []
        if mode == "resource_only":
            rerouted = self._reroute_away_from_resource_ids(
                uav_index,
                candidate,
                resources,
            )
            if rerouted is not None:
                output.append(("resource_only_reroute", rerouted))
            delayed = self._add_departure_delay(
                candidate,
                self.config.generic_delay_step_s,
            )
            if delayed is not None:
                output.append(("resource_only_delay", delayed))
            return tuple(output)

        shift = self._required_resource_time_shift(
            uav_id,
            projection,
            evaluation,
        )
        if shift > 0.0:
            delayed = self._add_departure_delay(candidate, shift)
            if delayed is not None:
                output.append((f"resource_time_delay_{shift:.6g}", delayed))
            else:
                held = self._add_holding_before_resource_time(
                    uav_index,
                    candidate,
                    self._resource_time_supports(evaluation),
                    shift,
                )
                if held is not None:
                    output.append((f"resource_time_holding_{shift:.6g}", held))
        faster = self._speed_up_resource_ids(uav_index, candidate, resources)
        if faster is not None:
            output.append(("resource_time_speed_up", faster))
        rerouted = self._reroute_away_from_resource_ids(
            uav_index,
            candidate,
            resources,
        )
        if rerouted is not None:
            output.append(("resource_time_reroute", rerouted))
        return tuple(output)

    @staticmethod
    def _resource_ids(evaluation: CertificateEvaluation) -> set[str]:
        return {witness.resource_id for witness in evaluation.resource_witnesses}

    @staticmethod
    def _resource_time_supports(
        evaluation: CertificateEvaluation,
    ) -> tuple[tuple[str, float, float], ...]:
        return tuple(
            (witness.resource_id, witness.start_time_s, witness.end_time_s)
            for witness in evaluation.resource_witnesses
        )

    @staticmethod
    def _information_limited_responsible_ids(
        all_uav_ids: tuple[str, ...],
        evaluation: CertificateEvaluation,
        mode: FeedbackInformationMode,
    ) -> tuple[str, ...]:
        if mode in {"resource_time_responsible", "full_witness", "structured"}:
            return evaluation.responsible_uav_ids
        return tuple(sorted(set(all_uav_ids)))

    def _generic_feedback_neighbors(
        self,
        uav_index: int,
        candidate: UAVDecisionVariables,
    ) -> tuple[tuple[str, UAVDecisionVariables], ...]:
        """Generate blind repair candidates after receiving only FAILED.

        This method deliberately accepts neither a projection nor an evaluation,
        preventing access to resource IDs, time supports, responsible UAV sets,
        occupancy peaks, overload integrals, or certificate-derived hyperedges.
        """

        output: list[tuple[str, UAVDecisionVariables]] = []
        delayed = self._add_departure_delay(
            candidate,
            self.config.generic_delay_step_s,
        )
        if delayed is not None:
            output.append(("generic_delay", delayed))

        route = self.problem.uavs[uav_index].route(candidate.route_index)
        for hold_index, is_allowed in enumerate(
            route.holding_allowed_after_edge
        ):
            if not is_allowed:
                continue
            available = (
                self.problem.config.max_holding_time_s
                - candidate.holding_times_s[hold_index]
            )
            increment = min(self.config.generic_holding_step_s, available)
            if increment <= 1e-9:
                continue
            holding = candidate.holding_times_s.copy()
            holding[hold_index] += increment
            output.append(
                (
                    f"generic_holding_{hold_index}",
                    replace(candidate, holding_times_s=holding),
                )
            )
        return tuple(output)

    def _required_candidate_delay_shift(
        self,
        uav_id: str,
        projection: CertificateProjectionResult,
    ) -> float:
        all_intervals = tuple(
            interval
            for certificate in (
                projection.existing_certificates
                + projection.candidate_certificates
            )
            for interval in certificate.resource_intervals
        )
        shifts = []
        for episode in projection.verification.overload_episodes:
            selected = [
                interval
                for interval in all_intervals
                if interval.uav_id == uav_id
                and interval.resource_id == episode.resource_id
                and interval.t_enter_robust < episode.t_end
                and episode.t_start < interval.t_exit_robust
            ]
            others = [
                interval
                for interval in all_intervals
                if interval.uav_id != uav_id
                and interval.resource_id == episode.resource_id
                and interval.t_enter_robust < episode.t_end
                and episode.t_start < interval.t_exit_robust
            ]
            if selected and others:
                shifts.append(
                    max(interval.t_exit_robust for interval in others)
                    - min(interval.t_enter_robust for interval in selected)
                    + self.config.delay_guard_s
                )
        positive = [value for value in shifts if value > 1e-9]
        return max(self.config.delay_guard_s, min(positive)) if positive else 0.0

    def _required_resource_time_shift(
        self,
        uav_id: str,
        projection: CertificateProjectionResult,
        evaluation: CertificateEvaluation,
    ) -> float:
        """Return a shift derived only from resource/time support and own visits.

        The ResourceTime and ResourceTimeResponsible ablations may inspect the
        overload resource identifier and support endpoints.  They may also
        inspect the candidate UAV's own projected visit because that visit is
        part of its current decision realisation.  They deliberately do not
        inspect other UAV interval endpoints, witness capacity, peak occupancy,
        integrated overload, or visit-index/responsibility fields.
        """

        own_intervals = tuple(
            interval
            for certificate in (
                projection.existing_certificates
                + projection.candidate_certificates
            )
            if certificate.uav_id == uav_id
            for interval in certificate.resource_intervals
        )
        shifts = []
        for resource_id, _, end_time_s in self._resource_time_supports(evaluation):
            matching = [
                interval
                for interval in own_intervals
                if interval.resource_id == resource_id
                and interval.t_enter_robust < end_time_s
            ]
            if matching:
                shifts.append(
                    end_time_s
                    - min(interval.t_enter_robust for interval in matching)
                    + self.config.delay_guard_s
                )
        positive = [value for value in shifts if value > 1e-9]
        return max(self.config.delay_guard_s, min(positive)) if positive else 0.0

    def _add_departure_delay(
        self,
        candidate: UAVDecisionVariables,
        shift_s: float,
    ) -> UAVDecisionVariables | None:
        target = candidate.departure_delay_s + max(0.0, float(shift_s))
        if target > self.problem.config.max_departure_delay_s + 1e-9:
            return None
        return replace(candidate, departure_delay_s=float(target))

    def _add_holding_before_witness(
        self,
        uav_index: int,
        candidate: UAVDecisionVariables,
        evaluation: CertificateEvaluation,
        shift_s: float,
    ) -> UAVDecisionVariables | None:
        if not len(candidate.holding_times_s):
            return None
        uav_id = self.problem.uavs[uav_index].uav_id
        route = self.problem.uavs[uav_index].route(candidate.route_index)
        for witness in evaluation.resource_witnesses:
            visit_indices = witness.visit_indices.get(uav_id, tuple())
            if not visit_indices:
                continue
            matching_edges = [
                edge_index
                for edge_index, resource_id in enumerate(route.resource_ids)
                if resource_id == witness.resource_id
            ]
            occurrence = visit_indices[0]
            if occurrence >= len(matching_edges):
                continue
            target_edge = matching_edges[occurrence]
            allowed = [
                index
                for index, is_allowed in enumerate(
                    route.holding_allowed_after_edge
                )
                if is_allowed and index < target_edge
            ]
            if not allowed:
                continue
            for hold_index in reversed(allowed):
                available = (
                    self.problem.config.max_holding_time_s
                    - candidate.holding_times_s[hold_index]
                )
                increment = min(
                    max(0.0, shift_s),
                    max(0.0, available),
                )
                if increment <= 1e-9:
                    continue
                holding = candidate.holding_times_s.copy()
                holding[hold_index] += increment
                return replace(candidate, holding_times_s=holding)
        return None

    def _add_holding_before_resource_time(
        self,
        uav_index: int,
        candidate: UAVDecisionVariables,
        resource_time_supports: tuple[tuple[str, float, float], ...],
        shift_s: float,
    ) -> UAVDecisionVariables | None:
        if not len(candidate.holding_times_s):
            return None
        route = self.problem.uavs[uav_index].route(candidate.route_index)
        implicated = {resource_id for resource_id, _, _ in resource_time_supports}
        matching_edges = [
            edge_index
            for edge_index, resource_id in enumerate(route.resource_ids)
            if resource_id in implicated
        ]
        if not matching_edges:
            return None
        target_edge = min(matching_edges)
        allowed = [
            index
            for index, is_allowed in enumerate(route.holding_allowed_after_edge)
            if is_allowed and index < target_edge
        ]
        for hold_index in reversed(allowed):
            available = (
                self.problem.config.max_holding_time_s
                - candidate.holding_times_s[hold_index]
            )
            increment = min(max(0.0, shift_s), max(0.0, available))
            if increment <= 1e-9:
                continue
            holding = candidate.holding_times_s.copy()
            holding[hold_index] += increment
            return replace(candidate, holding_times_s=holding)
        return None

    def _speed_up_witness_edges(
        self,
        uav_index: int,
        candidate: UAVDecisionVariables,
        evaluation: CertificateEvaluation,
    ) -> UAVDecisionVariables | None:
        uav_id = self.problem.uavs[uav_index].uav_id
        route = self.problem.uavs[uav_index].route(candidate.route_index)
        edge_times = candidate.edge_travel_times_s.copy()
        changed = False
        for witness in evaluation.resource_witnesses:
            if uav_id not in witness.responsible_uav_ids:
                continue
            for edge_index, resource_id in enumerate(route.resource_ids):
                if resource_id != witness.resource_id:
                    continue
                minimum = route.min_edge_times_s[edge_index]
                if edge_times[edge_index] > minimum + 1e-9:
                    edge_times[edge_index] = minimum
                    changed = True
        return replace(candidate, edge_travel_times_s=edge_times) if changed else None

    def _speed_up_resource_ids(
        self,
        uav_index: int,
        candidate: UAVDecisionVariables,
        resource_ids: set[str],
    ) -> UAVDecisionVariables | None:
        route = self.problem.uavs[uav_index].route(candidate.route_index)
        edge_times = candidate.edge_travel_times_s.copy()
        changed = False
        for edge_index, resource_id in enumerate(route.resource_ids):
            if resource_id not in resource_ids:
                continue
            minimum = route.min_edge_times_s[edge_index]
            if edge_times[edge_index] > minimum + 1e-9:
                edge_times[edge_index] = minimum
                changed = True
        return replace(candidate, edge_travel_times_s=edge_times) if changed else None

    def _evaluate_incumbent(
        self,
        decisions: Mapping[str, UAVDecisionVariables],
        accepted_uav_ids: tuple[str, ...],
    ) -> tuple[
        CertificateProjectionResult,
        ContinuousSeparationResult,
        CertificateEvaluation,
    ]:
        projection = self.projector.project(
            decisions,
            uav_ids=accepted_uav_ids,
        )
        trajectories = dict(projection.polynomial_trajectories)
        geometry_started = perf_counter()
        geometry = self.separation_verifier.verify(
            trajectories,
            minimum_separation_m=self.config.minimum_separation_m,
            tracking_bounds_m=self.config.tracking_bounds_m,
        )
        geometry_runtime = perf_counter() - geometry_started
        evaluation = evaluate_certificate(
            f"phase13_incumbent:{decision_fingerprint(decisions)[:16]}",
            projection,
            geometry=geometry,
            require_geometry=True,
            tracking_tube_safe=(
                self.config.tracking_tube_certified
                or not accepted_uav_ids
            ),
            certificate_runtime_s=(
                projection.projection_runtime_s + geometry_runtime
            ),
        )
        return projection, geometry, evaluation

    def _candidate_score(
        self,
        uav_index: int,
        candidate: UAVDecisionVariables,
    ) -> float:
        route = self.problem.uavs[uav_index].route(candidate.route_index)
        return float(
            self.config.departure_delay_score_weight
            * candidate.departure_delay_s
            + self.config.travel_time_score_weight
            * np.sum(candidate.edge_travel_times_s)
            + self.config.holding_time_score_weight
            * np.sum(candidate.holding_times_s)
            + self.config.route_length_score_weight
            * route.route_length_m
            + self.config.route_switch_score_penalty
            * float(
                candidate.route_index
                != self.problem.uavs[uav_index].initial_route_index
            )
        )

    def _queue_priority(
        self,
        uav_index: int,
        candidate: UAVDecisionVariables,
        serial: int,
    ) -> float:
        if self.config.search_queue_mode == "fifo_coordinate":
            return float(serial)
        return self._candidate_score(uav_index, candidate)

    def _deadline_reached(
        self,
        deadline_s: float,
        total_evaluations: int,
    ) -> bool:
        return (
            self._time_expired(deadline_s)
            or total_evaluations
            >= min(
                self.config.maximum_total_candidate_evaluations,
                self.config.maximum_route_evaluations,
            )
            or self._replanning_calls >= self.config.maximum_replanning_calls
        )

    def _remaining_candidate_evaluations(self, total_evaluations: int) -> int:
        return max(
            0,
            min(
                self.config.maximum_total_candidate_evaluations,
                self.config.maximum_route_evaluations,
            )
            - total_evaluations,
        )

    @staticmethod
    def _time_expired(deadline_s: float) -> bool:
        return perf_counter() >= deadline_s

    def _uav_index(self, uav_id: str) -> int:
        for index, uav in enumerate(self.problem.uavs):
            if uav.uav_id == uav_id:
                return index
        raise KeyError(uav_id)
