from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

import numpy as np

from .decision_variables import UAVDecisionVariables
from .problem_definition import HyperCertProblemDefinition


@dataclass(frozen=True)
class ResourceVisit:
    uav_id: str
    route_id: str
    resource_id: str
    edge_index: int
    visit_index: int
    nominal_enter_s: float
    nominal_exit_s: float
    enter_jacobian: np.ndarray
    exit_jacobian: np.ndarray


class SoftOccupancyModel:
    """Differentiable timing projection used only inside optimization.

    This model is not an exact resource certificate and must not be used as an
    execution acceptance test.
    """

    def __init__(self, problem: HyperCertProblemDefinition) -> None:
        self.problem = problem
        self.time_grid_s = problem.time_grid_s
        self.temperature_s = problem.config.occupancy_temperature_s

    def visits_for_uav(self, uav_index: int, decision: UAVDecisionVariables) -> tuple[ResourceVisit, ...]:
        uav = self.problem.uavs[uav_index]
        route = uav.route(decision.route_index)
        layout = decision.continuous_layout
        current_time = uav.release_time_s + decision.departure_delay_s
        time_jacobian = np.zeros(layout.size, dtype=float)
        time_jacobian[layout.departure_delay] = 1.0
        visit_count: dict[str, int] = {}
        visits: list[ResourceVisit] = []
        for edge_index, resource_id in enumerate(route.resource_ids):
            enter_s = float(current_time)
            enter_jacobian = time_jacobian.copy()
            edge_coordinate = layout.edge_travel_times.start + edge_index
            current_time += decision.edge_travel_times_s[edge_index]
            time_jacobian[edge_coordinate] += 1.0
            exit_s = float(current_time)
            exit_jacobian = time_jacobian.copy()
            occurrence = visit_count.get(resource_id, 0)
            visit_count[resource_id] = occurrence + 1
            visits.append(
                ResourceVisit(
                    uav_id=uav.uav_id,
                    route_id=route.route_id,
                    resource_id=resource_id,
                    edge_index=edge_index,
                    visit_index=occurrence,
                    nominal_enter_s=enter_s,
                    nominal_exit_s=exit_s,
                    enter_jacobian=enter_jacobian,
                    exit_jacobian=exit_jacobian,
                )
            )
            if edge_index < route.holding_count:
                current_time += decision.holding_times_s[edge_index]
                holding_coordinate = layout.holding_times.start + edge_index
                time_jacobian[holding_coordinate] += 1.0
        return tuple(visits)

    def occupancy_for_visit(self, visit: ResourceVisit) -> np.ndarray:
        left = _sigmoid((self.time_grid_s - visit.nominal_enter_s) / self.temperature_s)
        right = _sigmoid((visit.nominal_exit_s - self.time_grid_s) / self.temperature_s)
        return left * right

    def occupancy_gradient_for_visit(self, visit: ResourceVisit) -> np.ndarray:
        left = _sigmoid((self.time_grid_s - visit.nominal_enter_s) / self.temperature_s)
        right = _sigmoid((visit.nominal_exit_s - self.time_grid_s) / self.temperature_s)
        derivative_enter = -(left * (1.0 - left) * right) / self.temperature_s
        derivative_exit = (left * right * (1.0 - right)) / self.temperature_s
        return (
            derivative_enter[:, None] * visit.enter_jacobian[None, :]
            + derivative_exit[:, None] * visit.exit_jacobian[None, :]
        )

    def occupancy_by_resource_for_uav(
        self,
        uav_index: int,
        decision: UAVDecisionVariables,
    ) -> dict[str, np.ndarray]:
        occupancy = {resource_id: np.zeros_like(self.time_grid_s) for resource_id in self.problem.resource_ids}
        for visit in self.visits_for_uav(uav_index, decision):
            occupancy[visit.resource_id] += self.occupancy_for_visit(visit)
        return occupancy

    def aggregate_by_resource(
        self,
        decisions: Mapping[str, UAVDecisionVariables],
    ) -> dict[str, np.ndarray]:
        self.problem.validate_decisions(decisions)
        aggregate = {resource_id: np.zeros_like(self.time_grid_s) for resource_id in self.problem.resource_ids}
        for uav_index, uav in enumerate(self.problem.uavs):
            local = self.occupancy_by_resource_for_uav(uav_index, decisions[uav.uav_id])
            for resource_id, values in local.items():
                aggregate[resource_id] += values
        return aggregate

    def capacity_residual(
        self,
        decisions: Mapping[str, UAVDecisionVariables],
    ) -> dict[str, np.ndarray]:
        occupancy = self.aggregate_by_resource(decisions)
        return {
            resource_id: values - self.problem.resource_capacity(resource_id)
            for resource_id, values in occupancy.items()
        }

    def integrated_price_cost_and_gradient(
        self,
        uav_index: int,
        decision: UAVDecisionVariables,
        resource_prices: Mapping[str, np.ndarray],
    ) -> tuple[float, np.ndarray]:
        gradient = np.zeros(decision.continuous_layout.size, dtype=float)
        cost = 0.0
        dt = float(np.mean(np.diff(self.time_grid_s)))
        for visit in self.visits_for_uav(uav_index, decision):
            price = np.asarray(resource_prices[visit.resource_id], dtype=float)
            if price.shape != self.time_grid_s.shape:
                raise ValueError(f"price shape for {visit.resource_id} does not match the optimization grid")
            occupancy = self.occupancy_for_visit(visit)
            occupancy_gradient = self.occupancy_gradient_for_visit(visit)
            cost += float(np.sum(price * occupancy) * dt)
            gradient += np.sum(price[:, None] * occupancy_gradient, axis=0) * dt
        return cost, gradient


def _sigmoid(values: np.ndarray) -> np.ndarray:
    x = np.asarray(values, dtype=float)
    result = np.empty_like(x)
    positive = x >= 0.0
    result[positive] = 1.0 / (1.0 + np.exp(-x[positive]))
    exp_x = np.exp(x[~positive])
    result[~positive] = exp_x / (1.0 + exp_x)
    return result

