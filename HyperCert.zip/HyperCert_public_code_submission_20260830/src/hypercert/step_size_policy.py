from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class DiminishingStepSizePolicy:
    """Robbins-Monro step size for the restricted convex convergence result."""

    initial_step: float = 0.50
    offset: float = 1.0
    decay_power: float = 0.75

    def __post_init__(self) -> None:
        if self.initial_step <= 0.0:
            raise ValueError("initial_step must be positive")
        if self.offset < 0.0:
            raise ValueError("offset cannot be negative")
        if not 0.5 < self.decay_power <= 1.0:
            raise ValueError("decay_power must lie in (0.5, 1]")

    def update(self, iteration: int, primal_residual: float = 0.0, dual_residual: float = 0.0) -> float:
        if iteration <= 0:
            raise ValueError("iteration must be positive")
        del primal_residual, dual_residual
        return float(self.initial_step / ((self.offset + iteration) ** self.decay_power))

    @property
    def has_infinite_sum_and_square_summable(self) -> bool:
        """Return the analytic Robbins-Monro condition for the power schedule."""

        return 0.5 < self.decay_power <= 1.0


@dataclass
class AdaptiveStepSizePolicy:
    initial_step: float = 0.20
    minimum_step: float = 1e-4
    maximum_step: float = 1.0
    growth_factor: float = 1.05
    shrink_factor: float = 0.70
    residual_balance: float = 5.0
    decay_power: float = 0.25

    def __post_init__(self) -> None:
        if not 0.0 < self.minimum_step <= self.initial_step <= self.maximum_step:
            raise ValueError("step sizes must satisfy 0 < min <= initial <= max")
        if self.growth_factor < 1.0 or not 0.0 < self.shrink_factor <= 1.0:
            raise ValueError("invalid adaptive step factors")
        self.current_step = float(self.initial_step)

    def update(self, iteration: int, primal_residual: float, dual_residual: float) -> float:
        if iteration <= 0:
            raise ValueError("iteration must be positive")
        if primal_residual > self.residual_balance * max(dual_residual, 1e-12):
            self.current_step = min(self.maximum_step, self.current_step * self.growth_factor)
        elif dual_residual > self.residual_balance * max(primal_residual, 1e-12):
            self.current_step = max(self.minimum_step, self.current_step * self.shrink_factor)
        decayed = self.current_step / (float(iteration) ** self.decay_power)
        return max(self.minimum_step, min(self.maximum_step, decayed))

    def reset(self) -> None:
        self.current_step = float(self.initial_step)
