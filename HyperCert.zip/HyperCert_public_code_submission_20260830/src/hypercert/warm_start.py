from __future__ import annotations

from dataclasses import dataclass

from .decision_variables import UAVDecisionVariables
from .dual_variables import ResourceTimeDualVariables
from .problem_definition import HyperCertProblemDefinition


@dataclass(frozen=True)
class HyperCertWarmStart:
    decisions: dict[str, UAVDecisionVariables]
    duals: ResourceTimeDualVariables
    source_iteration: int = 0
    source_label: str = "previous_solve"

    def validate(self, problem: HyperCertProblemDefinition) -> None:
        problem.validate_decisions(self.decisions)
        if set(self.duals.values) != set(problem.resource_ids):
            raise ValueError("warm-start dual resources do not match the problem")
        if self.duals.time_grid_s.shape != problem.time_grid_s.shape or not (
            self.duals.time_grid_s == problem.time_grid_s
        ).all():
            raise ValueError("warm-start dual grid does not match the problem")

    def copied_decisions(self) -> dict[str, UAVDecisionVariables]:
        return {
            uav_id: decision.with_continuous_vector(decision.continuous_vector().copy())
            for uav_id, decision in self.decisions.items()
        }


class WarmStartCache:
    def __init__(self) -> None:
        self._entries: dict[str, HyperCertWarmStart] = {}

    def put(self, key: str, warm_start: HyperCertWarmStart) -> None:
        if not key:
            raise ValueError("warm-start key cannot be empty")
        self._entries[key] = warm_start

    def get(self, key: str, problem: HyperCertProblemDefinition) -> HyperCertWarmStart | None:
        entry = self._entries.get(key)
        if entry is None:
            return None
        entry.validate(problem)
        return HyperCertWarmStart(
            decisions=entry.copied_decisions(),
            duals=entry.duals.copy(),
            source_iteration=entry.source_iteration,
            source_label=entry.source_label,
        )

