from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ResourceUncertaintyBounds:
    epsilon_early_s: float
    epsilon_late_s: float
    spatial_margin_m: float

    def __post_init__(self) -> None:
        if min(self.epsilon_early_s, self.epsilon_late_s, self.spatial_margin_m) < 0.0:
            raise ValueError("resource uncertainty bounds must be nonnegative")


@dataclass
class UncertaintyModel:
    tracking_position_error_m: float = 0.0
    velocity_error_mps: float = 0.0
    velocity_error_propagation_horizon_s: float = 1.0
    controller_response_delay_s: float = 0.0
    network_latency_s: float = 0.0
    clock_sync_error_s: float = 0.0
    numerical_interpolation_error_s: float = 1e-3
    resource_overrides: dict[str, ResourceUncertaintyBounds] = field(default_factory=dict)

    def __post_init__(self) -> None:
        values = (
            self.tracking_position_error_m,
            self.velocity_error_mps,
            self.velocity_error_propagation_horizon_s,
            self.controller_response_delay_s,
            self.network_latency_s,
            self.clock_sync_error_s,
            self.numerical_interpolation_error_s,
        )
        if min(values) < 0.0:
            raise ValueError("uncertainty components must be nonnegative")

    def bounds_for_resource(self, resource_id: str, nominal_speed_mps: float) -> ResourceUncertaintyBounds:
        if resource_id in self.resource_overrides:
            return self.resource_overrides[resource_id]
        speed = max(abs(float(nominal_speed_mps)), 1e-6)
        spatial_time = self.tracking_position_error_m / speed
        velocity_position_error_m = (
            self.velocity_error_mps * self.velocity_error_propagation_horizon_s
        )
        velocity_time = velocity_position_error_m / speed
        epsilon = (
            spatial_time
            + velocity_time
            + self.controller_response_delay_s
            + self.network_latency_s
            + self.clock_sync_error_s
            + self.numerical_interpolation_error_s
        )
        return ResourceUncertaintyBounds(
            epsilon_early_s=max(0.0, epsilon),
            epsilon_late_s=max(0.0, epsilon),
            spatial_margin_m=max(0.0, self.tracking_position_error_m),
        )
