from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ReservationLease:
    lease_id: str
    owner_id: str
    expires_at: float
    priority: float = 0.0
