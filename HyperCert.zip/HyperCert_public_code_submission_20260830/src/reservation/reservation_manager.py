from __future__ import annotations

from dataclasses import dataclass, field
from threading import RLock
from time import monotonic, time
from uuid import uuid4

from certificate.certificate_auditor import CertificateAuditor
from certificate.resource_certificate import ResourceCertificate

from .reservation_lease import ReservationLease
from .reservation_snapshot import ReservationSnapshot
from .reservation_transaction import ReservationTransaction
from .resource_calendar import ResourceCalendar


@dataclass(frozen=True)
class ReservationCommitResult:
    success: bool
    version: int
    reason: str = ""
    retry_recommended: bool = False


@dataclass
class ReservationManager:
    capacities: dict[str, int]
    lease_ttl_s: float = 30.0
    auditor: CertificateAuditor = field(default_factory=CertificateAuditor)
    _calendar: ResourceCalendar = field(init=False)
    _version: int = 0
    _resource_versions: dict[str, int] = field(default_factory=dict)
    _leases: dict[str, ReservationLease] = field(default_factory=dict)
    _certificate_priorities: dict[str, float] = field(default_factory=dict)
    _lock: RLock = field(default_factory=RLock)

    def __post_init__(self) -> None:
        self.capacities = {str(k): max(1, int(v)) for k, v in self.capacities.items()}
        self._calendar = ResourceCalendar(self.capacities)
        self._resource_versions = {rid: 0 for rid in self.capacities}

    def snapshot(self) -> ReservationSnapshot:
        with self._lock:
            self._expire_leases_locked()
            return ReservationSnapshot(
                version=self._version,
                resource_versions=dict(self._resource_versions),
                certificates=self._calendar.active_certificates(),
                capacities=dict(self.capacities),
            )

    def create_lease(self, owner_id: str, priority: float = 0.0) -> ReservationLease:
        with self._lock:
            lease = ReservationLease(str(uuid4()), owner_id, monotonic() + self.lease_ttl_s, priority)
            self._leases[lease.lease_id] = lease
            return lease

    def make_transaction(
        self,
        owner_id: str,
        snapshot: ReservationSnapshot,
        certificates: tuple[ResourceCertificate, ...],
        lease: ReservationLease | None = None,
        priority: float = 0.0,
        replace_certificate_ids: tuple[str, ...] = tuple(),
    ) -> ReservationTransaction:
        replace_ids = tuple(sorted(set(replace_certificate_ids)))
        snapshot_by_id = {certificate.certificate_id: certificate for certificate in snapshot.certificates}
        replacement_resources = tuple(
            sorted(
                {
                    interval.resource_id
                    for certificate_id in replace_ids
                    if certificate_id in snapshot_by_id
                    for interval in snapshot_by_id[certificate_id].resource_intervals
                }
            )
        )
        touched = {i.resource_id for c in certificates for i in c.resource_intervals}
        touched.update(replacement_resources)
        expected = {rid: snapshot.resource_versions.get(rid, 0) for rid in touched}
        return ReservationTransaction(
            owner_id=owner_id,
            base_version=snapshot.version,
            expected_resource_versions=expected,
            certificates=certificates,
            lease=lease,
            priority=priority,
            replace_certificate_ids=replace_ids,
            replacement_resource_ids=replacement_resources,
        )

    def commit(self, transaction: ReservationTransaction) -> ReservationCommitResult:
        with self._lock:
            self._expire_leases_locked()
            if transaction.lease is not None:
                lease = self._leases.get(transaction.lease.lease_id)
                if lease is None or lease.owner_id != transaction.owner_id:
                    return ReservationCommitResult(False, self._version, "lease_expired_or_missing", True)
            if transaction.base_version != self._version:
                return ReservationCommitResult(False, self._version, "version_conflict", True)
            for rid, expected in transaction.expected_resource_versions.items():
                if self._resource_versions.get(rid, 0) != expected:
                    return ReservationCommitResult(False, self._version, "resource_version_conflict", True)
            missing_replacements = set(transaction.replace_certificate_ids) - set(self._calendar.certificates)
            if missing_replacements:
                return ReservationCommitResult(False, self._version, "replacement_certificate_missing", True)
            excluded = set(transaction.replace_certificate_ids)
            verification = self._calendar.verify_with(
                transaction.certificates,
                tuple(sorted(excluded)),
            )
            preemptions: set[str] = set()
            if not verification.is_safe:
                preemptions = self._priority_preemption_candidates_locked(transaction) - excluded
                if preemptions:
                    verification = self._calendar.verify_with(
                        transaction.certificates,
                        tuple(sorted(excluded.union(preemptions))),
                    )
            if not verification.is_safe:
                for cert in transaction.certificates:
                    self.auditor.record(cert, "reject", "resource_capacity", verification.to_json_dict())
                return ReservationCommitResult(False, self._version, "resource_capacity", False)
            for certificate_id in sorted(excluded.union(preemptions)):
                old = self._calendar.remove(certificate_id)
                self._certificate_priorities.pop(certificate_id, None)
                if old is not None:
                    action = "replace" if certificate_id in excluded else "preempt"
                    reason = "atomic_suffix_replacement" if action == "replace" else "priority_preemption"
                    self.auditor.record(
                        old,
                        action,
                        reason,
                        verification.to_json_dict(),
                        old.certificate_version,
                        old.certificate_version + 1,
                    )
            for cert in transaction.certificates:
                committed = cert.with_state("committed")
                self._calendar.put(committed)
                self._certificate_priorities[committed.certificate_id] = float(transaction.priority)
                self.auditor.record(committed, "commit", "atomic_commit", verification.to_json_dict(), cert.certificate_version, committed.certificate_version)
            for rid in transaction.touched_resources:
                self._resource_versions[rid] = self._resource_versions.get(rid, 0) + 1
            self._version += 1
            if transaction.lease is not None:
                self._leases.pop(transaction.lease.lease_id, None)
            return ReservationCommitResult(True, self._version)

    def rollback(self, certificate_ids: tuple[str, ...]) -> int:
        with self._lock:
            removed = 0
            touched: set[str] = set()
            for cid in certificate_ids:
                cert = self._calendar.remove(cid)
                if cert is not None:
                    self._certificate_priorities.pop(cid, None)
                    removed += 1
                    touched.update(i.resource_id for i in cert.resource_intervals)
            if removed:
                for rid in touched:
                    self._resource_versions[rid] = self._resource_versions.get(rid, 0) + 1
                self._version += 1
            return removed

    def expire_leases(self) -> None:
        with self._lock:
            self._expire_leases_locked()

    def _expire_leases_locked(self) -> None:
        now = monotonic()
        expired = [lid for lid, lease in self._leases.items() if lease.expires_at <= now]
        for lid in expired:
            self._leases.pop(lid, None)

    def _priority_preemption_candidates_locked(self, transaction: ReservationTransaction) -> set[str]:
        if transaction.priority <= 0.0:
            return set()
        to_remove: set[str] = set()
        proposed = tuple(interval for cert in transaction.certificates for interval in cert.resource_intervals)
        for existing in self._calendar.active_certificates():
            existing_priority = self._certificate_priorities.get(existing.certificate_id, 0.0)
            if existing_priority >= transaction.priority:
                continue
            if any(a.overlaps(b) for a in proposed for b in existing.resource_intervals):
                to_remove.add(existing.certificate_id)
        if not to_remove:
            return set()
        return to_remove
