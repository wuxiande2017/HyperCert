from __future__ import annotations

from dataclasses import dataclass

from certificate.resource_certificate import ResourceCertificate


@dataclass(frozen=True)
class ReservationSnapshot:
    version: int
    resource_versions: dict[str, int]
    certificates: tuple[ResourceCertificate, ...]
    capacities: dict[str, int]
