from __future__ import annotations

from dataclasses import dataclass

from certificate.resource_certificate import ResourceCertificate

from .reservation_lease import ReservationLease


@dataclass(frozen=True)
class ReservationTransaction:
    owner_id: str
    base_version: int
    expected_resource_versions: dict[str, int]
    certificates: tuple[ResourceCertificate, ...]
    lease: ReservationLease | None = None
    priority: float = 0.0
    replace_certificate_ids: tuple[str, ...] = tuple()
    replacement_resource_ids: tuple[str, ...] = tuple()

    @property
    def touched_resources(self) -> tuple[str, ...]:
        proposed = {i.resource_id for c in self.certificates for i in c.resource_intervals}
        return tuple(sorted(proposed.union(self.replacement_resource_ids)))
