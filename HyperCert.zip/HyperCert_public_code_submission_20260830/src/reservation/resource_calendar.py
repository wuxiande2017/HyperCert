from __future__ import annotations

from dataclasses import dataclass, field

from certificate.continuous_capacity_verifier import ContinuousCapacityVerifier, ContinuousVerificationResult
from certificate.resource_certificate import ResourceCertificate


@dataclass
class ResourceCalendar:
    capacities: dict[str, int]
    certificates: dict[str, ResourceCertificate] = field(default_factory=dict)

    def active_certificates(self) -> tuple[ResourceCertificate, ...]:
        return tuple(cert for cert in self.certificates.values() if cert.state in {"committed", "executing", "tentative"})

    def verify_with(
        self,
        proposed: tuple[ResourceCertificate, ...] = tuple(),
        excluded_certificate_ids: tuple[str, ...] = tuple(),
    ) -> ContinuousVerificationResult:
        excluded = set(excluded_certificate_ids)
        certs = tuple(
            cert for cert in self.active_certificates() if cert.certificate_id not in excluded
        ) + tuple(proposed)
        intervals = tuple(interval for cert in certs for interval in cert.resource_intervals)
        return ContinuousCapacityVerifier(self.capacities).verify(intervals)

    def put(self, certificate: ResourceCertificate) -> None:
        self.certificates[certificate.certificate_id] = certificate

    def remove(self, certificate_id: str) -> ResourceCertificate | None:
        return self.certificates.pop(certificate_id, None)
