from __future__ import annotations

import unittest

import numpy as np

from certificate import ContinuousCapacityVerifier, OccupancyInterval
from hypercert import ResourceOverloadWitness
from hypercert.safe_anytime_planner import SafeAnytimePlannerConfig


class PublicCoreSmokeTest(unittest.TestCase):
    def test_capacity_sweep_detects_overlap(self) -> None:
        def interval(uav_id: str, start: float, end: float) -> OccupancyInterval:
            return OccupancyInterval(
                uav_id=uav_id,
                trajectory_id=f"trajectory-{uav_id}",
                resource_id="r",
                t_enter_nominal=start,
                t_exit_nominal=end,
                t_enter_robust=start,
                t_exit_robust=end,
                entry_position=np.zeros(3),
                exit_position=np.ones(3),
                spatial_margin_m=0.0,
                temporal_margin_s=0.0,
            )

        result = ContinuousCapacityVerifier({"r": 1}).verify(
            (interval("a", 0.0, 2.0), interval("b", 1.0, 3.0))
        )
        self.assertFalse(result.is_safe)
        self.assertEqual(result.maximum_occupancy["r"], 2)
        self.assertEqual(result.overload_integral_uav_s, 1.0)

    def test_public_planner_module_imports(self) -> None:
        config = SafeAnytimePlannerConfig()
        self.assertGreater(config.maximum_total_candidate_evaluations, 0)

    def test_structured_witness_validation(self) -> None:
        witness = ResourceOverloadWitness(
            resource_id="r",
            start_time_s=1.0,
            end_time_s=2.0,
            capacity=1,
            peak_occupancy=2,
            overload_integral_uav_s=1.0,
            responsible_uav_ids=("b", "a"),
            visit_indices={"a": (0,), "b": (0,)},
        )
        self.assertEqual(witness.responsible_uav_ids, ("a", "b"))


if __name__ == "__main__":
    unittest.main()
